const modifier = (text) => {    
  let modifiedText = text
  stop = false  
  const lowered = text.toLowerCase()

  if(!state.setup){
    state.setup = true
    state.set = {tic: 0, em: false, emDisplay: false}
    state.toggle = false
  }

  var commandMatcher = text.match(/\n? ?(?:> You |> You say "|)\/(\w*)(.*)/i) ? text.match(/\n? ?(?:> You |> You say "|)\/(\w*)(.*)/i) : []
  var command = commandMatcher[1]
  var editorText = text.match(/\n? ?(?:> You |> You say "|)(.*)/s) ? text.match(/\n? ?(?:> You |> You say "|)(.*)/s)[1] : ""
  if(command == "hang"){
    state.set.hang = commandMatcher[2] ? commandMatcher[2] : ""
    modifiedText = ""
    text = null; stop = true; return{ text, stop }
  }

  if(command == "en"){
    state.set.en = commandMatcher[2] ? commandMatcher[2] : ""
    modifiedText = ""
    state.set.enTic = state.set.tic
    text = null; stop = true; return{ text, stop }
  }

  if(command == "display"){
    state.set.emDisplay = state.set.emDisplay ? false : true
    modifiedText = ""
  }

  state.set.editorText = `[Editor's note: ${editorText}.]`

  if(state.set.emDisplay){
    state.displayStats = state.set.em ? [{key: "E/N", value: state.set.editorText}] : []
  } else {
    state.displayStats = []
  }

  if(command == "editor"){
    state.set.em = state.set.em ? false : true
    text = null; stop = true; return{ text, stop }
  }

  if(state.set.em){
    modifiedText = " "
  }

    return ({text : modifiedText})
}

modifier(text)
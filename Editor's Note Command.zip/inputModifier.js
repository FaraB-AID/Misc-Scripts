const modifier = (text) => {    
  let modifiedText = text
  stop = false  
  const lowered = text.toLowerCase()

  if(!state.setup){
    state.setup = true
    state.set = {args: []}
    state.toggle = false
  }

  var commandMatcher = text.match(/\n? ?(?:> You |> You say "|)\/(\w+?)( [\w ]+)?[".]?\n?$/i) ? text.match(/\n? ?(?:> You |> You say "|)\/(\w+?)( [\w ]+)?[".]?\n?$/i) : []
  var command = commandMatcher[1]
  
  if(!state.toggle){
    state.set.en = "" 
  } else {
    state.toggle = false
  }

  if(command == "en"){
    state.set.en = commandMatcher[2] ? commandMatcher[2] : []
    modifiedText = ""
    state.toggle = true
  }

    return ({text : modifiedText})
}

modifier(text)
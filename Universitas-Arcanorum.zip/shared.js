function getRandomInt(max) {
  return Math.floor(Math.random() * Math.floor(max));
} 

function toTitleCase(str) {
  return str.replace(
    /\w\S*/g,
    function(txt) {
      return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
    }
  );
}

const familiarTerms = /\bbat\b|\bcat\b|\bfrog\b|\btoad\b|\bcrab\b|\bhawk\b|\blizard\b|\boctopus\b|\bowl\b|\bsnake\b|\bfish\b|\brat\b|\bmouse\b|\braven\b|\bseahorse\b|\bspider\b|\bweasel\b|\bfox\b|\bsprite\b|\bpseudodragon\b/
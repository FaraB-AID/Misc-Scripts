const modifier = (text) => {
  let modifiedText = text
  console.log(info)

  function lowercaseFirstLetter(string) {
    return string.charAt(0).toLowerCase() + string.slice(1);
  }

  if (!state.set.inputOccurred){
    state.message = ""
  }

  if(info.evaluation.actionScore){
    state.level.currentExp += info.evaluation.actionScore
    state.message = `You gained ${info.evaluation.actionScore}xp because ` + lowercaseFirstLetter(info.evaluation.reason.substring(9))
  }


  if (state.level.currentExp >= state.level.expReq){
    state.level.player++
    state.level.currentExp -= state.level.expReq
    state.level.expReq = Math.round(state.level.expReq*1.35)
    state.skillPoints += 1
    state.message += `\nYou've leveled up! You're now level ${state.level.player}! Congrats!`
  }

  if(state.level.player == 2 && state.set.lvlTracker == 1){
    state.set.lvlTracker++
    state.event.familiar = true
  }

  if(getRandomInt(3) == 2 && state.event.familiar == true && !state.event.eventsOff){
    state.event.familiar = false
    state.event.eventsOff = true
    modifiedText = "\nA small shimmering portal suddenly appears above you. It only lasts a moment, dropping a thick envelope into your hands before disappearing. The envelope contains a note and a spell scroll.\nThe note reads \"Congratulations on your academic progress! Here at Universitas Arcanorum, we know that no-one should study magic alone. So, enjoy this scroll of Find Familiar.\nBest regards,\nUniversitas Arcanorum staff.\""
  }


  if(modifiedText.toLowerCase().includes("familiar") && !state.event.familiarComplete){
    state.set.familiarMatch = true
  }

  if(state.set.familiarMatch == true){
    var string = modifiedText.toLowerCase()
    if(familiarTerms.exec(string)){
      state.familiar.type = familiarTerms.exec(string)[0]
      state.set.finalMessageAdd = `Congratulations! You bonded a ${state.familiar.type} familiar! You can give them a name in WI.`
      for(var i = 0; i < worldInfo.length; i++){
        if(worldInfo[`${i}`].keys.includes("⚘")){
          worldInfo[`${i}`].entry = `Familiar Type: ${state.familiar.type}\nFamiliar Name: none\nYou can update your familiar type and name here.`
        }
      }
      state.event.familiarComplete = true
      state.set.familiarMatch = false
    }
  }

  var scheduleSchool = state.character.major ? state.character.major : "Unusual Magic"
  var scheduleAdvisor = state.set.advisors[state.character.major] ? state.set.advisors[state.character.major] : "Master Vongs"


  if(state.set.tic == 2 | state.event.hold == "schedule"){
    if(!state.event.eventsOff){
      modifiedText = `\nYou hear a faint meowing as a small portal irises open above you. A cat dressed in tweed casually pushes an envelope from a shelf. The envelope tumbles through the portal before it snaps shut. You find your class schedule inside. It reads:\n"𝑪𝒍𝒂𝒔𝒔 𝑺𝒄𝒉𝒆𝒅𝒖𝒍𝒆: ${scheduleSchool} Major, 1st Year:\nM,W - - 9am: - - - Introduction to ${scheduleSchool}\nT,U - - -11am: - - Foundations for Magical Study\nT - - - - - 1pm: - - ${state.set.electives1[state.set.el1]}\nW - - - - 4pm:- - - ${state.set.electives1[state.set.el2]}\nAdvisor:- - - - - - ${scheduleAdvisor}"`
      state.message += "You have a class schedule! It's been recorded in a WI entry."
      scheduleWI = {"id": "0.046241285244748375", "keys": "schedule, classes", entry:`𝑪𝒍𝒂𝒔𝒔 𝑺𝒄𝒉𝒆𝒅𝒖𝒍𝒆: ${scheduleSchool} Major, 1st Year:\nM,W - - 9am: - - - Introduction to ${scheduleSchool}\nT,U - - -11am: - - Foundations for Magical Study\nT - - - - - 1pm: - - ${state.set.electives1[state.set.el1]}\nW - - - - 4pm:- - - ${state.set.electives1[state.set.el2]}\nAdvisor:- - - - - - ${scheduleAdvisor}`, "isNotHidden": true}
      worldInfo.splice(2, 0, scheduleWI)
      state.event.eventsOff = true
      state.event.hold = ""
    } else {
        state.event.hold == "schedule"
    }
  }

  if(state.set.ticOn){
    state.set.tic++
    state.set.ticOn = false
  }

  state.message += state.set.finalMessageAdd
  state.set.finalMessageAdd = ""
  state.set.inputOccurred = false
  state.event.eventsOff = false

  return { text: modifiedText }
  }

modifier(text)
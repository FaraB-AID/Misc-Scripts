const modifier = (text) => {
  let modifiedText = text
  console.log(info)

  function lowercaseFirstLetter(string) {
    return string.charAt(0).toLowerCase() + string.slice(1);
  }

  state.message = ""

  if(info.evaluation.actionScore){
    state.level.currentExp += info.evaluation.actionScore
    state.message = `You gained ${info.evaluation.actionScore}xp because ` + lowercaseFirstLetter(info.evaluation.reason.substring(9))
  }


  if (state.level.currentExp >= state.level.expReq){
    state.level.player++
    state.level.currentExp -= state.level.expReq
    state.level.expReq = Math.round(state.level.expReq*1.35)
    state.skillPoints += 1
    state.message += `\nYou've leveled up! You're now level ${state.level.player}! Congrats!`
  }

  if(state.level.player == 2 && state.set.lvlTracker == 1){
    state.set.lvlTracker++
    state.event.familiar = true
  }

  if(getRandomInt(3) == 2 && state.event.familiar == true){
    state.event.familiar = false
    modifiedText = "\nA small shimmering portal suddenly appears above you. It only lasts a moment, dropping a thick envelope into your hands before disappearing. The envelope contains a note and a spell scroll.\nThe note reads \"Congratulations on your academic progress! Here at Universitas Arcanorum, we know that no-one should study magic alone. So, enjoy this scroll of Find Familiar.\nBest regards,\nUniversitas Arcanorum staff.\""
  }


  if(modifiedText.toLowerCase().includes("familiar") && modifiedText.toLowerCase().includes("summon") && !state.event.familiarComplete){
    state.set.familiarMatch = true
  }

  if(state.set.familiarMatch == true){
    var string = modifiedText.toLowerCase()
    if(/bat|cat|frog|toad|crab|hawk|lizard|octopus|owl|snake|fish|rat|mouse|raven|seahorse|spider|weasel|fox|pseudodragon/.exec(string)){
      state.familiar.type = /bat|cat|frog|toad|crab|hawk|lizard|octopus|owl|snake|fish|rat|mouse|raven|seahorse|spider|weasel|fox|pseudodragon/.exec(string)[0]
      for(var i = 0; i < worldInfo.length; i++){
        if(worldInfo[`${i}`].keys.includes("⚘")){
          worldInfo[`${i}`].entry = `You can update your familiar type and name here.\nFamiliar Type: ${state.familiar.type} ⚘\nFamiliar Name: none ⚜`
        }
      }
      state.event.familiarComplete = true
      state.set.familiarMatch = false
  }
}


  return { text: modifiedText }
  }

modifier(text)
const modifier = (text) => {
  
  const contextMemory = info.memoryLength ? text.slice(0, info.memoryLength) : ''
  const context = info.memoryLength ? text.slice(info.memoryLength) : text
  const lines = context.split("\n")
  state.evaluationBot = 'KillBot'

  if (lines.length > 3) {
     lines.splice(-4, 0, `${state.character.note}`)
  }

  const combinedLines = lines.join("\n").slice(-(info.maxChars - info.memoryLength))
  const finalText = [contextMemory, combinedLines].join("")
  
  return { text: finalText }
}

modifier(text)
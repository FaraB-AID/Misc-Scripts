const modifier = (text) => {
  var newtext = text

  if(text.includes("⚚ Spellbook")){
    state.set.bookStart = text.match(/⚚ Spellbook/) ? text.match(/⚚ Spellbook/).index : 0
    state.set.bookEnd = text.match(/Spellbook ⚚/) ? text.match(/Spellbook ⚚/).index + 11 : 0
    state.set.tog = 1
  }
  newtext = newtext.substr(0,state.set.bookStart) + newtext.substr(state.set.bookEnd)

  const contextMemory = info.memoryLength ? newtext.slice(0, info.memoryLength) : ''
  const context = info.memoryLength ? newtext.slice(info.memoryLength) : newtext
  const lines = context.split("\n")
  state.evaluationBot = 'KillBot'

  if(lines.length > 3) {
     lines.splice(-4, 0, `${state.character.note}`)
  }

  if(state.set.tog == 1){
    if(lines.length > 3) {
      lines.splice(-4, 0, `${state.character.spellsNote}`)
    }
  state.set.tog == 0
    } 




  const combinedLines = lines.join("\n").slice(-(info.maxChars - info.memoryLength))
  var finalText = [contextMemory, combinedLines].join("")
  return { text: finalText }
}

modifier(text)
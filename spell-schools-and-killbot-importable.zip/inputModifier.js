const modifier = (text) => {    
  let modifiedText = text
  stop = false  
  const lowered = text.toLowerCase()

  function getRandomInt(max) {
    return Math.floor(Math.random() * Math.floor(max));
  } 
  
  if(!state.setup){
    state.setup = true
    state.character = {note:"", spellsKnown: [], spellsNote: ""}
    state.skills = {'Abjuration': 0, 'Conjuration': 0, 'Divination': 0, 'Enchantment': 0, 'Evocation': 0, 'Illusion': 0, 'Necromancy': 0, 'Transmutation': 0}
    state.skillTerms = ["incapable", "unskilled", "neophyte", "novice", "apprentice", "journeyman", "adept", "expert", "master", "grandmaster", "super grandmaster", "super grandmaster", "super grandmaster", "super grandmaster", "super grandmaster", "super grandmaster"]
    state.skillPoints = 0
    state.disableRandomSkill = true
    state.level= {expReq : 40, currentExp : 0, player : 1} 
    for (i in state.skills){
      if(getRandomInt(4) == 3){
        state.skills[`${i}`] += 1
      }
    }
    state.spells = {}
    state.spells.wizard = [{level: 0, name: "Blade Ward", school: "Abjuration"},
    {level: 0, name: "Chill Touch", school: "Necromancy"},
    {level: 0, name: "Create Bonfire", school: "Conjuration"},
    {level: 0, name: "Friends", school: "Enchantment"},
    {level: 0, name: "Fire Bolt", school: "Evocation"},
    {level: 0, name: "Gust", school: "Transmutation"},
    {level: 0, name: "Light", school: "Evocation"},
    {level: 0, name: "Mage Hand", school: "Conjuration"},
    {level: 0, name: "Mending", school: "Transmutation"},
    {level: 0, name: "Minor Illusion", school: "Illusion"},
    {level: 0, name: "Poison Spray", school: "Conjuration"},
    {level: 0, name: "Prestidigitation", school: "Transmutation"},
    {level: 0, name: "Shocking Grasp", school: "Evocation"},
    {level: 1, name: "Absorb Elements", school: "Abjuration"},
    {level: 1, name: "Burning Hands", school: "Evocation"},
    {level: 1, name: "Catapult", school: "Transmutation"},
    {level: 1, name: "Cause Fear", school: "Necromancy"},
    {level: 1, name: "Charm Person", school: "Enchantment"},
    {level: 1, name: "Chromatic Orb", school: "Evocation"},
    {level: 1, name: "Color Spray", school: "Illusion"},
    {level: 1, name: "Detect Magic", school: "Divination"},
    {level: 1, name: "Disguise Self", school: "Illusion"},
    {level: 1, name: "Expeditious Retreat", school: "Transmutation"},
    {level: 1, name: "Feather Fall", school: "Transmutation"},
    {level: 1, name: "Find Familiar", school: "Conjuration"},
    {level: 1, name: "Fog Cloud", school: "Conjuration"},
    {level: 1, name: "Grease", school: "Conjuration"},
    {level: 1, name: "Identify", school: "Divination"},
    {level: 1, name: "Jump", school: "Transmutation"},
    {level: 1, name: "Mage Armor", school: "Abjuration"},
    {level: 1, name: "Magic Missile", school: "Evocation"},
    {level: 1, name: "Protection from Evil and Good", school: "Abjuration"},
    {level: 1, name: "Ray of Sickness", school: "Necromancy"},
    {level: 1, name: "Shield", school: "Abjuration"},
    {level: 1, name: "Silent Image", school: "Illusion"},
    {level: 1, name: "Sleep", school: "Enchantment"},
    {level: 2, name: "Alter Self", school: "Transmutation"},
    {level: 2, name: "Arcane Lock", school: "Abjuration"},
    {level: 2, name: "Barkskin", school: "Transmutation"},
    {level: 2, name: "Blindness", school: "Necromancy"},
    {level: 2, name: "Blur", school: "Illusion"},
    {level: 2, name: "Crown of Madness", school: "Enchantment"},
    {level: 2, name: "Darkness", school: "Evocation"},
    {level: 2, name: "Darkvision", school: "Transmutation"},
    {level: 2, name: "Detect Thoughts", school: "Divination"},
    {level: 2, name: "Earthbind", school: "Transmutation"},
    {level: 2, name: "Enlarge/Reduce", school: "Transmutation"},
    {level: 2, name: "Flaming Sphere", school: "Conjuration"},
    {level: 2, name: "Hold Person", school: "Enchantment"},
    {level: 2, name: "Invisibility", school: "Illusion"},
    {level: 2, name: "Knock", school: "Transmutation"},
    {level: 2, name: "Levitate", school: "Transmutation"},
    {level: 2, name: "Magic Weapon", school: "Transmutation"},
    {level: 2, name: "Earthen Grasp", school: "Transmutation"},
    {level: 2, name: "Acid Arrow", school: "Evocation"},
    {level: 2, name: "Mind Spike", school: "Divination"},
    {level: 2, name: "Mirror Image", school: "Illusion"},
    {level: 2, name: "Misty Step", school: "Conjuration"},
    {level: 2, name: "Phantasmal Force", school: "Illusion"},
    {level: 2, name: "Ray of Enfeeblement", school: "Necromancy"},
    {level: 2, name: "Rope Trick", school: "Transmutation"},
    {level: 2, name: "Scorching Ray", school: "Evocation"},
    {level: 2, name: "Shatter", school: "Evocation"},
    {level: 2, name: "Spider Climb", school: "Transmutation"},
    {level: 2, name: "Suggestion", school: "Enchantment"},
    {level: 2, name: "Web", school: "Conjuration"},
    {level: 3, name: "Animate Dead", school: "Necromancy"},
    {level: 3, name: "Bestow Curse", school: "Necromancy"},
    {level: 3, name: "Blink", school: "Transmutation"},
    {level: 3, name: "Clairvoyance", school: "Divination"},
    {level: 3, name: "Counterspell", school: "Abjuration"},
    {level: 3, name: "Dispel Magic", school: "Abjuration"},
    {level: 3, name: "Erupting Earth", school: "Transmutation"},
    {level: 3, name: "Fear", school: "Illusion"},
    {level: 3, name: "Fireball", school: "Evocation"},
    {level: 3, name: "Flame Arrows", school: "Transmutation"},
    {level: 3, name: "Fly", school: "Transmutation"},
    {level: 3, name: "Glyph of Warding", school: "Abjuration"},
    {level: 3, name: "Haste", school: "Transmutation"},
    {level: 3, name: "Hypnotic Pattern", school: "Illusion"},
    {level: 3, name: "Lightning Bolt", school: "Evocation"},
    {level: 3, name: "Magic Circle", school: "Abjuration"},
    {level: 3, name: "Major Image", school: "Illusion"},
    {level: 3, name: "Sleet Storm", school: "Conjuration"},
    {level: 3, name: "Slow", school: "Transmutation"},
    {level: 3, name: "Stinking Cloud", school: "Conjuration"},
    {level: 3, name: "Tidal Wave", school: "Conjuration"},
    {level: 3, name: "Vampiric Touch", school: "Necromancy"},
    {level: 3, name: "Wall of Sand", school: "Evocation"},
    {level: 3, name: "Water Breathing", school: "Transmutation"},
    {level: 3, name: "Conjure Elemental", school: "Conjuration"},
    {level: 4, name: "Arcane Eye", school: "Divination"},
    {level: 4, name: "Banishment", school: "Abjuration"},
    {level: 4, name: "Blight", school: "Necromancy"},
    {level: 4, name: "Charm Monster", school: "Enchantment"},
    {level: 4, name: "Confusion", school: "Enchantment"},
    {level: 4, name: "Control Water", school: "Transmutation"},
    {level: 4, name: "Dimension Door", school: "Conjuration"},
    {level: 4, name: "Fire Shield", school: "Evocation"},
    {level: 4, name: "Greater Invisibility", school: "Illusion"},
    {level: 4, name: "Ice Storm", school: "Evocation"},
    {level: 4, name: "Locate Creature", school: "Divination"},
    {level: 4, name: "Phantasmal Killer", school: "Illusion"},
    {level: 4, name: "Polymorph", school: "Transmutation"},
    {level: 4, name: "Stoneskin", school: "Abjuration"},
    {level: 4, name: "Summon Demon", school: "Conjuration"},
    {level: 4, name: "Vitriolic Sphere", school: "Evocation"},
    {level: 4, name: "Wall of Fire", school: "Evocation"},
    {level: 4, name: "Watery Sphere", school: "Conjuration"},
    {level: 5, name: "Bigby's Hand", school: "Evocation"},
    {level: 5, name: "Cloudkill", school: "Conjuration"},
    {level: 5, name: "Cone of Cold", school: "Evocation"},
    {level: 5, name: "Conjure Elemental", school: "Conjuration"},
    {level: 5, name: "Control Winds", school: "Transmutation"},
    {level: 5, name: "Dominate Person", school: "Enchantment"},
    {level: 5, name: "Dream", school: "Illusion"},
    {level: 5, name: "Enervation", school: "Necromancy"},
    {level: 5, name: "Geas", school: "Enchantment"},
    {level: 5, name: "Hold Monster", school: "Enchantment"},
    {level: 5, name: "Negative Energy Field", school: "Necromancy"},
    {level: 5, name: "Scrying", school: "Divination"},
    {level: 5, name: "Seeming", school: "Illusion"},
    {level: 5, name: "Telekinesis", school: "Transmutation"},
    {level: 5, name: "Teleportation Circle", school: "Conjuration"},
    {level: 5, name: "Transmute Rock", school: "Transmutation"},
    {level: 5, name: "Wall of Force", school: "Evocation"},
    {level: 6, name: "Chain Lightning", school: "Evocation"},
    {level: 6, name: "Circle of Death", school: "Necromancy"},
    {level: 6, name: "Create Undead", school: "Necromancy"},
    {level: 6, name: "Disintegrate", school: "Transmutation"},
    {level: 6, name: "Eyebite", school: "Necromancy"},
    {level: 6, name: "Flesh to Stone", school: "Transmutation"},
    {level: 6, name: "Globe of Invulnerability", school: "Abjuration"},
    {level: 6, name: "Mass Suggestion", school: "Enchantment"},
    {level: 6, name: "Mental Prison", school: "Illusion"},
    {level: 6, name: "Move Earth", school: "Transmutation"},
    {level: 6, name: "Sunbeam", school: "Evocation"},
    {level: 6, name: "True Seeing", school: "Divination"},
    {level: 6, name: "Wall of Ice", school: "Evocation"},
    {level: 7, name: "Etherealness", school: "Transmutation"},
    {level: 7, name: "Finger of Death", school: "Necromancy"},
    {level: 7, name: "Forcecage", school: "Evocation"},
    {level: 7, name: "Mirage Arcane", school: "Illusion"},
    {level: 7, name: "Plane Shift", school: "Conjuration"},
    {level: 7, name: "Prismatic Spray", school: "Evocation"},
    {level: 7, name: "Reverse Gravity", school: "Transmutation"},
    {level: 7, name: "Teleport", school: "Conjuration"},
    {level: 7, name: "Whirlwind", school: "Evocation"},
    {level: 8, name: "Antimagic Field", school: "Abjuration"},
    {level: 8, name: "Control Weather", school: "Transmutation"},
    {level: 8, name: "Demiplane", school: "Conjuration"},
    {level: 8, name: "Dominate Monster", school: "Enchantment"},
    {level: 8, name: "Feeblemind", school: "Enchantment"},
    {level: 8, name: "Illusory Dragon", school: "Illusion"},
    {level: 8, name: "Incendiary Cloud", school: "Conjuration"},
    {level: 8, name: "Maddening Darkness", school: "Evocation"},
    {level: 8, name: "Maze", school: "Conjuration"},
    {level: 8, name: "Mind Blank", school: "Abjuration"},
    {level: 8, name: "Sunburst", school: "Evocation"},
    {level: 9, name: "Astral Projection", school: "Necromancy"},
    {level: 9, name: "Foresight", school: "Divination"},
    {level: 9, name: "Gate", school: "Conjuration"},
    {level: 9, name: "Invulnerability", school: "Abjuration"},
    {level: 9, name: "Mass Polymorph", school: "Transmutation"},
    {level: 9, name: "Meteor Swarm", school: "Evocation"},
    {level: 9, name: "Power Word Kill", school: "Enchantment"},
    {level: 9, name: "Prismatic Wall", school: "Abjuration"},
    {level: 9, name: "Psychic Scream", school: "Enchantment"},
    {level: 9, name: "Time Stop", school: "Transmutation"},
    {level: 9, name: "True Polymorph", school: "Transmutation"},
    {level: 9, name: "Weird", school: "Illusion"},
    {level: 9, name: "Wish", school: "Conjuration"}]
  }

  if(!state.checkClass){
    for(i in state.skills){
      if(lowered.includes("school is " + `${i}`.toLowerCase())){
        state.skills[`${i}`] += 2
      }
    }

    state.checkClass = true
  }

  state.message = ""
  
  state.character.note = "[ you skills:"
  for(i in state.skills){
    if(state.skills[`${i}`]){
      state.character.note += `< ` + `${i}`.toLowerCase() + `≡ ${state.skillTerms[`${state.skills[`${i}`]}`]}>.\n`      
    }
  }
  state.character.note = state.character.note.slice(0, -1)
  state.character.note += "]"  
  
  state.character.spellsKnown = []
  for (var i = 0; i < state.spells.wizard.length; i++){
    x = state.spells.wizard
    if(state.skills[`${x[`${i}`].school}`] > x[`${i}`].level) {
      state.character.spellsKnown.push(x[`${i}`])
    }
  }

  state.character.spellsNote = "[ you powers:"
  for(var i in state.skills){
    var x = state.character
    if(state.skills[`${i}`] >= 1){
      x.spellsNote += "< " + `${i}`.toLowerCase() + " spells≡"
      for(var ii = 0; ii < x.spellsKnown.length; ii++){
        if (x.spellsKnown[`${ii}`].school == `${i}`) {
          x.spellsNote += ` ${x.spellsKnown[`${ii}`].name}&`
        }
      }
      x.spellsNote = x.spellsNote.slice(0, -1)
      x.spellsNote += ">.\n"
    }
  }
  state.character.spellsNote = state.character.spellsNote.slice(0, -1)
  state.character.spellsNote += "]"

  updateWorldEntry(Number(worldInfo[0].id), "spellbook, spells, spell list, list of spells, castable", state.character.spellsNote, isNotHidden = true)
  
  if(lowered.includes("/cheat")){
    state.skillPoints += 100
    text = null; stop = true; return{ text, stop }
  }

  if(lowered.includes("/level")){
    state.message = `Current level: ${state.level.player}. Experience required for next level: ` + (state.level.expReq - state.level.currentExp)
    text = null; stop = true; return{ text, stop }
  }

    return ({text})
  }

modifier(text)
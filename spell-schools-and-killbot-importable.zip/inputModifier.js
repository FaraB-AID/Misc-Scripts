const modifier = (text) => {    
  let modifiedText = text
  stop = false  
  const lowered = text.toLowerCase()

  function getRandomInt(max) {
    return Math.floor(Math.random() * Math.floor(max));
  } 
  
  if(!state.setup){
    state.setup = true
    state.character = {note:""}
    state.skills = {'Abjuration': 0, 'Conjuration': 0, 'Divination': 0, 'Enchantment': 0, 'Evocation': 0, 'Illusion': 0, 'Necromancy': 0, 'Transmutation': 0}
    state.skillTerms = ["incapable", "unskilled", "neophyte", "novice", "apprentice", "journeyman", "adept", "expert", "master", "grandmaster", "super grandmaster", "super grandmaster", "super grandmaster", "super grandmaster", "super grandmaster", "super grandmaster"]
    state.skillPoints = 0
    state.disableRandomSkill = true
    state.level= {expReq : 100, currentExp : 0, player : 1} 
    for (i in state.skills){
      if(getRandomInt(3) == 2){
        state.skills[`${i}`] += (getRandomInt(2) + 1)
      }
    }
  }

  if(!state.checkClass){
    for(i in state.skills){
      if(lowered.includes("school is " + `${i}`.toLowerCase())){
        state.skills[`${i}`] += 2
      }
    }

    state.checkClass = true
  }

  state.message = ""
  
  state.character.note = "[ you skills:"
  for(i in state.skills){
    if(state.skills[`${i}`]){
      state.character.note += `< ` + `${i}`.toLowerCase() + `≡ ${state.skillTerms[`${state.skills[`${i}`]}`]}>.\n`      
    }
  }
  state.character.note = state.character.note.slice(0, -1)
  state.character.note += "]"  
  
  
  if(lowered.includes("/cheat")){
    state.skillPoints += 100
    text = null; stop = true; return{ text, stop }
  }


    return ({text})
  }

modifier(text)
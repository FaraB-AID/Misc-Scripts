function getRandomInt(max) {
  return Math.floor(Math.random() * Math.floor(max));
} 

function toTitleCase(str) {
  return str.replace(
    /\w\S*/g,
    function(txt) {
      return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
    }
  );
}
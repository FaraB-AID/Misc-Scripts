const modifier = (text) => {    
  let modifiedText = text
  stop = false  
  const lowered = text.toLowerCase()

  function getRandomInt(max) {
    return Math.floor(Math.random() * Math.floor(max));
  } 
  
  if(!state.setup){
    state.setup = true
    state.character = {}
    state.stats = {stats:{Strength:{level: 8, cost:1, terms:["dead", "feeble", "feeble", "weak", "weak", "average", "strong", "great", "mighty", "extreme", "overwhelming", "superhuman", "superhuman", "superhuman", "superhuman", "superhuman", "godly", "godly", "godly", "godly", "godly"]}, Dexterity:{level: 8, cost:1, terms:["dead", "paralyzed", "paralyzed", "clumsy", "clumsy", "average", "spry", "quick", "nimble", "graceful", "untouchable", "superhuman", "superhuman", "superhuman", "superhuman", "superhuman", "godly", "godly", "godly", "godly", "godly"]}, Constitution:{level: 8, cost:1, terms:["dead", "comatose", "sickly", "frail", "frail", "average", "hale", "hearty", "rugged", "tireless", "indefagitable", "superhuman", "superhuman", "superhuman", "superhuman", "superhuman", "godly", "godly", "godly", "godly", "godly"]}, Intelligence:{level: 8, cost:1, terms:["dead", "simple", "simple", "dull", "dull", "average", "learned", "bright", "enlightened", "genius", "supergenius", "superhuman", "superhuman", "superhuman", "superhuman", "superhuman", "godly", "godly", "godly", "godly", "godly"]}, Wisdom:{level: 8, cost:1, terms:["dead", "thoughtless", "thoughtless", "foolish", "foolish", "average", "thoughtful", "perceptive", "insightful", "visionary", "prescient", "superhuman", "superhuman", "superhuman", "superhuman", "superhuman", "godly", "godly", "godly", "godly", "godly"]}, Charisma:{level: 8, cost:1, terms:["dead", "repulisive", "repulsive", "obnoxious", "obnoxious", "average", "genial", "persuasive", "inspiring", "captivating", "mesmerizing", "superhuman", "superhuman", "superhuman", "superhuman", "superhuman", "godly", "godly", "godly", "godly", "godly"]},}, statPoints:0}
    state.level= {expReq : 100, currentExp : 0, player : 1} 
    for (i in state.stats.stats){
      state.stats.stats[`${i}`].level += getRandomInt(4)
    }
  }

  if(!state.checkClass){
    var x = state.stats.stats
    if(text.match(/(?<=profession: )(rogue|thief|ninja|sneak)/i)) {
      x.Dexterity += 4
      x.Intelligence +=2
      x.Strength -= 2
      x.Wisdom -=2
    }
    if(text.match(/(?<=profession: )(fighter|warrior|gladiator|combat)/i)) {
      x.Strength += 4
      x.Constitution += 2
      x.Intelligence -=2
      x.Charisma -=2
    }

    state.checkClass = true
  }


  state.message = ""

  var strengthTerm = state.stats.stats.Strength.terms[Math.round(state.stats.stats.Strength.level/2)]
  var dexterityTerm = state.stats.stats.Dexterity.terms[Math.round(state.stats.stats.Dexterity.level/2)]
  var constitutionTerm = state.stats.stats.Constitution.terms[Math.round(state.stats.stats.Constitution.level/2)]
  var intelligenceTerm = state.stats.stats.Intelligence.terms[Math.round(state.stats.stats.Intelligence.level/2)]
  var wisdomTerm = state.stats.stats.Wisdom.terms[Math.round(state.stats.stats.Wisdom.level/2)]
  var charismaTerm = state.stats.stats.Charisma.terms[Math.round(state.stats.stats.Charisma.level/2)]

  state.character.note = `[ you ability scores:< STR≡ ${strengthTerm}>.\n< DEX≡ ${dexterityTerm}>.\n< CON≡ ${constitutionTerm}>.\n< INT≡ ${intelligenceTerm}>.\n< WIS≡ ${wisdomTerm}>.\n< CHA≡ ${charismaTerm}>.]`

  if(lowered.includes("/cheat")){
    state.stats.statPoints += 100
    text = null; stop = true; return{ text, stop }
  }


    return ({text})
  }

modifier(text)
const modifier = (text) => {
  const contextMemory = info.memoryLength ? text.slice(0, info.memoryLength) : ''
  const context = info.memoryLength ? text.slice(info.memoryLength) : text
  const lines = context.split("\n")

  if(cot1Action && info.actionCount >= cot1Action && info.actionCount < cot2Check){
    if(cot1Float){
      if(lines.length > cot1FloatDist) {
        lines.splice((-(cot1FloatDist) -1), 0, cot1Float)
      }
    }
    if(cot1EN && info.actionCount <= (cot1Action + cot1ENDur)){
      lines.push(`[Editor's note: ${cot1EN}.]`)
    }
  }

  if(cot2Action && info.actionCount >= cot2Action && info.actionCount < cot3Check){
    if(cot2Float){
      if(lines.length > cot2FloatDist) {
        lines.splice((-(cot2FloatDist) -1), 0, cot2Float)
      }
    }
    if(cot2EN && info.actionCount <= (cot2Action + cot2ENDur)){
      lines.push(`[Editor's note: ${cot2EN}.]`)
    }
  }

  if(cot3Action && info.actionCount >= cot3Action && info.actionCount < cot4Check){
    if(cot3Float){
      if(lines.length > cot3FloatDist) {
        lines.splice((-(cot3FloatDist) -1), 0, cot3Float)
      }
    }
    if(cot3EN && info.actionCount <= (cot3Action + cot3ENDur)){
      lines.push(`[Editor's note: ${cot3EN}.]`)
    }
  }

  if(cot4Action && info.actionCount >= cot4Action && info.actionCount < cot5Check){
    if(cot4Float){
      if(lines.length > cot4FloatDist) {
        lines.splice((-(cot4FloatDist) -1), 0, cot4Float)
      }
    }
    if(cot4EN && info.actionCount <= (cot4Action + cot4ENDur)){
      lines.push(`[Editor's note: ${cot4EN}.]`)
    }
  }

  if(cot5Action && info.actionCount >= cot5Action && info.actionCount < cot6Check){
    if(cot5Float){
      if(lines.length > cot5FloatDist) {
        lines.splice((-(cot5FloatDist) -1), 0, cot5Float)
      }
    }
    if(cot5EN && info.actionCount <= (cot5Action + cot5ENDur)){
      lines.push(`[Editor's note: ${cot5EN}.]`)
    }
  }

  if(cot6Action && info.actionCount >= cot6Action && info.actionCount < cot7Check){
    if(cot6Float){
      if(lines.length > cot6FloatDist) {
        lines.splice((-(cot6FloatDist) -1), 0, cot6Float)
      }
    }
    if(cot6EN && info.actionCount <= (cot6Action + cot6ENDur)){
      lines.push(`[Editor's note: ${cot6EN}.]`)
    }
  }

  if(cot7Action && info.actionCount >= cot7Action && info.actionCount < cot8Check){
    if(cot7Float){
      if(lines.length > cot7FloatDist) {
        lines.splice((-(cot7FloatDist) -1), 0, cot7Float)
      }
    }
    if(cot7EN && info.actionCount <= (cot7Action + cot7ENDur)){
      lines.push(`[Editor's note: ${cot7EN}.]`)
    }
  }

  if(cot8Action && info.actionCount >= cot8Action && info.actionCount < cot9Check){
    if(cot8Float){
      if(lines.length > cot8FloatDist) {
        lines.splice((-(cot8FloatDist) -1), 0, cot8Float)
      }
    }
    if(cot8EN && info.actionCount <= (cot8Action + cot8ENDur)){
      lines.push(`[Editor's note: ${cot8EN}.]`)
    }
  }

  if(cot9Action && info.actionCount >= cot9Action && info.actionCount < cot10Check){
    if(cot9Float){
      if(lines.length > cot9FloatDist) {
        lines.splice((-(cot9FloatDist) -1), 0, cot9Float)
      }
    }
    if(cot9EN && info.actionCount <= (cot9Action + cot9ENDur)){
      lines.push(`[Editor's note: ${cot9EN}.]`)
    }
  }

  if(cot10Action && info.actionCount >= cot10Action){
    if(cot10Float){
      if(lines.length > cot10FloatDist) {
        lines.splice((-(cot10FloatDist) -1), 0, cot10Float)
      }
    }
    if(cot10EN && info.actionCount <= (cot10Action + cot10ENDur)){
      lines.push(`[Editor's note: ${cot10EN}.]`)
    }
  }

  if(!state.inputHappened){
    if(cot1Action && info.actionCount < cot1Action){
      state.memory.context = ""
      state.memory.authorsNote = ""
      worldInfo = state.initialWI
    }
    if(cot1Action && info.actionCount >= cot1Action && info.actionCount < cot2Check){
      if(cot1Memory){
        state.memory.context = cot1Memory
      }
      if(cot1AN){
        state.memory.authorsNote = cot1AN
      }
      var cotWIKeys = [cot1WIKey10, cot1WIKey9, cot1WIKey8, cot1WIKey7, cot1WIKey6, cot1WIKey5, cot1WIKey4, cot1WIKey3, cot1WIKey2, cot1WIKey1]
      var cotWIEntries = [cot1WIEntry10, cot1WIEntry9, cot1WIEntry8, cot1WIEntry7, cot1WIEntry6, cot1WIEntry5, cot1WIEntry4, cot1WIEntry3, cot1WIEntry2, cot1WIEntry1]
      for(i = 0; i < cotWIKeys.length; i++){
        if(cotWIKeys[i]){
          worldInfo.shift()
        }
      }
      for(i = 0; i < cotWIKeys.length; i++){
        if(cotWIKeys[i]){
          var tempWI = {"id": `${Math.random()}`, "keys": cotWIKeys[i], "entry": cotWIEntries[i], "hidden": false}
          worldInfo.unshift(tempWI)
        }
      }
    }
  
    if(cot2Action && info.actionCount >= cot2Action && info.actionCount < cot3Check){
      if(cot2Memory){
        state.memory.context = cot2Memory
      }
      if(cot2AN){
        state.memory.authorsNote = cot2AN
      }
      var cotWIKeys = [cot2WIKey10, cot2WIKey9, cot2WIKey8, cot2WIKey7, cot2WIKey6, cot2WIKey5, cot2WIKey4, cot2WIKey3, cot2WIKey2, cot2WIKey1]
      var cotWIEntries = [cot2WIEntry10, cot2WIEntry9, cot2WIEntry8, cot2WIEntry7, cot2WIEntry6, cot2WIEntry5, cot2WIEntry4, cot2WIEntry3, cot2WIEntry2, cot2WIEntry1]
      for(i = 0; i < cotWIKeys.length; i++){
        if(cotWIKeys[i]){
          worldInfo.shift()
        }
      }
      for(i = 0; i < cotWIKeys.length; i++){
        if(cotWIKeys[i]){
          var tempWI = {"id": `${Math.random()}`, "keys": cotWIKeys[i], "entry": cotWIEntries[i], "hidden": false}
          worldInfo.unshift(tempWI)
        }
      }
    }
  
    if(cot3Action && info.actionCount >= cot3Action && info.actionCount < cot4Check){
      if(cot3Memory){
        state.memory.context = cot3Memory
      }
      if(cot3AN){
        state.memory.authorsNote = cot3AN
      }
      var cotWIKeys = [cot3WIKey10, cot3WIKey9, cot3WIKey8, cot3WIKey7, cot3WIKey6, cot3WIKey5, cot3WIKey4, cot3WIKey3, cot3WIKey2, cot3WIKey1]
      var cotWIEntries = [cot3WIEntry10, cot3WIEntry9, cot3WIEntry8, cot3WIEntry7, cot3WIEntry6, cot3WIEntry5, cot3WIEntry4, cot3WIEntry3, cot3WIEntry2, cot3WIEntry1]
      for(i = 0; i < cotWIKeys.length; i++){
        if(cotWIKeys[i]){
          worldInfo.shift()
        }
      }
      for(i = 0; i < cotWIKeys.length; i++){
        if(cotWIKeys[i]){
          var tempWI = {"id": `${Math.random()}`, "keys": cotWIKeys[i], "entry": cotWIEntries[i], "hidden": false}
          worldInfo.unshift(tempWI)
        }
      }
    }
  
    if(cot4Action && info.actionCount >= cot4Action && info.actionCount < cot5Check){
      if(cot4Memory){
        state.memory.context = cot4Memory
      }
      if(cot4AN){
        state.memory.authorsNote = cot4AN
      }
      var cotWIKeys = [cot4WIKey10, cot4WIKey9, cot4WIKey8, cot4WIKey7, cot4WIKey6, cot4WIKey5, cot4WIKey4, cot4WIKey3, cot4WIKey2, cot4WIKey1]
      var cotWIEntries = [cot4WIEntry10, cot4WIEntry9, cot4WIEntry8, cot4WIEntry7, cot4WIEntry6, cot4WIEntry5, cot4WIEntry4, cot4WIEntry3, cot4WIEntry2, cot4WIEntry1]
      for(i = 0; i < cotWIKeys.length; i++){
        if(cotWIKeys[i]){
          worldInfo.shift()
        }
      }
      for(i = 0; i < cotWIKeys.length; i++){
        if(cotWIKeys[i]){
          var tempWI = {"id": `${Math.random()}`, "keys": cotWIKeys[i], "entry": cotWIEntries[i], "hidden": false}
          worldInfo.unshift(tempWI)
        }
      }
    }
  
    if(cot5Action && info.actionCount >= cot5Action && info.actionCount < cot6Check){
      if(cot5Memory){
        state.memory.context = cot5Memory
      }
      var cotWIKeys = [cot5WIKey10, cot5WIKey9, cot5WIKey8, cot5WIKey7, cot5WIKey6, cot5WIKey5, cot5WIKey4, cot5WIKey3, cot5WIKey2, cot5WIKey1]
      var cotWIEntries = [cot5WIEntry10, cot5WIEntry9, cot5WIEntry8, cot5WIEntry7, cot5WIEntry6, cot5WIEntry5, cot5WIEntry4, cot5WIEntry3, cot5WIEntry2, cot5WIEntry1]
      for(i = 0; i < cotWIKeys.length; i++){
        if(cotWIKeys[i]){
          worldInfo.shift()
        }
      }
      for(i = 0; i < cotWIKeys.length; i++){
        if(cotWIKeys[i]){
          var tempWI = {"id": `${Math.random()}`, "keys": cotWIKeys[i], "entry": cotWIEntries[i], "hidden": false}
          worldInfo.unshift(tempWI)
        }
      }
    }
  
    if(cot6Action && info.actionCount >= cot6Action && info.actionCount < cot7Check){
      if(cot6Memory){
        state.memory.context = cot6Memory
      }
      if(cot6AN){
        state.memory.authorsNote = cot6AN
      }
      var cotWIKeys = [cot6WIKey10, cot6WIKey9, cot6WIKey8, cot6WIKey7, cot6WIKey6, cot6WIKey5, cot6WIKey4, cot6WIKey3, cot6WIKey2, cot6WIKey1]
      var cotWIEntries = [cot6WIEntry10, cot6WIEntry9, cot6WIEntry8, cot6WIEntry7, cot6WIEntry6, cot6WIEntry5, cot6WIEntry4, cot6WIEntry3, cot6WIEntry2, cot6WIEntry1]
      for(i = 0; i < cotWIKeys.length; i++){
        if(cotWIKeys[i]){
          worldInfo.shift()
        }
      }
      for(i = 0; i < cotWIKeys.length; i++){
        if(cotWIKeys[i]){
          var tempWI = {"id": `${Math.random()}`, "keys": cotWIKeys[i], "entry": cotWIEntries[i], "hidden": false}
          worldInfo.unshift(tempWI)
        }
      }
    }
  
    if(cot7Action && info.actionCount >= cot7Action && info.actionCount < cot8Check){
      if(cot7Memory){
        state.memory.context = cot7Memory
      }
      if(cot7AN){
        state.memory.authorsNote = cot7AN
      }
      var cotWIKeys = [cot7WIKey10, cot7WIKey9, cot7WIKey8, cot7WIKey7, cot7WIKey6, cot7WIKey5, cot7WIKey4, cot7WIKey3, cot7WIKey2, cot7WIKey1]
      var cotWIEntries = [cot7WIEntry10, cot7WIEntry9, cot7WIEntry8, cot7WIEntry7, cot7WIEntry6, cot7WIEntry5, cot7WIEntry4, cot7WIEntry3, cot7WIEntry2, cot7WIEntry1]
      for(i = 0; i < cotWIKeys.length; i++){
        if(cotWIKeys[i]){
          worldInfo.shift()
        }
      }
      for(i = 0; i < cotWIKeys.length; i++){
        if(cotWIKeys[i]){
          var tempWI = {"id": `${Math.random()}`, "keys": cotWIKeys[i], "entry": cotWIEntries[i], "hidden": false}
          worldInfo.unshift(tempWI)
        }
      }
    }
  
    if(cot8Action && info.actionCount >= cot8Action && info.actionCount < cot9Check){
      if(cot8Memory){
        state.memory.context = cot8Memory
      }
      if(cot8AN){
        state.memory.authorsNote = cot8AN
      }
      var cotWIKeys = [cot8WIKey10, cot8WIKey9, cot8WIKey8, cot8WIKey7, cot8WIKey6, cot8WIKey5, cot8WIKey4, cot8WIKey3, cot8WIKey2, cot8WIKey1]
      var cotWIEntries = [cot8WIEntry10, cot8WIEntry9, cot8WIEntry8, cot8WIEntry7, cot8WIEntry6, cot8WIEntry5, cot8WIEntry4, cot8WIEntry3, cot8WIEntry2, cot8WIEntry1]
      for(i = 0; i < cotWIKeys.length; i++){
        if(cotWIKeys[i]){
          worldInfo.shift()
        }
      }
      for(i = 0; i < cotWIKeys.length; i++){
        if(cotWIKeys[i]){
          var tempWI = {"id": `${Math.random()}`, "keys": cotWIKeys[i], "entry": cotWIEntries[i], "hidden": false}
          worldInfo.unshift(tempWI)
        }
      }
    }
  
    if(cot9Action && info.actionCount >= cot9Action && info.actionCount < cot10Check){
      if(cot9Memory){
        state.memory.context = cot9Memory
      }
      var cotWIKeys = [cot9WIKey10, cot9WIKey9, cot9WIKey8, cot9WIKey7, cot9WIKey6, cot9WIKey5, cot9WIKey4, cot9WIKey3, cot9WIKey2, cot9WIKey1]
      var cotWIEntries = [cot9WIEntry10, cot9WIEntry9, cot9WIEntry8, cot9WIEntry7, cot9WIEntry6, cot9WIEntry5, cot9WIEntry4, cot9WIEntry3, cot9WIEntry2, cot9WIEntry1]
      for(i = 0; i < cotWIKeys.length; i++){
        if(cotWIKeys[i]){
          worldInfo.shift()
        }
      }
      for(i = 0; i < cotWIKeys.length; i++){
        if(cotWIKeys[i]){
          var tempWI = {"id": `${Math.random()}`, "keys": cotWIKeys[i], "entry": cotWIEntries[i], "hidden": false}
          worldInfo.unshift(tempWI)
        }
      }
    }
  
    if(cot10Action && info.actionCount >= cot10Action){
      if(cot10Memory){
        state.memory.context = cot10Memory
      }
      if(cot10AN){
        state.memory.authorsNote = cot10AN
      }
      var cotWIKeys = [cot10WIKey10, cot10WIKey9, cot10WIKey8, cot10WIKey7, cot10WIKey6, cot10WIKey5, cot10WIKey4, cot10WIKey3, cot10WIKey2, cot10WIKey1]
      var cotWIEntries = [cot10WIEntry10, cot10WIEntry9, cot10WIEntry8, cot10WIEntry7, cot10WIEntry6, cot10WIEntry5, cot10WIEntry4, cot10WIEntry3, cot10WIEntry2, cot10WIEntry1]
      for(i = 0; i < cotWIKeys.length; i++){
        if(cotWIKeys[i]){
          worldInfo.shift()
        }
      }
      for(i = 0; i < cotWIKeys.length; i++){
        if(cotWIKeys[i]){
          var tempWI = {"id": `${Math.random()}`, "keys": cotWIKeys[i], "entry": cotWIEntries[i], "hidden": false}
          worldInfo.unshift(tempWI)
        }
      }
    }    
  }
 
  if (lines.length > 0) {
    if(state.set.hang){
      lines.push(state.set.hang)
    }
  }
  
  if (lines.length > 0) {
    if(state.set.em){
      lines.push(state.set.editorText)
    }
  }

  if (lines.length > 0) {
    if(state.set.tic === state.set.enTic){
      editorNote = "[Editor's note: " + state.set.en + ".]"
      lines.push(editorNote)
    }
  }


state.inputHappened = false

var currHistory = history.length ? history[(history.length -1)].text : ""
if(currHistory != state.set.prevHistory){
  state.set.tic++
}
state.set.prevHistory = history.length ? history[(history.length -1)].text : ""

const combinedLines = lines.join("\n").slice(-(info.maxChars - info.memoryLength))
const finalText = [contextMemory, combinedLines].join("")
return { text: finalText }
}

modifier(text)
const modifier = (text) => {
  const contextMemory = info.memoryLength ? text.slice(0, info.memoryLength) : ''
  const context = info.memoryLength ? text.slice(info.memoryLength) : text
  const lines = context.split("\n")
  
  if (lines.length > 0) {
    if(state.set.hang){
      lines.push(state.set.hang)
    }
  }
  
  if (lines.length > 0) {
    if(state.set.em){
      lines.push(state.set.editorText)
    }
  }

  if (lines.length > 0) {
    if(state.set.tic === state.set.enTic){
      editorNote = "[Editor's note: " + state.set.en + ".]"
      lines.push(editorNote)
    }
  }

  var currHistory = history.length ? history[(history.length -1)].text : ""
  if(currHistory != state.set.prevHistory){
    state.set.tic++
  }
  state.set.prevHistory = history.length ? history[(history.length -1)].text : ""

  const combinedLines = lines.join("\n").slice(-(info.maxChars - info.memoryLength))
  const finalText = [contextMemory, combinedLines].join("")
  return { text: finalText }
}

modifier(text)
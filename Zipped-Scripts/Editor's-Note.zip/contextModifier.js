const modifier = (text) => {
  const contextMemory = info.memoryLength ? text.slice(0, info.memoryLength) : ''
  const context = info.memoryLength ? text.slice(info.memoryLength) : text
  const lines = context.split("\n")
  
  state.message = ""

  function textInsert(distance, text){
    if(!isNaN(distance) && distance != 0){
      if(lines.length > (distance - 1)){
        lines.splice(-(distance), 0, text)
      } 
    } else {
      lines.push(text)
    }
  }

  if(state.set.en){
    if(state.set.actionCount){
      if(state.set.actionCount >= info.actionCount){
        textInsert(state.set.enDist, state.set.en)
      } else {
        state.set.actionCount = 0
        state.set.en = ""
        state.displayStats = []
      }
    } else {
      textInsert(state.set.enDist, state.set.en)
    }
  }

  if (state.set.float){
    textInsert(state.set.floatDist, state.set.float)
  }
  
  const combinedLines = lines.join("\n").slice(-(info.maxChars - info.memoryLength))
  const finalText = [contextMemory, combinedLines].join("")
  return { text: finalText }
}

modifier(text)
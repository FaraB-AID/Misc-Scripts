noteTextParser()
const lines = text.split("\n")
const modifier = (text) => {
  noteTextInjector()

  if(state.contextStop){
    state.contextStop = false
    stop = true; return{ stop }
  }
  
  var currHistory = (history.length >= 2) ? history[(history.length -1)].text : ""

  if(!state.set.ai){
    if(state.set.aiOnce || state.set.aiRetry){
    }else{
    stop = true; return{ stop }
    }
  }

  if (lines.length > 0) {
    if(state.set.aiOnce){
      lines.push(state.set.onceText)
    }else if (currHistory == state.set.prevHistory && state.set.aiRetry){
      lines.push(state.set.onceText)
    } 
  }

  state.set.aiOnce = false
  state.set.prevHistory = (history.length >= 2) ? history[(history.length -1)].text : ""

  const finalText = lines.join("\n")
  return { text: finalText }
}

modifier(text)
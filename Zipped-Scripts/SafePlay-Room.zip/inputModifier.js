const modifier = (text) => {    
  let modifiedText = text
  stop = false  
  const lowered = text.toLowerCase()
  
  if(!state.setup){
    state.set = {red: false, yellow: false, ai: false, aiOnce: false, aiRetry: false, onceText: ""}
    state.setup = true
  }
  
  state.set.aiOnce = false
  

  var mpCommandMatcher = text.match(/\n? ?(?:> You |> You say "|)\/(\w*)(.*)/i) ? text.match(/\n? ?(?:> You |> You say "|)\/(\w*)(.*)/i) : []
  var mpCommand = mpCommandMatcher[1]
  var mpArgs = mpCommandMatcher[2] ? mpCommandMatcher[2] : ""
  if(mpArgs.substr(-1) == "."){
    mpArgs = mpArgs.substr(0, mpArgs.length - 1)
  } 
  if(mpArgs.substr(0, 1) == " "){
    mpArgs = mpArgs.substr(1)
  }
  if(mpArgs == `"`){
    mpArgs = ""
  }
  var diceCatcher = mpCommandMatcher[2] ? mpCommandMatcher[2].match(/(?: )?(\D*)*(?: )?(\d+)?(?:d)(\d+)?(?: )?(\-|\+)?(?: )?(\d+)?(?: )?(.*)/i) : []

  function getRandomInt(max) {
    return Math.floor(Math.random() * Math.floor(max));
  }

  var commandText = `Commands:
  /help — toggles this message on/off
  /ai — toggles AI on and off (default off)
  /ai 𝘵𝘦𝘹𝘵 — tells the AI to write about 𝘵𝘦𝘹𝘵 happening
  /red — blocks all player inputs until unblocked by /green
  /yellow — issues a warning that someone's uncomfortable
  /green — unblocks /red; otherwise, says someone is happy
  /roll d𝘯𝘶𝘮𝘣𝘦𝘳 — rolls a d𝘯𝘶𝘮𝘣𝘦𝘳. See more details in prompt.`

  if(mpCommand == "commands" || mpCommand == "help"){
    state.message = (state.message == commandText) ? (state.message = "") : (state.message = commandText)  
    text = null; stop = true; return{ text, stop }
  }

  if(!state.set.red && !state.set.yellow){
    state.message = ""
  }
  
  
  if(mpCommand == "roll"){
    var rollTotal = 0
    var diceList = ""
    for(i = 0; i < diceCatcher[2]; i++){
      var tempNum = (getRandomInt(Number(diceCatcher[3])) + 1)
      rollTotal += tempNum
      diceList += `,${tempNum}`
    }
    if (diceCatcher[4] == "+"){
      rollTotal += Number(diceCatcher[5])
    }
    if (diceCatcher[4] == "-"){
      rollTotal -= Number(diceCatcher[5])
    }
    var rollName = diceCatcher[1] ? diceCatcher[1] : "Someone"
    if(rollName.substr(-1) == " "){
      rollName = rollName.substr(0, rollName.length - 1)
    } 
    var rollReason = diceCatcher[6] ? ` for ${diceCatcher[6]}` : ""
    var diceNumber = diceCatcher[2] ? diceCatcher[2] : "1"
    var dicePlusMinus = diceCatcher[4] ? diceCatcher[4] : ""
    var diceBonusNumber = diceCatcher[5] ? diceCatcher[5] : ""
    diceList = (diceNumber >= 2) ? `(${diceList.substr(1)}) Total:` : `Result:`
    var rollText = `${rollName} rolled ${diceNumber}d${diceCatcher[3]}${dicePlusMinus}${diceBonusNumber} ${diceList} ${rollTotal}${rollReason}.`
    state.message = diceCatcher ? rollText : ""
    text = null; stop = true; return{ text, stop }
  }

  if(mpCommand == "ai" && !mpArgs){
    state.set.ai = state.set.ai ? false : true
    state.message = state.set.ai ? "The AI has been turned on." : "The AI has been turned off."
    text = null; stop = true; return{ text, stop }
  }

  if(mpCommand == "red"){
    state.message = 'Someone is NOT okay with what\'s going on. Inputs have been stopped. Please discuss the issue and type /green when you\'re ready to continue.'
    state.set.red = true
    text = null; stop = true; return{ text, stop }
  }

  if(mpCommand == "yellow"){
    state.set.yellow = state.set.yellow ? false : true 
    state.message = state.set.yellow ? 'Someone is getting uncomfortable. Please slow down and be considerate. Type /yellow again to hide this message.' : ""
    text = null; stop = true; return{ text, stop }
  }

  if(mpCommand == "green"){
    state.message = state.set.red ? "" : "Someone is happy about how things are going. Keep it up!"
    state.set.red = false
    text = null; stop = true; return{ text, stop }
  } 


  if(state.set.red){
    text = null; stop = true; return{ text, stop }
  }

  state.set.aiRetry = false

  if(mpCommand == "ai" && mpArgs){
    modifiedText = " "
    state.set.aiOnce = true
    state.set.aiRetry = true
    state.set.onceText = `[Editor's note: this scene:<"${mpArgs}">.]`
  }

  return ({text : modifiedText})
}

modifier(text)
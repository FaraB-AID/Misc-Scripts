const modifier = (text) => {
  const contextMemory = info.memoryLength ? text.slice(0, info.memoryLength) : ''
  const context = info.memoryLength ? text.slice(info.memoryLength) : text
  const lines = context.split("\n")

  var currHistory = (history.length >= 2) ? history[(history.length -1)].text : ""

  if(!state.set.ai){
    if(state.set.aiOnce || state.set.aiRetry){
    }else{
    stop = true; return{ stop }
    }
  }

  if (lines.length > 0) {
    if(state.set.aiOnce){
      lines.push(state.set.onceText)
    }else if (currHistory == state.set.prevHistory && state.set.aiRetry){
      lines.push(state.set.onceText)
    } 
  }

  state.set.aiOnce = false
  state.set.prevHistory = (history.length >= 2) ? history[(history.length -1)].text : ""

  const combinedLines = lines.join("\n").slice(-(info.maxChars - info.memoryLength))
  const finalText = [contextMemory, combinedLines].join("")
  return { text: finalText }
}

modifier(text)
//Sets the action # when change-over-time 1 (cot1) variables will
//take effect. If left at 0, they will never take effect.
var cot1Action = 0

//Sets state.memory to `` at action #, overwriting the client-set memory.
var cot1Memory = ``

//Sets state.memory.authorsNote to `` at action #, overwriting the client-set author's note.
var cot1AN = ``

//Creates `` as an editor's note at action #, which hangs in front of all player text
//and lasts for cot1ENDur # actions (default 1). Good for trying to prompt specific events.
//The EN is formatted as: [Editor's note: ``.]
var cot1EN = ``
var cot1ENDur = 1

//Creates `` as hidden floating text  at action #, which floats # (default 3) lines behind the text.
var cot1Float = ``
var cot1FloatDist = 3

//For however many WIKey variables as have something in their "", replaces that many
//WI entries with the entries filled out between `` while after action #.
//Replaces WI entries from the top down.
var cot1WIKey1 = ""
var cot1WIEntry1 = ``
var cot1WIKey2 = ""
var cot1WIEntry2 = ``
var cot1WIKey3 = ""
var cot1WIEntry3 = ``
var cot1WIKey4 = ""
var cot1WIEntry4 = ``
var cot1WIKey5 = ""
var cot1WIEntry5 = ``
var cot1WIKey6 = ""
var cot1WIEntry6 = ``
var cot1WIKey7 = ""
var cot1WIEntry7 = ``
var cot1WIKey8 = ""
var cot1WIEntry8 = ``
var cot1WIKey9 = ""
var cot1WIEntry9 = ``
var cot1WIKey10 = ""
var cot1WIEntry10 = ``


//For cot2 (if > 0), filled in variables will replace previous ones when that action# is reached
//For the script to work, each non-zero cot you set must be greater than the last, and you must
//use them sequentially, i.e, set cot1 & cot2 & cot3, not cot1 & cot4 & cot8 while skipping ones in-between
var cot2Action = 0

var cot2Memory = ``

var cot2AN = ``

var cot2EN = ``
var cot2ENDur = 1


var cot2Float = ``
var cot2FloatDist = 3

var cot2WIKey1 = ""
var cot2WIEntry1 = ``
var cot2WIKey2 = ""
var cot2WIEntry2 = ``
var cot2WIKey3 = ""
var cot2WIEntry3 = ``
var cot2WIKey4 = ""
var cot2WIEntry4 = ``
var cot2WIKey5 = ""
var cot2WIEntry5 = ``
var cot2WIKey6 = ""
var cot2WIEntry6 = ``
var cot2WIKey7 = ""
var cot2WIEntry7 = ``
var cot2WIKey8 = ""
var cot2WIEntry8 = ``
var cot2WIKey9 = ""
var cot2WIEntry9 = ``
var cot2WIKey10 = ""
var cot2WIEntry10 = ``

//For cot3 (if > 0), filled in variables will replace previous ones when that action# is reached
var cot3Action = 0

var cot3Memory = ``

var cot3AN = ``

var cot3EN = ``
var cot3ENDur = 1


var cot3Float = ``
var cot3FloatDist = 3

var cot3WIKey1 = ""
var cot3WIEntry1 = ``
var cot3WIKey2 = ""
var cot3WIEntry2 = ``
var cot3WIKey3 = ""
var cot3WIEntry3 = ``
var cot3WIKey4 = ""
var cot3WIEntry4 = ``
var cot3WIKey5 = ""
var cot3WIEntry5 = ``
var cot3WIKey6 = ""
var cot3WIEntry6 = ``
var cot3WIKey7 = ""
var cot3WIEntry7 = ``
var cot3WIKey8 = ""
var cot3WIEntry8 = ``
var cot3WIKey9 = ""
var cot3WIEntry9 = ``
var cot3WIKey10 = ""
var cot3WIEntry10 = ``


//For cot4 (if > 0), filled in variables will replace previous ones when that action# is reached
var cot4Action = 0

var cot4Memory = ``

var cot4AN = ``

var cot4EN = ``
var cot4ENDur = 1


var cot4Float = ``
var cot4FloatDist = 3

var cot4WIKey1 = ""
var cot4WIEntry1 = ``
var cot4WIKey2 = ""
var cot4WIEntry2 = ``
var cot4WIKey3 = ""
var cot4WIEntry3 = ``
var cot4WIKey4 = ""
var cot4WIEntry4 = ``
var cot4WIKey5 = ""
var cot4WIEntry5 = ``
var cot4WIKey6 = ""
var cot4WIEntry6 = ``
var cot4WIKey7 = ""
var cot4WIEntry7 = ``
var cot4WIKey8 = ""
var cot4WIEntry8 = ``
var cot4WIKey9 = ""
var cot4WIEntry9 = ``
var cot4WIKey10 = ""
var cot4WIEntry10 = ``


//For cot5 (if > 0), filled in variables will replace previous ones when that action# is reached
var cot5Action = 0

var cot5Memory = ``

var cot5AN = ``

var cot5EN = ``
var cot5ENDur = 1


var cot5Float = ``
var cot5FloatDist = 3

var cot5WIKey1 = ""
var cot5WIEntry1 = ``
var cot5WIKey2 = ""
var cot5WIEntry2 = ``
var cot5WIKey3 = ""
var cot5WIEntry3 = ``
var cot5WIKey4 = ""
var cot5WIEntry4 = ``
var cot5WIKey5 = ""
var cot5WIEntry5 = ``
var cot5WIKey6 = ""
var cot5WIEntry6 = ``
var cot5WIKey7 = ""
var cot5WIEntry7 = ``
var cot5WIKey8 = ""
var cot5WIEntry8 = ``
var cot5WIKey9 = ""
var cot5WIEntry9 = ``
var cot5WIKey10 = ""
var cot5WIEntry10 = ``


//For cot6 (if > 0), filled in variables will replace previous ones when that action# is reached
var cot6Action = 0

var cot6Memory = ``

var cot6AN = ``

var cot6EN = ``
var cot6ENDur = 1


var cot6Float = ``
var cot6FloatDist = 3

var cot6WIKey1 = ""
var cot6WIEntry1 = ``
var cot6WIKey2 = ""
var cot6WIEntry2 = ``
var cot6WIKey3 = ""
var cot6WIEntry3 = ``
var cot6WIKey4 = ""
var cot6WIEntry4 = ``
var cot6WIKey5 = ""
var cot6WIEntry5 = ``
var cot6WIKey6 = ""
var cot6WIEntry6 = ``
var cot6WIKey7 = ""
var cot6WIEntry7 = ``
var cot6WIKey8 = ""
var cot6WIEntry8 = ``
var cot6WIKey9 = ""
var cot6WIEntry9 = ``
var cot6WIKey10 = ""
var cot6WIEntry10 = ``


//For cot7 (if > 0), filled in variables will replace previous ones when that action# is reached
var cot7Action = 0

var cot7Memory = ``

var cot7AN = ``

var cot7EN = ``
var cot7ENDur = 1


var cot7Float = ``
var cot7FloatDist = 3

var cot7WIKey1 = ""
var cot7WIEntry1 = ``
var cot7WIKey2 = ""
var cot7WIEntry2 = ``
var cot7WIKey3 = ""
var cot7WIEntry3 = ``
var cot7WIKey4 = ""
var cot7WIEntry4 = ``
var cot7WIKey5 = ""
var cot7WIEntry5 = ``
var cot7WIKey6 = ""
var cot7WIEntry6 = ``
var cot7WIKey7 = ""
var cot7WIEntry7 = ``
var cot7WIKey8 = ""
var cot7WIEntry8 = ``
var cot7WIKey9 = ""
var cot7WIEntry9 = ``
var cot7WIKey10 = ""
var cot7WIEntry10 = ``


//For cot8 (if > 0), filled in variables will replace previous ones when that action# is reached
var cot8Action = 0

var cot8Memory = ``

var cot8AN = ``

var cot8EN = ``
var cot8ENDur = 1


var cot8Float = ``
var cot8FloatDist = 3

var cot8WIKey1 = ""
var cot8WIEntry1 = ``
var cot8WIKey2 = ""
var cot8WIEntry2 = ``
var cot8WIKey3 = ""
var cot8WIEntry3 = ``
var cot8WIKey4 = ""
var cot8WIEntry4 = ``
var cot8WIKey5 = ""
var cot8WIEntry5 = ``
var cot8WIKey6 = ""
var cot8WIEntry6 = ``
var cot8WIKey7 = ""
var cot8WIEntry7 = ``
var cot8WIKey8 = ""
var cot8WIEntry8 = ``
var cot8WIKey9 = ""
var cot8WIEntry9 = ``
var cot8WIKey10 = ""
var cot8WIEntry10 = ``


//For cot9 (if > 0), filled in variables will replace previous ones when that action# is reached
var cot9Action = 0

var cot9Memory = ``

var cot9AN = ``

var cot9EN = ``
var cot9ENDur = 1


var cot9Float = ``
var cot9FloatDist = 3

var cot9WIKey1 = ""
var cot9WIEntry1 = ``
var cot9WIKey2 = ""
var cot9WIEntry2 = ``
var cot9WIKey3 = ""
var cot9WIEntry3 = ``
var cot9WIKey4 = ""
var cot9WIEntry4 = ``
var cot9WIKey5 = ""
var cot9WIEntry5 = ``
var cot9WIKey6 = ""
var cot9WIEntry6 = ``
var cot9WIKey7 = ""
var cot9WIEntry7 = ``
var cot9WIKey8 = ""
var cot9WIEntry8 = ``
var cot9WIKey9 = ""
var cot9WIEntry9 = ``
var cot9WIKey10 = ""
var cot9WIEntry10 = ``


//For cot10 (if > 0), filled in variables will replace previous ones when that action# is reached
var cot10Action = 0

var cot10Memory = ``

var cot10AN = ``

var cot10EN = ``
var cot10ENDur = 1


var cot10Float = ``
var cot10FloatDist = 3

var cot10WIKey1 = ""
var cot10WIEntry1 = ``
var cot10WIKey2 = ""
var cot10WIEntry2 = ``
var cot10WIKey3 = ""
var cot10WIEntry3 = ``
var cot10WIKey4 = ""
var cot10WIEntry4 = ``
var cot10WIKey5 = ""
var cot10WIEntry5 = ``
var cot10WIKey6 = ""
var cot10WIEntry6 = ``
var cot10WIKey7 = ""
var cot10WIEntry7 = ``
var cot10WIKey8 = ""
var cot10WIEntry8 = ``
var cot10WIKey9 = ""
var cot10WIEntry9 = ``
var cot10WIKey10 = ""
var cot10WIEntry10 = ``

//Don't touch these
var cot2Check = cot2Action ? cot2Action : 1000000 
var cot3Check = cot3Action ? cot3Action : 1000000
var cot4Check = cot4Action ? cot4Action : 1000000
var cot5Check = cot5Action ? cot5Action : 1000000
var cot6Check = cot6Action ? cot6Action : 1000000
var cot7Check = cot7Action ? cot7Action : 1000000
var cot8Check = cot8Action ? cot8Action : 1000000
var cot9Check = cot9Action ? cot9Action : 1000000
var cot10Check = cot10Action ? cot10Action : 1000000
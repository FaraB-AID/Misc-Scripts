const modifier = (text) => {    
  let modifiedText = text
  stop = false  
  const lowered = text.toLowerCase()

  if(!state.setup){
    state.setup = true
    state.set = {enHelp: false, enAuto: true, enFormat: true, enFormatStart: "[Editor's note: this scene:< ", enFormatEnd: ">.]", enDist: 0, floatDist: 1, actionCount: 0, en: "", float: "", em: false, enDisplay: false, emToggle: false}
    state.cotSetup = true
    state.initialWI = worldInfo
    state.inputHappened = false
  }

  var enCommandMatcher = text.match(/\n? ?(> You |> You say "|)(\/\w*)? ?(.*)/i) ? text.match(/\n? ?(> You |> You say "|)(\/\w*)? ?(.*)/i) : []
  var enCommand = enCommandMatcher[2]
  var enArgs = enCommandMatcher[3]
  if(enCommandMatcher[1] == '> You ' || enCommandMatcher[1] == '> You say "'){
    enArgs = enCommandMatcher[3].substring(0, enCommandMatcher[3].length - 1)
  }
  
  state.message = ""

  if(enCommand == "/enhelp"){
    var helpText = "E/N Commands:\n/en 𝘵𝘦𝘹𝘵 — creates an E/N using 𝘵𝘦𝘹𝘵 that lasts for one action\n/float 𝘵𝘦𝘹𝘵 — creates unformatted floating text using 𝘵𝘦𝘹𝘵\n/editor — toggles Editor Mode (all inputs are converted into E/Ns)\n/display — toggles whether E/Ns are shown in the top text.\n/auto — toggles whether you automatically submit a minimal (\" \") input after setting an E/N\n/format — toggles whether E/N formatting includes \" this scene:<\"\n/endist # — sets how many lines back E/Ns float (default: 0; in front of text)\n/floatdist — sets how many lines back /float text floats (default: 1) #"
    state.set.enHelp = state.set.enHelp ? false : true
    state.message = state.set.enHelp ? helpText : ""
    text = null; stop = true; return{ text, stop }
  }

  if(enCommand == "/auto"){
    state.set.enAuto = state.set.enAuto ? false : true
    state.message = state.set.enAuto ? "Auto mode on." : "Auto mode off."
    text = null; stop = true; return{ text, stop }
  }

  if(enCommand == "/format"){
    state.set.enFormat = state.set.enFormat ? false : true
    state.message = state.set.enFormat ? `E/N format is now "[Editor's note: this scene< 𝘵𝘦𝘹𝘵>.]` : `E/N format is now "[Editor's note: 𝘵𝘦𝘹𝘵.]`
    state.set.enFormatStart = state.set.enFormat ? "[Editor's note: this scene:< " : "[Editor's note: "
    state.set.enFormatEnd = state.set.enFormat ? ">.]" : ".]"
    text = null; stop = true; return{ text, stop }
  }

  if(enCommand == "/endist"){
    if(Number(enArgs)){
      state.set.enDist = Number(enArgs)
      state.message = `E/N distance set to above the ${enArgs} most recent lines of text.`
    } else {
      state.set.enDist = 0
      state.message = `E/N distance set to 0 (hanging beneath all text).`
    }
    text = null; stop = true; return{ text, stop }
  }

  if(enCommand == "/floatdist"){
    if(Number(enArgs)){
      state.set.floatDist = Number(enArgs)
      state.message = `Float distance set to above the ${enArgs} most recent lines of text.`
    } else {
      state.set.floatDist = 0
      state.message = `Float distance set to 0 (hanging beneath all text).`
    }
    text = null; stop = true; return{ text, stop }
  }

  if(enCommand == "/display"){
    state.set.enDisplay = state.set.enDisplay ? false : true
    state.message = state.set.enDisplay ? "E/N display on." : "E/N display off."
    if (state.set.enDisplay){
      state.displayStats = state.set.en ? [{key: "E/N", value: state.set.en}] : []
    } else {
      state.displayStats = []
    }
    text = null; stop = true; return{ text, stop }
  }

  if(enCommand == "/float"){
    state.set.float = enArgs ? enArgs : ""
    text = null; stop = true; return{ text, stop }
  }

  if(enCommand == "/en"){
    state.set.en = enArgs ? `${state.set.enFormatStart}${enArgs}${state.set.enFormatEnd}` : ""
    state.set.actionCount = enArgs ? info.actionCount : 0
    if(state.set.enDisplay){
      state.displayStats = state.set.en ? [{key: "E/N", value: state.set.en}] : []
    }
    if(state.set.enAuto){
      modifiedText = " "
      if(state.set.actionCount){
        state.set.actionCount++
      }
    } else {
      text = null; stop = true; return{ text, stop }
    }
  }

  if(enCommand == "/editor"){
    state.set.em = state.set.em ? false : true
    state.set.en = state.set.em ? state.set.en : ""
    state.message = state.set.em ? "Editor mode enabled." : "Editor mode disabled."
    text = null; stop = true; return{ text, stop }
  }

  if(state.set.em && !enCommand){
    state.set.actionCount = enArgs ? 0 : state.set.actionCount
    state.set.en = enArgs ? `${state.set.enFormatStart}${enArgs}${state.set.enFormatEnd}` : ""
    if(state.set.enDisplay){
      state.displayStats = state.set.en ? [{key: "E/N", value: state.set.en}] : []
    }
    if(state.set.enAuto && enArgs){
      modifiedText = " "
    } else {
      text = null; stop = true; return{ text, stop }
    }
  }

  if(cot1Action && (info.actionCount + 1) < cot1Action){
    state.memory.context = ""
    state.memory.authorsNote = ""
    worldInfo = state.initialWI
  }
  if(cot1Action && (info.actionCount + 1) >= cot1Action && (info.actionCount + 1) < cot2Check){
    if(cot1Memory){
      state.memory.context = cot1Memory
    }
    if(cot1AN){
      state.memory.authorsNote = cot1AN
    }
    var cotWIKeys = [cot1WIKey10, cot1WIKey9, cot1WIKey8, cot1WIKey7, cot1WIKey6, cot1WIKey5, cot1WIKey4, cot1WIKey3, cot1WIKey2, cot1WIKey1]
    var cotWIEntries = [cot1WIEntry10, cot1WIEntry9, cot1WIEntry8, cot1WIEntry7, cot1WIEntry6, cot1WIEntry5, cot1WIEntry4, cot1WIEntry3, cot1WIEntry2, cot1WIEntry1]
    for(i = 0; i < cotWIKeys.length; i++){
      if(cotWIKeys[i]){
        worldInfo.shift()
      }
    }
    for(i = 0; i < cotWIKeys.length; i++){
      if(cotWIKeys[i]){
        var tempWI = {"id": `${Math.random()}`, "keys": cotWIKeys[i], "entry": cotWIEntries[i], "hidden": false}
        worldInfo.unshift(tempWI)
      }
    }
  }

  if(cot2Action && (info.actionCount + 1) >= cot2Action && (info.actionCount + 1) < cot3Check){
    if(cot2Memory){
      state.memory.context = cot2Memory
    }
    if(cot2AN){
      state.memory.authorsNote = cot2AN
    }
    var cotWIKeys = [cot2WIKey10, cot2WIKey9, cot2WIKey8, cot2WIKey7, cot2WIKey6, cot2WIKey5, cot2WIKey4, cot2WIKey3, cot2WIKey2, cot2WIKey1]
    var cotWIEntries = [cot2WIEntry10, cot2WIEntry9, cot2WIEntry8, cot2WIEntry7, cot2WIEntry6, cot2WIEntry5, cot2WIEntry4, cot2WIEntry3, cot2WIEntry2, cot2WIEntry1]
    for(i = 0; i < cotWIKeys.length; i++){
      if(cotWIKeys[i]){
        worldInfo.shift()
      }
    }
    for(i = 0; i < cotWIKeys.length; i++){
      if(cotWIKeys[i]){
        var tempWI = {"id": `${Math.random()}`, "keys": cotWIKeys[i], "entry": cotWIEntries[i], "hidden": false}
        worldInfo.unshift(tempWI)
      }
    }
  }

  if(cot3Action && (info.actionCount + 1) >= cot3Action && (info.actionCount + 1) < cot4Check){
    if(cot3Memory){
      state.memory.context = cot3Memory
    }
    if(cot3AN){
      state.memory.authorsNote = cot3AN
    }
    var cotWIKeys = [cot3WIKey10, cot3WIKey9, cot3WIKey8, cot3WIKey7, cot3WIKey6, cot3WIKey5, cot3WIKey4, cot3WIKey3, cot3WIKey2, cot3WIKey1]
    var cotWIEntries = [cot3WIEntry10, cot3WIEntry9, cot3WIEntry8, cot3WIEntry7, cot3WIEntry6, cot3WIEntry5, cot3WIEntry4, cot3WIEntry3, cot3WIEntry2, cot3WIEntry1]
    for(i = 0; i < cotWIKeys.length; i++){
      if(cotWIKeys[i]){
        worldInfo.shift()
      }
    }
    for(i = 0; i < cotWIKeys.length; i++){
      if(cotWIKeys[i]){
        var tempWI = {"id": `${Math.random()}`, "keys": cotWIKeys[i], "entry": cotWIEntries[i], "hidden": false}
        worldInfo.unshift(tempWI)
      }
    }
  }

  if(cot4Action && (info.actionCount + 1) >= cot4Action && (info.actionCount + 1) < cot5Check){
    if(cot4Memory){
      state.memory.context = cot4Memory
    }
    if(cot4AN){
      state.memory.authorsNote = cot4AN
    }
    var cotWIKeys = [cot4WIKey10, cot4WIKey9, cot4WIKey8, cot4WIKey7, cot4WIKey6, cot4WIKey5, cot4WIKey4, cot4WIKey3, cot4WIKey2, cot4WIKey1]
    var cotWIEntries = [cot4WIEntry10, cot4WIEntry9, cot4WIEntry8, cot4WIEntry7, cot4WIEntry6, cot4WIEntry5, cot4WIEntry4, cot4WIEntry3, cot4WIEntry2, cot4WIEntry1]
    for(i = 0; i < cotWIKeys.length; i++){
      if(cotWIKeys[i]){
        worldInfo.shift()
      }
    }
    for(i = 0; i < cotWIKeys.length; i++){
      if(cotWIKeys[i]){
        var tempWI = {"id": `${Math.random()}`, "keys": cotWIKeys[i], "entry": cotWIEntries[i], "hidden": false}
        worldInfo.unshift(tempWI)
      }
    }
  }

  if(cot5Action && (info.actionCount + 1) >= cot5Action && (info.actionCount + 1) < cot6Check){
    if(cot5Memory){
      state.memory.context = cot5Memory
    }
    var cotWIKeys = [cot5WIKey10, cot5WIKey9, cot5WIKey8, cot5WIKey7, cot5WIKey6, cot5WIKey5, cot5WIKey4, cot5WIKey3, cot5WIKey2, cot5WIKey1]
    var cotWIEntries = [cot5WIEntry10, cot5WIEntry9, cot5WIEntry8, cot5WIEntry7, cot5WIEntry6, cot5WIEntry5, cot5WIEntry4, cot5WIEntry3, cot5WIEntry2, cot5WIEntry1]
    for(i = 0; i < cotWIKeys.length; i++){
      if(cotWIKeys[i]){
        worldInfo.shift()
      }
    }
    for(i = 0; i < cotWIKeys.length; i++){
      if(cotWIKeys[i]){
        var tempWI = {"id": `${Math.random()}`, "keys": cotWIKeys[i], "entry": cotWIEntries[i], "hidden": false}
        worldInfo.unshift(tempWI)
      }
    }
  }

  if(cot6Action && (info.actionCount + 1) >= cot6Action && (info.actionCount + 1) < cot7Check){
    if(cot6Memory){
      state.memory.context = cot6Memory
    }
    if(cot6AN){
      state.memory.authorsNote = cot6AN
    }
    var cotWIKeys = [cot6WIKey10, cot6WIKey9, cot6WIKey8, cot6WIKey7, cot6WIKey6, cot6WIKey5, cot6WIKey4, cot6WIKey3, cot6WIKey2, cot6WIKey1]
    var cotWIEntries = [cot6WIEntry10, cot6WIEntry9, cot6WIEntry8, cot6WIEntry7, cot6WIEntry6, cot6WIEntry5, cot6WIEntry4, cot6WIEntry3, cot6WIEntry2, cot6WIEntry1]
    for(i = 0; i < cotWIKeys.length; i++){
      if(cotWIKeys[i]){
        worldInfo.shift()
      }
    }
    for(i = 0; i < cotWIKeys.length; i++){
      if(cotWIKeys[i]){
        var tempWI = {"id": `${Math.random()}`, "keys": cotWIKeys[i], "entry": cotWIEntries[i], "hidden": false}
        worldInfo.unshift(tempWI)
      }
    }
  }

  if(cot7Action && (info.actionCount + 1) >= cot7Action && (info.actionCount + 1) < cot8Check){
    if(cot7Memory){
      state.memory.context = cot7Memory
    }
    if(cot7AN){
      state.memory.authorsNote = cot7AN
    }
    var cotWIKeys = [cot7WIKey10, cot7WIKey9, cot7WIKey8, cot7WIKey7, cot7WIKey6, cot7WIKey5, cot7WIKey4, cot7WIKey3, cot7WIKey2, cot7WIKey1]
    var cotWIEntries = [cot7WIEntry10, cot7WIEntry9, cot7WIEntry8, cot7WIEntry7, cot7WIEntry6, cot7WIEntry5, cot7WIEntry4, cot7WIEntry3, cot7WIEntry2, cot7WIEntry1]
    for(i = 0; i < cotWIKeys.length; i++){
      if(cotWIKeys[i]){
        worldInfo.shift()
      }
    }
    for(i = 0; i < cotWIKeys.length; i++){
      if(cotWIKeys[i]){
        var tempWI = {"id": `${Math.random()}`, "keys": cotWIKeys[i], "entry": cotWIEntries[i], "hidden": false}
        worldInfo.unshift(tempWI)
      }
    }
  }

  if(cot8Action && (info.actionCount + 1) >= cot8Action && (info.actionCount + 1) < cot9Check){
    if(cot8Memory){
      state.memory.context = cot8Memory
    }
    if(cot8AN){
      state.memory.authorsNote = cot8AN
    }
    var cotWIKeys = [cot8WIKey10, cot8WIKey9, cot8WIKey8, cot8WIKey7, cot8WIKey6, cot8WIKey5, cot8WIKey4, cot8WIKey3, cot8WIKey2, cot8WIKey1]
    var cotWIEntries = [cot8WIEntry10, cot8WIEntry9, cot8WIEntry8, cot8WIEntry7, cot8WIEntry6, cot8WIEntry5, cot8WIEntry4, cot8WIEntry3, cot8WIEntry2, cot8WIEntry1]
    for(i = 0; i < cotWIKeys.length; i++){
      if(cotWIKeys[i]){
        worldInfo.shift()
      }
    }
    for(i = 0; i < cotWIKeys.length; i++){
      if(cotWIKeys[i]){
        var tempWI = {"id": `${Math.random()}`, "keys": cotWIKeys[i], "entry": cotWIEntries[i], "hidden": false}
        worldInfo.unshift(tempWI)
      }
    }
  }

  if(cot9Action && (info.actionCount + 1) >= cot9Action && (info.actionCount + 1) < cot10Check){
    if(cot9Memory){
      state.memory.context = cot9Memory
    }
    var cotWIKeys = [cot9WIKey10, cot9WIKey9, cot9WIKey8, cot9WIKey7, cot9WIKey6, cot9WIKey5, cot9WIKey4, cot9WIKey3, cot9WIKey2, cot9WIKey1]
    var cotWIEntries = [cot9WIEntry10, cot9WIEntry9, cot9WIEntry8, cot9WIEntry7, cot9WIEntry6, cot9WIEntry5, cot9WIEntry4, cot9WIEntry3, cot9WIEntry2, cot9WIEntry1]
    for(i = 0; i < cotWIKeys.length; i++){
      if(cotWIKeys[i]){
        worldInfo.shift()
      }
    }
    for(i = 0; i < cotWIKeys.length; i++){
      if(cotWIKeys[i]){
        var tempWI = {"id": `${Math.random()}`, "keys": cotWIKeys[i], "entry": cotWIEntries[i], "hidden": false}
        worldInfo.unshift(tempWI)
      }
    }
  }

  if(cot10Action && (info.actionCount + 1) >= cot10Action){
    if(cot10Memory){
      state.memory.context = cot10Memory
    }
    if(cot10AN){
      state.memory.authorsNote = cot10AN
    }
    var cotWIKeys = [cot10WIKey10, cot10WIKey9, cot10WIKey8, cot10WIKey7, cot10WIKey6, cot10WIKey5, cot10WIKey4, cot10WIKey3, cot10WIKey2, cot10WIKey1]
    var cotWIEntries = [cot10WIEntry10, cot10WIEntry9, cot10WIEntry8, cot10WIEntry7, cot10WIEntry6, cot10WIEntry5, cot10WIEntry4, cot10WIEntry3, cot10WIEntry2, cot10WIEntry1]
    for(i = 0; i < cotWIKeys.length; i++){
      if(cotWIKeys[i]){
        worldInfo.shift()
      }
    }
    for(i = 0; i < cotWIKeys.length; i++){
      if(cotWIKeys[i]){
        var tempWI = {"id": `${Math.random()}`, "keys": cotWIKeys[i], "entry": cotWIEntries[i], "hidden": false}
        worldInfo.unshift(tempWI)
      }
    }
  }

state.inputHappened = true

  return ({text : modifiedText})
}

modifier(text)
const modifier = (text) => {
  let modifiedText = text
  console.log(info)

  function lowercaseFirstLetter(string) {
    return string.charAt(0).toLowerCase() + string.slice(1);
  }

  if(info.evaluation.actionScore){
    state.level.currentExp += info.evaluation.actionScore
    state.message = `You gained ${info.evaluation.actionScore}xp because ` + lowercaseFirstLetter(info.evaluation.reason.substring(9))
  }


  if (state.level.currentExp >= state.level.expReq){
    state.level.player++
    state.level.currentExp -= state.level.expReq
    state.level.expReq = Math.round(state.level.expReq*1.25)
    state.stats.statPoints += 3
    state.message += `\nYou've leveled up! You're now level ${state.level.player}! Congrats!`
  }

  return { text: modifiedText }
  }

modifier(text)
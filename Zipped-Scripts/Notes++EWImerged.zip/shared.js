 //this is a function for creating the pronoun-swapper mini-script
 function pronounSwapper(){
    if(/\{ppl:[^\{\}]*\}/i.test(text)){
      pronounText = [...text.match(/\{ppl:([^\{\}]*)\}/i)]
      text = text.replace(pronounText[0], "")
      pronounNeut = false
      pronounFem = false
      pronounMasc = false
      if(/they|them|their|theirs|themselves|neuter|neutral|neutroi|nonbinary|other/i.test(pronounText[1])){
        pronounNeut = true
      } else if(/she|her|hers|herself|feminine|female|fem|woman/i.test(pronounText[1])){
        pronounFem = true
      } else if(/he|him|his|himself|masculine|male|masc|man/i.test(pronounText[1])){
        pronounMasc = true
      } else {
        pronounNeut = true
      }
      if(pronounNeut){
        text = text.replace(/\{sp\}/g, `they`)
        text = text.replace(/\{op\}/g, `them`)
        text = text.replace(/\{pa\}/g, `their`)
        text = text.replace(/\{pp\}/g, `theirs`)
        text = text.replace(/\{rp\}/g, `themselves`)
        text = text.replace(/\{Sp\}/g, `They`)
        text = text.replace(/\{Op\}/g, `Them`)
        text = text.replace(/\{Pa\}/g, `Their`)
        text = text.replace(/\{Pp\}/g, `Theirs`)
        text = text.replace(/\{Rp\}/g, `Themselves`)
      }
      if(pronounFem){
        text = text.replace(/\{sp\}/g, `she`)
        text = text.replace(/\{op\}/g, `her`)
        text = text.replace(/\{pa\}/g, `her`)
        text = text.replace(/\{pp\}/g, `hers`)
        text = text.replace(/\{rp\}/g, `herself`)
        text = text.replace(/\{Sp\}/g, `She`)
        text = text.replace(/\{Op\}/g, `Her`)
        text = text.replace(/\{Pa\}/g, `Her`)
        text = text.replace(/\{Pp\}/g, `Hers`)
        text = text.replace(/\{Rp\}/g, `Herself`)
      }
      if(pronounMasc){
        text = text.replace(/\{sp\}/g, `he`)
        text = text.replace(/\{op\}/g, `him`)
        text = text.replace(/\{pa\}/g, `his`)
        text = text.replace(/\{pp\}/g, `his`)
        text = text.replace(/\{rp\}/g, `himself`)
        text = text.replace(/\{Sp\}/g, `He`)
        text = text.replace(/\{Op\}/g, `Him`)
        text = text.replace(/\{Pa\}/g, `His`)
        text = text.replace(/\{Pp\}/g, `His`)
        text = text.replace(/\{Rp\}/g, `Himself`)
      }
    }
  }

//configures initial states on startup
if(!state.notesInitialize){
  state.notesRecord = []
  state.notes = []
  state.notesOO = []
  state.notesIO = []
  state.notesOP = []
  state.notesIP = []
  state.notesOS = []
  state.notesIS = []
  state.notesM = []
  state.notesD = []
  pronounSwapper()
  state.notesInitialize = true
}

//these functions are needed by noteTextParser
function noteTextRemover (noteType){
  for (i = 0; i < noteType.length; i++){
    text = text.replace(noteType[i][0], "")
  }
}
function noteRecordCheck(noteType){
  if (noteType[i][1] || noteType[i][3]){  
    for(ii = 0; ii < state.notesRecord.length; ii++){
      if(state.notesRecord[ii].record == noteType[i][0]){
        state.notesRecordMatch = true
      }
    }
  }
}
function noteRecorder(noteType){
  tempLine = Number(noteType[i][5]) ? Number(noteType[i][5]) : 0
  tempObject = {note: tempNote, line: tempLine}
  tempDuration = Number(noteType[i][1])
  tempDelay = Number(noteType[i][3])
  if ((tempDuration  || tempDelay) && !state.notesRecordMatch){
    tempBeginAt = tempDelay ? tempDelay + info.actionCount : info.actionCount
    tempEndBy = tempDuration  ? tempBeginAt + tempDuration : 1000000    
    tempRecord = {record: noteType[i][0], beginAt: tempBeginAt, endBy: tempEndBy}
    if(tempDuration == 1){
      tempRecord.once = true
    }
  }
  if (tempDuration || tempDelay){
    tempObject.record = noteType[i][0]
  }
  if(noteType[i][6]){
    state.notes.push(tempObject)
  }
  if((tempDuration || tempDelay) && noteType[i][6] && !state.notesRecordMatch){
    state.notesRecord.push(tempRecord)
  }
  state.notesRecordMatch = false
}

function noteRecorderSpecial(noteType, stateName){
  tempObject = {note: noteType[i][6]}
  tempDuration = Number(noteType[i][1])
  tempDelay = Number(noteType[i][3])
  if ((tempDuration || tempDelay) && !state.notesRecordMatch){ 
    tempBeginAt = tempDelay ? tempDelay + info.actionCount : info.actionCount
    tempEndBy = tempDuration ? tempBeginAt + tempDuration : 1000000
    tempRecord = {record: noteType[i][0], beginAt: tempBeginAt, endBy: tempEndBy}
    if(tempDuration == 1){
      tempRecord.once = 1
    }
  }
  if (tempDuration || tempDelay){
    tempObject.record = noteType[i][0]
  }
  if(noteType[i][6]){
    state[stateName].push(tempObject)
  }
  if((tempDuration || tempDelay) && noteType[i][6] && !state.notesRecordMatch){
    state.notesRecord.push(tempRecord)
  }
  state.notesRecordMatch = false
}
function noteRecorderDisplay(noteType, stateName){
  tempDisplayObject = {line: Number(noteType[i][5]), key: noteType[i][6], value: noteType[i][7], color: noteType[i][8]}
  tempDuration = Number(noteType[i][1])
  tempDelay = Number(noteType[i][3])
  if ((tempDuration || tempDelay) && !state.notesRecordMatch){ 
    tempBeginAt = tempDelay ? tempDelay + info.actionCount : info.actionCount
    tempEndBy = tempDuration ? tempBeginAt + tempDuration : 1000000
    tempRecord = {record: noteType[i][0], beginAt: tempBeginAt, endBy: tempEndBy}
    if(tempDuration == 1){
      tempRecord.once = 1
    }
  }
  if (tempDuration || tempDelay){
    tempDisplayObject.record = noteType[i][0]
  }

  state[stateName].push(tempDisplayObject)

  if((tempDuration || tempDelay) && noteType[i][6] && !state.notesRecordMatch){
    state.notesRecord.push(tempRecord)
  }
  state.notesRecordMatch = false
}
//this function finds, parses, and extracts Note++ notes
function noteTextParser (){
  state.notes = []
  state.notesOO = []
  state.notesIO = []
  state.notesOP = []
  state.notesIP = []
  state.notesOS = []
  state.notesIS = []
  state.notesM = []
  state.notesD = []


  //this finds and caches Notes++ formatted Notes in text
  authorsNotes = [...text.matchAll(/\{(\d*)(\+?(\d*))(a\/?n(\d+)):([^\{\}]*)\}\n?/gi)]
  unformattedNotes = [...text.matchAll(/\{(\d*)*(\+?(\d*))([\s-,\.]?(\d+)):([^\{\}]*)\}\n?/gi)]
  editorsNotes = [...text.matchAll(/\{(\d*)(\+?(\d*))(e\/?n(\d+)):([^\{\}]*)\}\n?/gi)]
  editorsNotesScene = [...text.matchAll(/\{(\d*)(\+?(\d*))(e\/?ns(\d+)):([^\{\}]*)\}\n?/gi)]
  outputOverrideNotes = [...text.matchAll(/\{(\d*)(\+?(\d*))(o\/?o)(:)([^\{\}]*)\}\n?/gi)]
  inputOverrideNotes = [...text.matchAll(/\{(\d*)(\+?(\d*))(i\/?o)(:)([^\{\}]*)\}\n?/gi)]
  outputPrefixNotes = [...text.matchAll(/\{(\d*)(\+?(\d*))(o\/?p)(:)([^\{\}]*)\}\n?/gi)]
  inputPrefixNotes = [...text.matchAll(/\{(\d*)(\+?(\d*))(i\/?p)(:)([^\{\}]*)\}\n?/gi)]
  outputSuffixNotes = [...text.matchAll(/\{(\d*)(\+?(\d*))(o\/?s)(:)([^\{\}]*)\}\n?/gi)]
  inputSuffixNotes = [...text.matchAll(/\{(\d*)(\+?(\d*))(i\/?s)(:)([^\{\}]*)\}\n?/gi)]
  messageNotes = [...text.matchAll(/\{(\d*)(\+?(\d*))(m)(:)([^\{\}]*)\}\n?/gi)]
  displayNotes = [...text.matchAll(/\{(\d*)(\+?(\d*))(d)(\d?):\s*([^\{\}:]*):\s*([^\{\}:]*):?\s*([^\{\}]*)\}\n?/gi)]
  //this finds and caches Notes++ formatted Notes in {notes} WIs
  for(i = 0; i < worldInfo.length; i++){
    if(/\{notes\}/i.test(worldInfo[i].keys)){
      authorsNotesTemp = [...worldInfo[i].entry.matchAll(/\{(\d*)(\+?(\d*))(a\/?n(\d+)):([^\{\}]*)\}\n?/gi)]
      authorsNotes = authorsNotes.concat(authorsNotesTemp)
      unformattedNotesTemp = [...worldInfo[i].entry.matchAll(/\{(\d*)(\+?(\d*))([\s-,\.]?(\d+)):([^\{\}]*)\}\n?/gi)]
      unformattedNotes = unformattedNotes.concat(unformattedNotesTemp)
      editorsNotesTemp = [...worldInfo[i].entry.matchAll(/\{(\d*)(\+?(\d*))(e\/?n(\d+)):([^\{\}]*)\}\n?/gi)]
      editorsNotes = editorsNotes.concat(editorsNotesTemp)
      editorsNotesSceneTemp = [...worldInfo[i].entry.matchAll(/\{(\d*)(\+?(\d*))(e\/?ns(\d+)):([^\{\}]*)\}\n?/gi)]
      editorsNotesScene = editorsNotesScene.concat(editorsNotesSceneTemp)
      outputOverrideNotesTemp = [...worldInfo[i].entry.matchAll(/\{(\d*)(\+?(\d*))(o\/?o)(:)([^\{\}]*)\}\n?/gi)]
      outputOverrideNotes = outputOverrideNotes.concat(outputOverrideNotesTemp)
      inputOverrideNotesTemp = [...worldInfo[i].entry.matchAll(/\{(\d*)(\+?(\d*))(i\/?o)(:)([^\{\}]*)\}\n?/gi)]
      inputOverrideNotes = inputOverrideNotes.concat(inputOverrideNotesTemp)
      outputPrefixNotesTemp = [...worldInfo[i].entry.matchAll(/\{(\d*)(\+?(\d*))(o\/?p)(:)([^\{\}]*)\}\n?/gi)]
      outputPrefixNotes = outputPrefixNotes.concat(outputPrefixNotesTemp)
      inputPrefixNotesTemp = [...worldInfo[i].entry.matchAll(/\{(\d*)(\+?(\d*))(i\/?p)(:)([^\{\}]*)\}\n?/gi)]
      inputPrefixNotes = inputPrefixNotes.concat(inputPrefixNotesTemp)
      outputSuffixNotesTemp = [...worldInfo[i].entry.matchAll(/\{(\d*)(\+?(\d*))(o\/?s)(:)([^\{\}]*)\}\n?/gi)]
      outputSuffixNotes = outputSuffixNotes.concat(outputSuffixNotesTemp)
      inputSuffixNotesTemp = [...worldInfo[i].entry.matchAll(/\{(\d*)(\+?(\d*))(i\/?s)(:)([^\{\}]*)\}\n?/gi)]
      inputSuffixNotes = inputSuffixNotes.concat(inputSuffixNotesTemp)
      messageNotesTemp = [...worldInfo[i].entry.matchAll(/\{(\d*)(\+?(\d*))(m)(:)([^\{\}]*)\}\n?/gi)]
      messageNotes = messageNotes.concat(messageNotesTemp)
      displayNotesTemp = [...worldInfo[i].entry.matchAll(/\{(\d*)(\+?(\d*))(d)(\d?):\s*([^\{\}:]*):\s*([^\{\}:]*):?\s*([^\{\}]*)\}\n?/gi)]
      displayNotes = displayNotes.concat(displayNotesTemp)
    }
  }
  //this removes Note++ formatted text from the context
  noteTextRemover (authorsNotes)
  noteTextRemover (unformattedNotes)
  noteTextRemover (editorsNotes)
  noteTextRemover (editorsNotesScene)
  noteTextRemover (outputOverrideNotes)
  noteTextRemover (inputOverrideNotes)
  noteTextRemover (outputPrefixNotes)
  noteTextRemover (inputPrefixNotes)
  noteTextRemover (outputSuffixNotes)
  noteTextRemover (inputSuffixNotes)
  noteTextRemover (messageNotes)
  noteTextRemover (displayNotes)

  //this reformats the cached Note++ text into an array of 
  //objects ready to be injected into the context later
  for(i = 0; i < authorsNotes.length; i++){
    noteRecordCheck(authorsNotes)
    if(/\{\d*\+?\d*a\/?n\d+:\s+\}\n?/i.test(authorsNotes[i][0])){
      authorsNotes[i][6] = ""
    }
    tempNote = authorsNotes[i][0].replace(`{${authorsNotes[i][1]}${authorsNotes[i][2]}${authorsNotes[i][4]}`, "[Author's note")
    tempNote = tempNote.replace("}\n", "}")
    tempNote = tempNote.replace("}", "]")
    noteRecorder(authorsNotes)
  }
  for(i = 0; i < unformattedNotes.length; i++){
    noteRecordCheck(unformattedNotes)
    if(/\{\d*\+?\d*[\s-,\.]?\d+:\s+\}\n?/i.test(unformattedNotes[i][0])){
      unformattedNotes[i][6] = ""
    }
    tempNote = unformattedNotes[i][6]
    noteRecorder(unformattedNotes)
  }
  for(i = 0; i < editorsNotes.length; i++){
    noteRecordCheck(editorsNotes)
    if(/\{\d*\+?\d*e\/?n\d+:\s+\}\n?/i.test(editorsNotes[i][0])){
      editorsNotes[i][6] = ""
    }
    tempNote = editorsNotes[i][0].replace(`{${editorsNotes[i][1]}${editorsNotes[i][2]}${editorsNotes[i][4]}`, "[Editor's note")
    tempNote = tempNote.replace("}\n", "}")
    tempNote = tempNote.replace("}", "]")
    noteRecorder(editorsNotes)
  }
  for(i = 0; i < editorsNotesScene.length; i++){
    noteRecordCheck(editorsNotesScene)
    if(/\{\d*\+?\d*e\/?ns\d+:\s+\}\n?/i.test(editorsNotesScene[i][0])){
      editorsNotesScene[i][6] = ""
    }
    tempNote = editorsNotesScene[i][0].replace(`{${editorsNotesScene[i][1]}${editorsNotesScene[i][2]}${editorsNotesScene[i][4]}:`, "[Editor's note: this scene:<")
    tempNote = tempNote.replace("}\n", "}")
    tempNote = tempNote.replace("}", ">.]")
    noteRecorder(editorsNotesScene)
  }
  for(i = 0; i < outputOverrideNotes.length; i++){
    noteRecordCheck(outputOverrideNotes)
    if(/\{\d*\+?\d*o\/?o:\s+\}\n?/i.test(outputOverrideNotes[i][0])){
      outputOverrideNotes[i][6] = ""
    }
    noteRecorderSpecial(outputOverrideNotes, "notesOO")
  }
  for(i = 0; i < inputOverrideNotes.length; i++){
    noteRecordCheck(inputOverrideNotes)
    if(/\{\d*\+?\d*i\/?o:\s+\}\n?/i.test(inputOverrideNotes[i][0])){
      inputOverrideNotes[i][6] = ""
    }
    noteRecorderSpecial(inputOverrideNotes, "notesIO")
  }
  for(i = 0; i < outputPrefixNotes.length; i++){
    noteRecordCheck(outputPrefixNotes)
    if(/\{\d*\+?\d*o\/?p:\s+\}\n?/i.test(outputPrefixNotes[i][0])){
      outputPrefixNotes[i][6] = ""
    }
    noteRecorderSpecial(outputPrefixNotes, "notesOP")
  }
  for(i = 0; i < inputPrefixNotes.length; i++){
    noteRecordCheck(inputPrefixNotes)
    if(/\{\d*\+?\d*i\/?p:\s+\}\n?/i.test(inputPrefixNotes[i][0])){
      inputPrefixNotes[i][6] = ""
    }
    noteRecorderSpecial(inputPrefixNotes, "notesIP")
  }
  for(i = 0; i < outputSuffixNotes.length; i++){
    noteRecordCheck(outputSuffixNotes)
    if(/\{\d*\+?\d*o\/?s:\s+\}\n?/i.test(outputSuffixNotes[i][0])){
      outputSuffixNotes[i][6] = ""
    }
    noteRecorderSpecial(outputSuffixNotes, "notesOS")
  }
  for(i = 0; i < inputSuffixNotes.length; i++){
    noteRecordCheck(inputSuffixNotes)
    if(/\{\d*\+?\d*i\/?s:\s+\}\n?/i.test(inputSuffixNotes[i][0])){
      inputSuffixNotes[i][6] = ""
    }
    noteRecorderSpecial(inputSuffixNotes, "notesIS")
  }
  for(i = 0; i < messageNotes.length; i++){
    noteRecordCheck(messageNotes)
    if(/\{\d*\+?\d*m:\s+\}\n?/i.test(messageNotes[i][0])){
      messageNotes[i][6] = ""
    }
    noteRecorderSpecial(messageNotes, "notesM")
  }
  for(i = 0; i < displayNotes.length; i++){
    noteRecordCheck(displayNotes)
    noteRecorderDisplay(displayNotes, "notesD")
  }
  //this removes any empty author's notes
  //which can generate if the A/N field is used for Note++ notes
  text = text.replace(/\[Author's note:[\s\n]*\]\n?/g, "")
}

//This injects the reformatted Note++ objects into the context
function noteTextInjector (){
  lines.reverse()
  for (i = 0; i < state.notes.length; i++){
    if (state.notes[i].record){
      for (ii = 0; ii < state.notesRecord.length; ii++){
        if(state.notes[i].record == state.notesRecord[ii].record){
          if(info.actionCount < state.notesRecord[ii].endBy && info.actionCount >= state.notesRecord[ii].beginAt && !state.notesRecord[ii].once){
            if(lines.length > (state.notes[i].line - 1)){
              lines[state.notes[i].line] += `\n${state.notes[i].note}`
            }
          } else if (state.notesRecord[ii].once){
            if (info.actionCount <= state.notesRecord[ii].beginAt && state.notesRecord[ii].once == 2) {
              state.notesRecord[ii].once = 1
            }
            if (info.actionCount >= state.notesRecord[ii].beginAt && state.notesRecord[ii].once == 1){
              state.notesRecord[ii].once = 2
              if(lines.length > (state.notes[i].line - 1)){
                lines[state.notes[i].line] += `\n${state.notes[i].note}`
              }
            }
          }
        }
      }
    } else if (lines.length > (state.notes[i].line - 1)){
      lines[state.notes[i].line] += `\n${state.notes[i].note}`
    }
  }
  lines.reverse()
  //this records the last model input for the /lmi command
  state.lmi = lines.join("\n").slice(-(info.maxChars))
}

//this modifies the input with the input special format notes
function noteInputSpecial(){
  notesTextTemp = ""
  notesPrefixTemp = ""
  notesSuffixTemp = ""
  for (i = 0; i < state.notesIO.length; i++){
    if (state.notesIO[i].record){
      for (ii = 0; ii < state.notesRecord.length; ii++){
        if(state.notesIO[i].record == state.notesRecord[ii].record){
          if((info.actionCount - 1) < state.notesRecord[ii].endBy && (info.actionCount - 1) >= state.notesRecord[ii].beginAt && !state.notesRecord[ii].once){
            notesTextTemp += state.notesIO[i].note 
          } else if (state.notesRecord[ii].once){
            if ((info.actionCount - 1) <= state.notesRecord[ii].beginAt && state.notesRecord[ii].once == 2) {
              state.notesRecord[ii].once = 1
            }
            if ((info.actionCount - 1) >= state.notesRecord[ii].beginAt && state.notesRecord[ii].once == 1){
              state.notesRecord[ii].once = 2
              notesTextTemp += state.notesIO[i].note 
            }
          }
        }
      }
    } else {
      notesTextTemp += state.notesIO[i].note 
    }
  }
  if (notesTextTemp){
    text = notesTextTemp
  }
  for (i = 0; i < state.notesIP.length; i++){
    if (state.notesIP[i].record){
      for (ii = 0; ii < state.notesRecord.length; ii++){
        if(state.notesIP[i].record == state.notesRecord[ii].record){
          if((info.actionCount - 1) < state.notesRecord[ii].endBy && (info.actionCount - 1) >= state.notesRecord[ii].beginAt && !state.notesRecord[ii].once){
            notesPrefixTemp += state.notesIP[i].note
          } else if (state.notesRecord[ii].once){
            if ((info.actionCount - 1) <= state.notesRecord[ii].beginAt && state.notesRecord[ii].once == 2) {
              state.notesRecord[ii].once = 1
            }
            if ((info.actionCount - 1) >= state.notesRecord[ii].beginAt && state.notesRecord[ii].once == 1){
              state.notesRecord[ii].once = 2
              notesPrefixTemp += state.notesIP[i].note 
            }
          }
        }
      }
    } else {
      notesPrefixTemp += state.notesIP[i].note
    }
  }
  text = notesPrefixTemp + text
  for (i = 0; i < state.notesIS.length; i++){
    if (state.notesIS[i].record){
      for (ii = 0; ii < state.notesRecord.length; ii++){
        if(state.notesIS[i].record == state.notesRecord[ii].record){
          if((info.actionCount - 1) < state.notesRecord[ii].endBy && (info.actionCount - 1) >= state.notesRecord[ii].beginAt && !state.notesRecord[ii].once){
            notesSuffixTemp += state.notesIS[i].note
          } else if (state.notesRecord[ii].once){
            if ((info.actionCount - 1) <= state.notesRecord[ii].beginAt && state.notesRecord[ii].once == 2) {
              state.notesRecord[ii].once = 1
            }
            if ((info.actionCount - 1) >= state.notesRecord[ii].beginAt && state.notesRecord[ii].once == 1){
              state.notesRecord[ii].once = 2
              notesSuffixTemp += state.notesIS[i].note
            }
          }
        }
      }
    } else {
      notesSuffixTemp += state.notesIS[i].note 
    }
  }
  text = text + notesSuffixTemp
}

//this modifies the output with the output special format notes
function noteOutputSpecial(){
  notesTextTemp = ""
  notesPrefixTemp = ""
  notesSuffixTemp = ""
  for (i = 0; i < state.notesOO.length; i++){
    if (state.notesOO[i].record){
      for (ii = 0; ii < state.notesRecord.length; ii++){
        if(state.notesOO[i].record == state.notesRecord[ii].record){
          if(info.actionCount < state.notesRecord[ii].endBy && info.actionCount >= state.notesRecord[ii].beginAt && !state.notesRecord[ii].once){
            notesTextTemp += state.notesOO[i].note 
          } else if (state.notesRecord[ii].once){
            if (info.actionCount <= state.notesRecord[ii].beginAt && state.notesRecord[ii].once == 2) {
              state.notesRecord[ii].once = 1
            }
            if (info.actionCount >= state.notesRecord[ii].beginAt && state.notesRecord[ii].once == 1){
              state.notesRecord[ii].once = 2
              notesTextTemp += state.notesOO[i].note 
            }
          }
        }
      }
    } else {
      notesTextTemp += state.notesOO[i].note 
    }
  }
  if (notesTextTemp){
    text = notesTextTemp
  }
  for (i = 0; i < state.notesOP.length; i++){
    if (state.notesOP[i].record){
      for (ii = 0; ii < state.notesRecord.length; ii++){
        if(state.notesOP[i].record == state.notesRecord[ii].record){
          if(info.actionCount < state.notesRecord[ii].endBy && info.actionCount >= state.notesRecord[ii].beginAt && !state.notesRecord[ii].once){
            notesPrefixTemp += state.notesOP[i].note
          } else if (state.notesRecord[ii].once){
            if (info.actionCount <= state.notesRecord[ii].beginAt && state.notesRecord[ii].once == 2) {
              state.notesRecord[ii].once = 1
            }
            if (info.actionCount >= state.notesRecord[ii].beginAt && state.notesRecord[ii].once == 1){
              state.notesRecord[ii].once = 2
              notesPrefixTemp += state.notesOP[i].note
            }
          }
        }
      }
    } else {
      notesPrefixTemp += state.notesOP[i].note
    }
  }
  text = notesPrefixTemp + text
  for (i = 0; i < state.notesOS.length; i++){
    if (state.notesOS[i].record){
      for (ii = 0; ii < state.notesRecord.length; ii++){
        if(state.notesOS[i].record == state.notesRecord[ii].record){
          if(info.actionCount < state.notesRecord[ii].endBy && info.actionCount >= state.notesRecord[ii].beginAt && !state.notesRecord[ii].once){
            notesSuffixTemp += state.notesOS[i].note
          } else if (state.notesRecord[ii].once){
            if (info.actionCount <= state.notesRecord[ii].beginAt && state.notesRecord[ii].once == 2) {
              state.notesRecord[ii].once = 1
            }
            if (info.actionCount >= state.notesRecord[ii].beginAt && state.notesRecord[ii].once == 1){
              state.notesRecord[ii].once = 2
              notesSuffixTemp += state.notesOS[i].note
            }
          }
        }
      }
    } else {
      notesSuffixTemp += state.notesOS[i].note 
    }
  }
  text = text + notesSuffixTemp
}

function noteMessageInjector(){
  state.message = ""
  for (i = 0; i < state.notesM.length; i++){
    if (state.notesM[i].record){
      for (ii = 0; ii < state.notesRecord.length; ii++){
        if(state.notesM[i].record == state.notesRecord[ii].record){
          if(info.actionCount < state.notesRecord[ii].endBy && info.actionCount >= state.notesRecord[ii].beginAt && !state.notesRecord[ii].once){
            if(i === 0){
              state.message = state.notesM[i].note
            } else if (i > 0){
              state.message += `\n${state.notesM[i].note}`
            }
          } else if (state.notesRecord[ii].once){
            if (info.actionCount <= state.notesRecord[ii].beginAt && state.notesRecord[ii].once == 2) {
              state.notesRecord[ii].once = 1
            }
            if (info.actionCount >= state.notesRecord[ii].beginAt && state.notesRecord[ii].once == 1){
              state.notesRecord[ii].once = 2
              if(i === 0){
                state.message = state.notesM[i].note
              } else if (i > 0){
                state.message += `\n${state.notesM[i].note}`
              }
            }
          }
        }
      }
    } else if(i === 0){
      state.message = state.notesM[i].note
    } else if (i > 0){
      state.message += `\n${state.notesM[i].note}`
    }
  }
}

function noteDisplayInjector(){
  state.displayStats = []
  tempDisplay = {0:{},1:{},2:{},3:{},4:{},5:{},6:{},7:{},8:{},9:{}}
  for (i = 0; i < state.notesD.length; i++){
    tempDisplayLine = Number(state.notesD[i].line) ? Number(state.notesD[i].line) : 0
    if (state.notesD[i].record){
      for (ii = 0; ii < state.notesRecord.length; ii++){
        if(state.notesD[i].record == state.notesRecord[ii].record){
          if(info.actionCount < state.notesRecord[ii].endBy && info.actionCount >= state.notesRecord[ii].beginAt && !state.notesRecord[ii].once){
            if (tempDisplayLine === 0){
              tempDisplay[tempDisplayLine].key = state.notesD[i].key
            } else {
              tempDisplay[tempDisplayLine].key = `\n${state.notesD[i].key}`
            }
            tempDisplay[tempDisplayLine].value = state.notesD[i].value
            tempDisplay[tempDisplayLine].color = state.notesD[i].color ? state.notesD[i].color : ""
          } else if (state.notesRecord[ii].once){
            if (info.actionCount <= state.notesRecord[ii].beginAt && state.notesRecord[ii].once == 2) {
              state.notesRecord[ii].once = 1
            }
            if (info.actionCount >= state.notesRecord[ii].beginAt && state.notesRecord[ii].once == 1){
              state.notesRecord[ii].once = 2
              if (tempDisplayLine === 0){
                tempDisplay[tempDisplayLine].key = state.notesD[i].key
              } else {
                tempDisplay[tempDisplayLine].key = `\n${state.notesD[i].key}`
              }
              tempDisplay[tempDisplayLine].value = state.notesD[i].value
              tempDisplay[tempDisplayLine].color = state.notesD[i].color ? state.notesD[i].color : ""
            }
          }
        }
      }
    } else {
      if (tempDisplayLine === 0){
        tempDisplay[tempDisplayLine].key = state.notesD[i].key
      } else {
        tempDisplay[tempDisplayLine].key = `\n${state.notesD[i].key}`
      }
      tempDisplay[tempDisplayLine].value = state.notesD[i].value
      tempDisplay[tempDisplayLine].color = state.notesD[i].color ? state.notesD[i].color : ""
    }
  }
  var x
  for (x in tempDisplay){
    if (tempDisplay[x].key && tempDisplay[x].value){
      state.displayStats.push(tempDisplay[x])
    }
  }
}

function notesCommands(){
  state.message = ""

  //this is a command to display the last model input
  if(/\n? ?(> You |> You say "|)(\/lmi)/i.test(text)) {
    text = "\n" + state.lmi
    state.contextStop = true
  }

  //this is a command to display the last model input
  if(/\n? ?(> You |> You say "|)(\/reset)/i.test(text)) {
    state.message = "Your cache of duration notes has been cleared."
    state.notesRecord = []
    text = ""
    stop = true
  }

  //this is a command to toggle the AI
  if(/\n? ?(> You |> You say "|)(\/ai)/i.test(text)){
    state.noteAIOff = state.noteAIOff ? false : true
    state.message = state.noteAIOff ? "The AI has been turned off." : "The AI has been turned on."
    text = ""
    stop = true
  }
}
console.log(`Turn: ${info.actionCount}`)
if (!state.data) { state.data = {} }
let dataStorage = state.data;
let contextMemoryLength = 0; // Keep count of additional context added.
if (!state.generate) { state.generate = {} }
if (!state.settings) { state.settings = {} }
if (!state.settings.globalWhitelist) { state.settings.globalWhitelist = [] }
const DefaultSettings = {
    'cross': true,
    'filter': false,
    'mode': true,
}
for (const setting in DefaultSettings) { if (!state.settings.hasOwnProperty(setting)) { state.settings[setting] = DefaultSettings[setting] } }

// Expressions hold re-usable RegEx.
const Expressions = {

    "invalid": /((("|')[^"']*("|'):)\s*({}|null|"")),?\s*/g,
    "clean": /,\s*(?=})/g,
    "listener": /<l=[^>]*>|<\/l>/g,
    "placeholder": /\$\{[^{}]*}/g,
    "attributes": /(\w(=+\d*)?)/g,
    "split": /=+/,
    "EWI": /#\[.*\]$/
}

const Tracker = {}
// Config for consistency.
state.config = {
    prefix: /^\n> You \/|^\n> You say "\/|^\/|^\n\//gi,
    prefixSymbol: '/',
    libraryPath: '_exp',
    whitelistPath: '_whitelist',
    synonymsPath: '_synonyms',
    configPath: '_config',
    wildcardPath: '/*',
    pathSymbol: '.',
    openListener: '<l',
    closeListener: '</l>'
}
let { cross } = state.settings;
const { whitelistPath, synonymsPath, pathSymbol, wildcardPath, configPath, libraryPath, openListener, closeListener } = state.config;
const internalPaths = [whitelistPath, synonymsPath, libraryPath]

// https://www.tutorialspoint.com/group-by-e-in-array-javascript
const groupElementsBy = arr =>
{
    const hash = Object.create(null),
        result = [];
    arr.forEach(el =>
    {
        const keys = el.keys.slice(0, el.keys.indexOf('#'))
        if (!hash[keys])
        {
            hash[keys] = [];
            result.push(hash[keys]);
        };
        hash[keys].push(el);
    });
    return result;
};
//https://stackoverflow.com/questions/61681176/json-stringify-replacer-how-to-get-full-path
const replacerWithPath = (replacer) => { let m = new Map(); return function(field, value) { let path = m.get(this) + (Array.isArray(this) ? `[${field}]` : '.' + field); if (value === Object(value)) m.set(value, path); return replacer.call(this, field, value, path.replace(/undefined\.\.?/, '')); } }
const worldEntriesFromObject = (obj, root) =>
{
    JSON.stringify(obj, replacerWithPath(function(field, value, path)
    {
        if (typeof value != 'object')
        {
            const index = worldEntries.findIndex(e => e["keys"] == `${root}.${path}`.replace(/^\.*|\.$/g, ''));
            index >= 0 ? updateWorldEntry(index, `${root}.${path}`.replace(/^\.*|\.$/g, ''), value.toString(), isNotHidden = true) : addWorldEntry(`${root}.${path}`.replace(/^\.*|\.$/g, ''), value.toString(), isNotHidden = true);
        }
        return value;
    }));
}
//https://stackoverflow.com/questions/273789/is-there-a-version-of-javascripts-string-indexof-that-allows-for-regular-expr#273810
String.prototype.regexLastIndexOf = function(regex, startpos)
{
    regex = (regex.global) ? regex : new RegExp(regex.source, "g" + (regex.ignoreCase ? "i" : "") + (regex.multiLine ? "m" : ""));
    if (typeof(startpos) == "undefined") { startpos = this.length; }
    else if (startpos < 0) { startpos = 0; }
    let stringToWorkWith = this.substring(0, startpos + 1);
    let lastIndexOf = -1;
    let nextStop = 0;
    while ((result = regex.exec(stringToWorkWith)) != null)
    {
        lastIndexOf = result.index;
        regex.lastIndex = ++nextStop;
    }
    return lastIndexOf;
}
const getHistoryString = (turns) => history.slice(turns).map(e => e["text"]).join(' ') // Returns a single string of the text.
const getHistoryText = (turns) => history.slice(turns).map(e => e["text"]) // Returns an array of text.
const getActionTypes = (turns) => history.slice(turns).map(e => e["type"]) // Returns the action types of the previous turns in an array.

// Ensure that '_synonyms' is processed first in the loop. It's executed if (Object.keys(dataStorage)[0] != synonymsPath)
const fixOrder = () =>
{
    dataStorage = Object.assign({ "_whitelist": {}, "_synonyms": {} }, dataStorage);
    state.data = dataStorage
}
const regExMatch = (keys) =>
{
    if (typeof keys != 'string') { console.log(`Invalid Expressions: ${keys}`); return }
    // Test the multi-lines individually, last/bottom line qualifying becomes result.
    const array = keys.split(/\n/g);
    const result = [];
    let key = '';
    try
    {
        array.forEach(line =>
        {

            const attributes = getAttributes(line);
            const length = attributes ? attributes.find(e => e[0] == 'l') : undefined;
            const string = state.settings["mode"] ? getHistoryString(length ? -length[1] : 0).slice(-info.maxChars) : lines.slice(length ? -length[1] : 0).join('\n');
            const expressions = line.slice(0, /#\[.*\]/.test(line) ? line.lastIndexOf('#') : line.length).split(/(?<!\\),/g);
            if (expressions.every(exp => { const regEx = new RegExp(exp.replace(/\\/g, ''), 'i'); return regEx.test(string); }))
            {
                key = line;
                result.push([...string.matchAll(new RegExp(expressions.pop(), 'gi'))].filter(Boolean).pop());
            }
        })
    }
    catch (error)
    {
        console.log(`An invalid RegEx was detected!\n${error.name}: ${error.message}`);
        state.message = `An invalid RegEx was detected!\n${error.name}: ${error.message}`
    }
    return [result.pop(), key]
}

const getAttributes = (string) => { const index = string.search(Expressions["EWI"]); if (index >= 0) { const match = string.slice(index).match(Expressions["attributes"]); if (Boolean(match[0])) { return match.map(e => e.includes('=') ? e.split(Expressions["split"]) : [e, 0]) } } }
const lens = (obj, path) => path.split('.').reduce((o, key) => o && o[key] ? o[key] : null, obj);
const replaceLast = (x, y, z) => { let a = x.split(""); let length = y.length; if (x.lastIndexOf(y) != -1) { for (let i = x.lastIndexOf(y); i < x.lastIndexOf(y) + length; i++) { if (i == x.lastIndexOf(y)) { a[i] = z; } else { delete a[i]; } } } return a.join(""); }
const getMemory = (text) => { return info.memoryLength ? text.slice(0, info.memoryLength) : '' } // If memoryLength is set then slice of the beginning until the end of memoryLength, else return an empty string.
const getContext = (text) => { return info.memoryLength ? text.slice(info.memoryLength) : text } // If memoryLength is set then slice from the end of memory to the end of text, else return the entire text.

// Extract the last cluster in the RegEx' AND check then filter out non-word/non-whitespace symbols to TRY and assemble the intended words.
const addDescription = (entry, value = 0) =>
{
    const result = entry["keys"].pop()
    let search = lines.join('\n');
    // Find a match for the last expression and grab the most recent word for positioning. Filter out undefined/false values.
    if (search.includes(result) && result && !Boolean(value))
    {
        search = search.slice(0, search.toLowerCase().lastIndexOf(result.toLowerCase())) + result.slice(0, -result.length) + entry["entry"] + ' ' + (result) + search.slice(search.toLowerCase().lastIndexOf(result.toLowerCase()) + result.length)
        lines = search.split('\n');
    }
    else if (search.includes(result) && result && Boolean(value))
    {
        search = search.slice(0, search.toLowerCase().lastIndexOf(result.toLowerCase()) + result.length) + ' ' + entry["entry"] + search.slice(search.toLowerCase().lastIndexOf(result.toLowerCase()) + result.length)
        lines = search.split('\n');
    }
}

// Reference to Object is severed during processing, so index it instead.
const addAuthorsNote = (entry, value = 0) => { const index = getEntryIndex(entry["keys"]); if (index >= 0) { state.memory.authorsNote = `${entry["entry"]}` } }
const showWorldEntry = (entry, value = 0) => { const index = getEntryIndex(entry["keys"]); if (index >= 0) { worldEntries[index].isNotHidden = true; } }
const addPositionalEntry = (entry, value = 0) => { spliceContext((Boolean(value) ? -(value) : copyLines.length), entry["entry"]); }
const addMemoryEntry = (entry, value = 0) =>
{
    if ((info.memoryLength + contextMemoryLength + entry["entry"].length) < (info.maxChars / 2))
    {
        spliceMemory(Boolean(value) ? -(value) : (copyMemoryLines.length), entry["entry"]);
    }

}

const addTrailingEntry = (entry, value = 0) =>
{
    let finalIndex = -1;
    copyLines.forEach((line, i) => { if (line.includes(entry["keys"][0])) { finalIndex = i; } })
    if (finalIndex >= 0)
    {
        spliceContext((finalIndex) - value, entry["entry"])
    }
    return;
}

const Attributes = {
    'a': addAuthorsNote, // [a] adds it as authorsNote, only one authorsNote at a time.
    's': showWorldEntry, // [r] reveals the entry once mentioned, used in conjuction with [e] to only reveal if all keywords are mentioned at once.
    'e': () => {}, // [e] tells the custom keyword check to only run the above functions if every keyword of the entry matches.
    'd': addDescription, // [d] adds the first sentence of the entry as a short, parenthesized descriptor to the last mention of the revelant keyword(s) e.g John (a business man)
    'r': () => {}, // [r] picks randomly between entries with the same matching keys. e.g 'you.*catch#[rp=1]' and 'you.*catch#[rd]' has 50% each to be picked.
    'm': addMemoryEntry,
    'p': addPositionalEntry, // Inserts the <entry> <value> amount of lines into context, e.g [p=1] inserts it one line into context.
    'w': () => {}, // [w] assigns the weight attribute, the higher value the more recent/relevant it will be in context/frontMemory/intermediateMemory etc.
    't': addTrailingEntry, // [t] adds the entry at a line relative to the activator in context. [t=2] will trail context two lines behind the activating word.
    'l': () => {}
}

const getWhitelist = () => { const index = getEntryIndex('_whitelist.'); return index >= 0 ? worldEntries[index]["entry"].toLowerCase().split(/,|\n/g).map(e => e.trim()) : [] }
const getWildcard = (display, offset = 0) => { const wildcard = display.split('.').slice(offset != 0 ? 0 : 1).join('.'); const list = display.split('.'); const index = list.indexOf(wildcard.slice(wildcard.lastIndexOf('.') + 1)); return [list[index].replace(wildcardPath, ''), index + offset] }
const getPlaceholder = (value) => typeof value == 'string' ? value.replace(Expressions["placeholder"], match => dataStorage[libraryPath][match.replace(/\$\{|\}/g, '')]) : value
const updateListener = (value, display, visited) =>
{
    // Check if it has previously qualified in 'visited' instead of running regExMatch on each node.
    const qualified = visited.some(e => e.includes(display.split('.')[0]));
    if (qualified)
    {
        const array = value.split(/(?<!\\),/g)
        const result = array.map(e =>
        {
            const find = e.match(/(?<=<l=)[^>]*(?=>)/g)
            if (find)
            {
                const expression = getPlaceholder(find[0])
                const match = regExMatch(`${expression}`)
                if (Boolean(match[0])) { return e.replace(/(?<=>)[^<]*(?=<)/g, match[0][0]) }
                else { return e }

            }
            else { return e }
        })

        const keys = display.toLowerCase().trim()
        const setKeys = display.includes('.') ? keys : `${keys}.`;
        const setValue = result.join(',')
        const index = getEntryIndex(setKeys);
        index >= 0 ? updateWorldEntry(index, setKeys, setValue, isNotHidden = true) : addWorldEntry(setKeys, setValue, isNotHidden = true)

    }
}
const globalReplacer = () =>
{

    const paths = [];
    const search = lines.join('\n')
    // Toggle the wildcard state to search down full path.
    // If the current path does not include the wildcard path, toggle it to false.
    let wildcards = [];
    const visited = [];
    const whitelist = getWhitelist().map(e =>
    {
        if (e.includes(wildcardPath)) { wildcards.push(getWildcard(e, 1)); return e.replace(wildcardPath, ''); }
        else { return e.split('.') }
    }).flat();


    //console.log(`Wildcards: ${wildcards}`)
    function replacer(replace)
    {
        let m = new Map();
        return function(key, value)
        {
            let path = m.get(this) + (Array.isArray(this) ? `[${key}]` : '.' + key);
            let display = path.replace(/undefined\.\.?/, '')
            const root = display.split('.')[0]

            // Find and store whether the Object qualifies to avoid repeated calls to regExMatch.
            // Without this, it'll call regExMatch for each node. While with this one may run:
            // visited.some(e => e.includes(node))
            if (dataStorage.hasOwnProperty(root) && dataStorage[root].hasOwnProperty(synonymsPath) && !visited.some(e => e[0].includes(root)))
            {
                const match = regExMatch(getPlaceholder(dataStorage[root][synonymsPath]))
                if (Boolean(match[0])) { visited.push([root, match[0][0]]) }
            }

            if (value === Object(value)) { m.set(value, path); }

            const final = replace.call(this, key, value, display);
            let current;

            if (Boolean(key) && (whitelist.includes(key)))
            {
                if (typeof value == 'string' && value.includes(closeListener)) { updateListener(value, display, visited); }
            }

            else if (typeof value == 'string')
            {
                // Only match paths in `_synonyms`.
                const match = display.startsWith(synonymsPath) ? regExMatch(getPlaceholder(value)) : undefined;
                if (value.includes(closeListener)) { updateListener(value, display, visited); }
                // Key is a wildcard and its value qualifies the regEx match.
                if (key.includes(wildcardPath) && Boolean(value) && Boolean(match[0])) { wildcards.push(getWildcard(display)) }
                // The current path contains one of the wildcards.
                else if (wildcards.some(e => { if (display.split('.')[e[1]] == e[0]) { current = e[0]; return true } }))
                {
                    const array = display.split('.');
                    paths.push(array);
                }
                else if (display.startsWith(synonymsPath) && Boolean(value) && Boolean(match[0])) { paths.push([display.split('.'), lines.join('\n').lastIndexOf(match[0][match[0].length - 1])]); }

            }
            return final;
        }
    }

    JSON.stringify(dataStorage, replacer(function(key, value, path) { return value; }));
    return [...new Set([...whitelist, ...paths.sort((a, b) => a[1] - b[1]).map(e => e[0]).flat()])].filter(e => !internalPaths.includes(e)).map(e => e.replace(wildcardPath, ''))
}

// globalWhitelist - Should only make one call to it per turn in context modifiers. Other modifiers access it via state.
const getGlobalWhitelist = () => state.settings.globalWhitelist = globalReplacer();
const setProperty = (keys, value, obj) => { const property = keys.split('.').pop(); const path = keys.split('.')[1] ? keys.split('.').slice(0, -1).join('.') : keys.replace('.', ''); if (property[1]) { getKey(path, obj)[property] = value ? value : null; } else { dataStorage[path] = value; } }
const getKey = (keys, obj) => { return keys.split('.').reduce((a, b) => { if (typeof a[b] != "object" || a[b] == null) { a[b] = {} } if (!a.hasOwnProperty(b)) { a[b] = {} } return a && a[b] }, obj) }

const buildObjects = () =>
{

    // Consume and process entries whose keys start with '!' or contains '.' and does not contain a '#'.
    const regEx = /(^!|\.)(?!.*#)/
    worldEntries.filter(wEntry => regEx.test(wEntry["keys"])).forEach(wEntry =>
    {
        if (wEntry["keys"].startsWith('!'))
        {
            const root = wEntry["keys"].match(/(?<=!)[^.]*/)[0];
            try
            {
                // Parse the contents into an Object.
                const object = JSON.parse(wEntry["entry"].match(/{.*}/)[0]);
                // Remove the parsed entry to prevent further executions of this process.
                removeWorldEntry(worldEntries.indexOf(wEntry));
                // Build individual entries of the Object into worldEntries.
                worldEntriesFromObject(object, root);
                // Re-process entries that begin with the exact root path.
                state.message = `Built Objects from !${root}.`
                worldEntries.filter(e => e["keys"].split('.')[0] == root).forEach(wEntry => setProperty(wEntry["keys"].toLowerCase().split(',').filter(e => e.includes('.')).map(e => e.trim()).join(''), wEntry["entry"], dataStorage))
            }
            catch (error)
            {
                console.log(error);
                state.message = `Failed to parse implicit conversion of !${root}. Verify the entry's format!`
            }
        }
        else { setProperty(wEntry["keys"].toLowerCase().split(',').filter(e => e.includes('.')).map(e => e.trim()).join(''), wEntry["entry"], dataStorage); }

    })
}

const sanitizeWhitelist = () => { const index = worldEntries.findIndex(e => e["keys"].includes(whitelistPath)); if (index >= 0) { worldEntries[index]["keys"] = whitelistPath + '.'; } }
const trackRoots = () => { const list = Object.keys(dataStorage); const index = worldEntries.findIndex(e => e["keys"] == 'rootList'); if (index < 0) { addWorldEntry('rootList', list, isNotHidden = true) } else { updateWorldEntry(index, 'rootList', list, isNotHidden = true) } }

// spliceContext takes a position to insert a line into the full context (memoryLines and lines combined) then reconstructs it with 'memory' taking priority.
// TODO: Sanitize and add counter, verify whether memory having priority is detrimental to the structure - 'Remember' should never be at risk of ommitance.
const spliceContext = (pos, string) =>
{

    const linesLength = lines.join('\n').length
    const memoryLength = memoryLines.join('\n').length

    let adjustedLines = 0;
    if ((linesLength + memoryLength) + string.length > info.maxChars)
    {
        const adjustor = lines.join('\n').slice(string.length).split('\n');
        adjustedLines = lines.length - adjustor.length;
        lines = adjustor;
    }
    lines.splice(pos - adjustedLines, 0, string)
    return
}

const spliceMemory = (pos, string) =>
{
    contextMemoryLength += string.length;
    memoryLines.splice(pos, 0, string);
    return

}

const cleanString = (string) => string.replace(/\\/g, '').replace(Expressions["listener"], '').replace(Expressions["invalid"], '').replace(Expressions["clean"], '');
const insertJSON = () =>
{

    // Cleanup edge-cases of empty Objects in the presented string.
    const { globalWhitelist } = state.settings;
    console.log(`Global Whitelist: ${globalWhitelist}`)

    const list = []
    for (const data in dataStorage)
    {

        if (typeof dataStorage[data] == 'object')
        {
            if (!dataStorage[data].hasOwnProperty(synonymsPath)) { dataStorage[data][synonymsPath] = `${data}#[t]` }
            let string = cleanString(JSON.stringify(dataStorage[data], globalWhitelist));
            if (state.settings["filter"]) { string = string.replace(/"|{|}/g, ''); }

            if (string.length > 4)
            {
                const object = { "keys": dataStorage[data][synonymsPath].split('\n').map(e => !e.includes('#') ? e + '#[t]' : e).join('\n'), "entry": `[${string}]` }
                list.push(object)
            }

        }
    }
    if (list.length > 0) { sortObjects(list) };
}

const pickRandom = () =>
{
    const lists = groupElementsBy(worldEntries.filter(e => /#.*\[.*r.*\]/.test(e.keys)));
    const result = [worldEntries.filter(e => !/#.*\[.*r.*\]/.test(e.keys))];
    lists.forEach(e => result.push(e[Math.floor(Math.random() * e.length)]))
    return result.flat()
}
const getEWI = () =>
{
    const entries = pickRandom(); // Ensure unique assortment of entries that adhere to the [r] attribute if present.
    return entries.filter(e => Expressions["EWI"].test(e["keys"]))
}
const processEWI = () => sortObjects(getEWI());
const execAttributes = (keys, entry, attributes) =>
{
    if (attributes.length > 0)
    {
        try
        {
            const object = { "keys": keys, "entry": entry };
            attributes.forEach(pair => { Attributes[pair[0]](object, pair[1]) })
        }
        catch (error) { console.log(`${error.name}: ${error.message}`) }
    }
}

// Sort all Objects/entries by the order of most-recent mention before processing.
// expects sortList to be populated by Objects with properties {"key": string, "entry": string}
const sortObjects = (list) =>
{
    const search = lines.join('\n')
    list.map(e =>
        {
            if (e.hasOwnProperty("keys"))
            {
                const match = regExMatch(getPlaceholder(e["keys"]));

                if (Boolean(match[0]))
                {
                    return { "index": search.lastIndexOf(match[0][match[0].length - 1]), "matches": match, "entry": e["entry"] };
                }
            }
        })
    .filter(Boolean)
    .filter(e => Expressions["EWI"].test(e["matches"][1]))
    .sort((a, b) => b["index"] - a["index"])
    .forEach(e => execAttributes(e["matches"][0], e["entry"], getAttributes(e["matches"][1])))

}

const crossLines = () =>
{
    const JSONLines = lines.filter(line => /\[\{.*\}\]/.test(line));
    const JSONString = JSONLines.join('\n');
    worldEntries.forEach(e =>
    {
        if (e["keys"].includes('.') && !e["keys"].includes('#'))
        {
            e["keys"].split(',').some(keyword =>
            {
                if (JSONString.toLowerCase().includes(keyword.toLowerCase()) && !text.includes(e["entry"]))
                {


                    if (info.memoryLength + contextMemoryLength + e["entry"].length <= info.maxChars / 2)
                    {
                        spliceMemory(memory.split('\n').length, e["entry"]);
                        return true;
                    }
                }
            })
        }
    })
}

const parseAsRoot = (text, root) =>
{
    const toParse = text.match(/{.*}/g);
    if (toParse)
    {
        toParse.forEach(string =>
        {
            const obj = JSON.parse(string);
            worldEntriesFromObject(obj, root);
            text = text.replace(string, '');
        })
    }
}



const getEntryIndex = (keys) => worldEntries.findIndex(e => e["keys"].toLowerCase() == keys.toLowerCase())
const updateHUD = () =>
{
    const { globalWhitelist } = state.settings;
    state.displayStats.forEach((e, i) => { if (dataStorage.hasOwnProperty(e["key"].trim())) { state.displayStats[i] = { "key": `${e["key"].trim()}`, "value": `${cleanString(JSON.stringify(dataStorage[e["key"].trim()], globalWhitelist)).replace(/\{|\}/g, '')}    ` } } })
}
state.commandList = {
    set: // Identifier and name of function
    {
        name: 'set',
        description: "Sets or updates a World Entry's keys and entry to the arguments given in addition to directly updating the object.",
        args: true,
        usage: '<root>.<property> <value>',
        execute: (args) =>
        {

            const keys = args[0].toLowerCase().trim()
            const setKeys = keys.includes('.') ? keys : `${keys}.`;
            const setValue = args.slice(1).join(' ');
            const index = getEntryIndex(setKeys);

            index >= 0 ? updateWorldEntry(index, setKeys, setValue, isNotHidden = true) : addWorldEntry(setKeys, setValue, isNotHidden = true)

            state.message = `Set ${setKeys} to ${setValue}!`
            if (state.displayStats) { updateHUD(); }
            return
        }
    },
    get:
    {
        name: 'get',
        description: "Fetches and displays the properties of an object.",
        args: true,
        usage: '<root> or <root>.<property>',
        execute: (args) =>
        {

            const path = args.join('').toLowerCase().trim();
            if (dataStorage && dataStorage.hasOwnProperty(args[0].split('.')[0].toLowerCase().trim()))
            {
                state.message = `Data Sheet for ${path}:\n${JSON.stringify(lens(dataStorage, path), null)}`;
            }
            else { state.message = `${path} was invalid!` }
            return

        }

    },
    delete:
    {
        name: 'delete',
        description: 'Deletes all dot-separated entries that match the provided argument.',
        args: true,
        usage: '<root> or <root>.<path>',
        execute: (args) =>
        {

            const keys = args[0].toLowerCase().trim();
            const setKeys = keys.includes('.') ? keys : `${keys}.`;
            worldEntries.filter(e => e["keys"].toLowerCase().startsWith(setKeys)).forEach(e => removeWorldEntry(worldEntries.indexOf(e)))
            state.message = `Deleted all entries matching: ${keys}`;
        }
    },
    show:
    {
        name: 'show',
        description: "Shows entries starting with the provided argument in World Information.",
        args: true,
        usage: '<root> or <root>.<property>',
        execute: (args) =>
        {

            const keys = args[0].toLowerCase()
            worldEntries.forEach(e => { if (e["keys"].toLowerCase().startsWith(keys)) { e["isNotHidden"] = true; } })
            state.message = `Showing all entries starting with ${keys} in World Information!`;
            return
        }
    },
    hide:
    {
        name: 'hide',
        description: "Hides entries starting with the provided argument in World Information.",
        args: true,
        usage: '<root> or <root>.<property>',
        execute: (args) =>
        {

            const keys = args[0].toLowerCase()
            worldEntries.forEach(e => { if (e["keys"].toLowerCase().startsWith(keys)) { e["isNotHidden"] = false; } })
            state.message = `Hiding all entries starting with ${keys} in World Information!`;
            return
        }
    },
    cross:
    {
        name: 'cross',
        description: `Toggles fetching of World Information from JSON Lines: ${state.settings["cross"]}`,
        args: false,
        execute: (args) =>
        {

            state.settings["cross"] = !state.settings["cross"];
            state.message = `World Information from JSON Lines: ${state.settings["cross"]}`
            return
        }
    },
    filter:
    {
        name: 'filter',
        description: `Toggles the filtering of quotation and curly-brackets within JSON lines: ${state.settings["filter"]}\nSaves character count, but may have detrimental effects.`,
        args: false,
        execute: (args) =>
        {
            state.settings["filter"] = !state.settings["filter"];
            state.message = `'"{}' filter set to ${state.settings["filter"]}`
            return
        }
    },
    from:
    {
        name: "from",
        description: 'Creates an Object with the given root from the passed JSON- line.',
        args: true,
        usage: '<root> <JSON- Line/Object>',
        execute: (args) =>
        {
            const obj = args.slice(1).join(' ')
            const root = args[0]
            parseAsRoot(obj, root)
            state.message = `Created Object '${root}' from ${obj}!`

        }
    },
    hud:
    {
        name: "hud",
        description: "Tracks the Object in the HUD",
        args: true,
        usage: '<root>',
        execute: (args) =>
        {

            if (!state.displayStats) { state.displayStats = [] }
            //getGlobalWhitelist(getHistoryString(-10).slice(-info.maxChars))
            const { globalWhitelist } = state.settings;
            const root = args[0].trim();
            const index = state.displayStats.findIndex(e => e["key"].trim() == root)

            if (dataStorage.hasOwnProperty(root))
            {
                const object = { "key": root, "value": `${cleanString(JSON.stringify(dataStorage[root], globalWhitelist).replace(/\{|\}/g, '')).replace(/\{|\}/g, '')}    ` }
                if (index >= 0) { state.displayStats.splice(index, 1) }
                else { state.displayStats.push(object) }
            }

        }
    },
    mode:
    {
        name: "mode",
        description: "Switches between actions (true) or lines (false) for conditions.",
        args: false,
        usage: '',
        execute: (args) =>
        {
            state.settings.mode = !state.settings.mode
            state.message = `Conditions now search amount of ${state.settings.mode == true ? 'actions' : 'lines'}.`
        }
    }


};
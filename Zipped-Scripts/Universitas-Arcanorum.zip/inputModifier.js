const modifier = (text) => {    
  modifiedText = text
  stop = false  
  const lowered = text.toLowerCase()

  var commandMatcher = text.match(/\n? ?(?:> You |> You say "|)\/(\w+?)( [\w ]+)?[".]?\n?$/i) ? text.match(/\n? ?(?:> You |> You say "|)\/(\w+?)( [\w ]+)?[".]?\n?$/i) : []
  var command = commandMatcher[1]
  var enCommandMatcher = text.match(/\n? ?(> You |> You say "|)(\/\w*)? ?(.*)/i) ? text.match(/\n? ?(> You |> You say "|)(\/\w*)? ?(.*)/i) : []
  var enCommand = enCommandMatcher[2]
  var enArgs = enCommandMatcher[3]
  if(enCommandMatcher[1] == '> You ' || enCommandMatcher[1] == '> You say "'){
    enArgs = enCommandMatcher[3].substring(0, enCommandMatcher[3].length - 1)
  }
  
  state.set.args = commandMatcher[2] ? commandMatcher[2].trim().split(' ') : []

  state.set.bookStart = 0
  state.set.bookEnd = 0
  state.message = ""

  if(!state.checkClass){
    for(i in state.skills){
      if(lowered.includes("school of " + `${i}`.toLowerCase())){
        state.skills[`${i}`] += 2
        state.character.major = `${i}`
      }
    }

    state.checkClass = true
  }
  
  familiarCheck()
  familiarVerbs()
  familiarNouns()
  familiarCheck()
  
  if(command == "rationale"){
    state.set.rationale = state.set.rationale ? false : true
    state.set.args = []
    text = null; stop = true; return{ text, stop }
  }

  if(command == "comment"){
    state.set.commentary = state.set.commentary ? false : true
    state.set.args = []
    text = null; stop = true; return{ text, stop }
  }

  if(command == "commands"){
    state.message = "/clear — remove the message (this text)\n/comment — familiar chat messages (toggle; default on)\n/rationale — exp gain messages (toggle; default off)\n/level — show current level & exp to next\n/tic — tic display (toggle; used for event timing)\n/en, /hang, /editor, /display — E/N script. See scenario comments for details." 
    state.set.args = []
    text = null; stop = true; return{ text, stop }
  }

  if(command == "secrets"){
    state.message = "/cheat — gain +100 skill points\n/exp — gain +100 exp\n/hic — make everyone drunk (toggle)\n/tits — make breasts the primary casting appendage (toggle)\n/lewd — force-start sex scenes (toggle)"
    state.set.args = []
    text = null; stop = true; return{ text, stop }
  }

  if(command == "cheat"){
    state.skillPoints += 100
    state.set.args = []
    text = null; stop = true; return{ text, stop }
  }

  if(command == "clear" || command == "hide"){
    state.message = ""
    state.set.args = []
    text = null; stop = true; return{ text, stop }
  }

  if(command == "exp"){
    state.level.currentExp += 100
    state.set.args = []
    text = null; stop = true; return{ text, stop }
  }

  if(command == "level"){
    state.message = `Current level: ${state.level.player}. Experience required for next level: ` + (state.level.expReq - state.level.currentExp)
    state.set.args = []
    text = null; stop = true; return{ text, stop }
  }

  if(command == "tic"){
    state.set.ticDisplay = state.set.ticDisplay ? false : true
    state.set.args = []
    modifiedText = ""
    state.set.comToggle = true
    state.set.enDisplay = false
  }
  
  if(state.set.ticDisplay){
    state.displayStats = [{key: "tic", value: state.set.tic, color: "green"}]
   }

   if(state.set.comToggle){
    state.set.comToggle = false
    text = null; stop = true; return{ text, stop }
  }

  if(command == "hic"){
    state.set.meme = state.set.meme ? "" : "[Author's note: everyone has been drinking heavily. Everyone is drunk right now.]"
    state.set.args = []
    text = null; stop = true; return{ text, stop }
  }

  if(command == "tits"){
    state.set.meme = state.set.meme ? "" : "[Author's note: every casts spells using breasts and cleavage.]"
    state.set.args = []
    text = null; stop = true; return{ text, stop }
  }

  if(command == "lewd"){
    state.set.meme = state.set.meme ? "" : "[Editor's note: write the next paragraph as a sex scene.]"
    state.set.args = []
    text = null; stop = true; return{ text, stop }
  }

  if(enCommand == "/enhelp"){
    var helpText = "E/N Commands:\n/en 𝘵𝘦𝘹𝘵 — creates an E/N using 𝘵𝘦𝘹𝘵 that lasts for one action\n/float 𝘵𝘦𝘹𝘵 — creates unformatted floating text using 𝘵𝘦𝘹𝘵\n/editor — toggles Editor Mode (all inputs are converted into E/Ns)\n/display — toggles whether E/Ns are shown in the top text.\n/auto — toggles whether you automatically submit a minimal (\" \") input after setting an E/N\n/format — toggles whether E/N formatting includes \" this scene:<\"\n/endist # — sets how many lines back E/Ns float (default: 0; in front of text)\n/floatdist — sets how many lines back /float text floats (default: 1) #"
    state.set.enHelp = state.set.enHelp ? false : true
    state.message = state.set.enHelp ? helpText : ""
    text = null; stop = true; return{ text, stop }
  }

  if(enCommand == "/auto"){
    state.set.enAuto = state.set.enAuto ? false : true
    state.message = state.set.enAuto ? "Auto mode on." : "Auto mode off."
    text = null; stop = true; return{ text, stop }
  }

  if(enCommand == "/format"){
    state.set.enFormat = state.set.enFormat ? false : true
    state.message = state.set.enFormat ? `E/N format is now "[Editor's note: this scene< 𝘵𝘦𝘹𝘵>.]` : `E/N format is now "[Editor's note: 𝘵𝘦𝘹𝘵.]`
    state.set.enFormatStart = state.set.enFormat ? "[Editor's note: this scene:< " : "[Editor's note: "
    state.set.enFormatEnd = state.set.enFormat ? ">.]" : ".]"
    text = null; stop = true; return{ text, stop }
  }

  if(enCommand == "/endist"){
    if(Number(enArgs)){
      state.set.enDist = Number(enArgs)
      state.message = `E/N distance set to above the ${enArgs} most recent lines of text.`
    } else {
      state.set.enDist = 0
      state.message = `E/N distance set to 0 (hanging beneath all text).`
    }
    text = null; stop = true; return{ text, stop }
  }

  if(enCommand == "/floatdist"){
    if(Number(enArgs)){
      state.set.floatDist = Number(enArgs)
      state.message = `Float distance set to above the ${enArgs} most recent lines of text.`
    } else {
      state.set.floatDist = 0
      state.message = `Float distance set to 0 (hanging beneath all text).`
    }
    text = null; stop = true; return{ text, stop }
  }

  if(enCommand == "/display"){
    state.set.enDisplay = state.set.enDisplay ? false : true
    state.message = state.set.enDisplay ? "E/N display on." : "E/N display off."
    if (state.set.enDisplay){
      state.displayStats = state.set.en ? [{key: "E/N", value: state.set.en}] : []
    } else {
      state.displayStats = []
    }
    text = null; stop = true; return{ text, stop }
  }

  if(enCommand == "/float"){
    state.set.float = enArgs ? enArgs : ""
    text = null; stop = true; return{ text, stop }
  }

  if(enCommand == "/en"){
    state.set.en = enArgs ? `${state.set.enFormatStart}${enArgs}${state.set.enFormatEnd}` : ""
    state.set.actionCount = enArgs ? info.actionCount : 0
    if(state.set.enDisplay){
      state.displayStats = state.set.en ? [{key: "E/N", value: state.set.en}] : []
    }
    if(state.set.enAuto){
      modifiedText = " "
      if(state.set.actionCount){
        state.set.actionCount++
      }
    } else {
      text = null; stop = true; return{ text, stop }
    }
  }

  if(enCommand == "/editor"){
    state.set.em = state.set.em ? false : true
    state.set.en = state.set.em ? state.set.en : ""
    state.message = state.set.em ? "Editor mode enabled." : "Editor mode disabled."
    text = null; stop = true; return{ text, stop }
  }

  if(state.set.em && !enCommand){
    state.set.actionCount = enArgs ? 0 : state.set.actionCount
    state.set.en = enArgs ? `${state.set.enFormatStart}${enArgs}${state.set.enFormatEnd}` : ""
    if(state.set.enDisplay){
      state.displayStats = state.set.en ? [{key: "E/N", value: state.set.en}] : []
    }
    if(state.set.enAuto && enArgs){
      modifiedText = " "
    } else {
      text = null; stop = true; return{ text, stop }
    }
  }

  state.set.args = []

  return ({text : modifiedText})
}

modifier(text)

//  if (command == "learn"){
//    if (Number(state.set.args[1])){
//      var spellLevel = Number(state.set.args[1])
//      var spellSchool = toTitleCase(state.set.args[0])
//      var spellName = toTitleCase(state.set.args.splice(2).join(" "))
//      state.character.spellsKnown.push({level: spellLevel, name: spellName, school: spellSchool})
//      modifiedText = ""
//    }
//  }

//  for(var i = 0; i < state.spells.wizard.length; i++ ){
//    state.spells.wizard[i].isCast = false
//  }

//  if(/cast|summon|conjure|evoke|enchant|transmute|abjure/.exec(lowered)){
//    for(var i = 0; i < state.spells.wizard.length; i++ ){
//      var spellName = new RegExp(`\\b${state.spells.wizard[i].name.toLowerCase()}\\b`)
//      if(spellName.exec(lowered)){
//        state.spells.wizard[i].isCast = true
//      }
//    }
//  }
const modifier = (text) => {    
  let modifiedText = text
  stop = false  
  const lowered = text.toLowerCase()
  
  if(!state.setup){
    state.setup = true
    state.set = {tog: 0, args: [], finalMessageAdd: "", castingNote: "", tic: 0, ticOn: false, enToggle: false, eventMessage: false, em: false, emDisplay: false, emtoggle: false}
    state.set.electives1 = ["Risks of Brownies", "Fundamental Fundamentals of Mystical Holidays", "Mythical Lucid Dreams",  "Popular Demons", "Kelpie Dynamics", "Principles of Ritual", "Potioncraft 101", "Unknown Curses", "Basics of Emotional Sorcery", "Fantastic Runes and their Uses", "Delightful Wolpertingers"]
    state.set.advisors = {'Abjuration': "Master Nuro", 'Conjuration': "Professor Amarillis", 'Divination': "Mistress Acossia", 'Enchantment': "Mistress Menolis", 'Evocation': "Azagral", 'Illusion': "Mistress Eldolith", 'Necromancy': "Master Neverexus", 'Transmutation': "Mistress Yvette"}
    state.event = {hold : "", times: [3, 8], note: ""}
    state.character = {note:"", spellsKnown: [], spellsNote: "", spellsBook: ""}
    state.character.name = memory.match(/(?<=(name≡.))(.*?)(?=(>.<))/) ? memory.match(/(?<=(name≡.))(.*?)(?=(>.<))/)[0] : "You"
    state.familiar = {name: "none", type: "none"}
    state.skills = {'Abjuration': 0, 'Conjuration': 0, 'Divination': 0, 'Enchantment': 0, 'Evocation': 0, 'Illusion': 0, 'Necromancy': 0, 'Transmutation': 0}
    state.skillTerms = ["incapable", "unskilled", "neophyte", "novice", "apprentice", "journeyman", "adept", "expert", "master", "grandmaster", "super grandmaster", "super grandmaster", "super grandmaster", "super grandmaster", "super grandmaster", "super grandmaster"]
    state.skillPoints = 0
    state.disableRandomSkill = true
    state.level= {expReq : 40, currentExp : 0, player : 1} 
    for (i in state.skills){
      if(getRandomInt(4) == 3){
        state.skills[`${i}`] += 1
      }
    }
    state.set.el1 = getRandomInt(11)
    state.set.el2 = getRandomInt(11)
    do {
      state.set.el2 = getRandomInt(11);
      } while(state.set.el2 === state.set.el1);
    state.spells = {}
    state.spells.wizard = [{level: 0, name: "Blade Ward", school: "Abjuration", floatText: "", isCast: false},
    {level: 0, name: "Chill Touch", school: "Necromancy", floatText: "", isCast: false},
    {level: 0, name: "Create Bonfire", school: "Conjuration", floatText: "", isCast: false},
    {level: 0, name: "Friends", school: "Enchantment", floatText: "", isCast: false},
    {level: 0, name: "Fire Bolt", school: "Evocation", floatText: "", isCast: false},
    {level: 0, name: "Gust", school: "Transmutation", floatText: "", isCast: false},
    {level: 0, name: "Light", school: "Divination", floatText: "<<test>>", isCast: false},
    {level: 0, name: "True Strike", school: "Divination", floatText: "", isCast: false},
    {level: 0, name: "Mage Hand", school: "Conjuration", floatText: "", isCast: false},
    {level: 0, name: "Mending", school: "Transmutation", floatText: "", isCast: false},
    {level: 0, name: "Minor Illusion", school: "Illusion", floatText: "", isCast: false},
    {level: 0, name: "Poison Spray", school: "Conjuration", floatText: "", isCast: false},
    {level: 0, name: "Prestidigitation", school: "Transmutation", floatText: "", isCast: false},
    {level: 0, name: "Shocking Grasp", school: "Evocation", floatText: "", isCast: false},
    {level: 1, name: "Absorb Elements", school: "Abjuration", floatText: "", isCast: false},
    {level: 1, name: "Burning Hands", school: "Evocation", floatText: "", isCast: false},
    {level: 1, name: "Catapult", school: "Transmutation", floatText: "", isCast: false},
    {level: 1, name: "Cause Fear", school: "Necromancy", floatText: "", isCast: false},
    {level: 1, name: "Charm Person", school: "Enchantment", floatText: "", isCast: false},
    {level: 1, name: "Chromatic Orb", school: "Evocation", floatText: "", isCast: false},
    {level: 1, name: "Color Spray", school: "Illusion", floatText: "", isCast: false},
    {level: 1, name: "Detect Magic", school: "Divination", floatText: "", isCast: false},
    {level: 1, name: "Disguise Self", school: "Illusion", floatText: "", isCast: false},
    {level: 1, name: "Expeditious Retreat", school: "Transmutation", floatText: "", isCast: false},
    {level: 1, name: "Feather Fall", school: "Transmutation", floatText: "", isCast: false},
    {level: 1, name: "Find Familiar", school: "Conjuration", floatText: "", isCast: false},
    {level: 1, name: "Fog Cloud", school: "Conjuration", floatText: "", isCast: false},
    {level: 1, name: "Grease", school: "Conjuration", floatText: "", isCast: false},
    {level: 1, name: "Identify", school: "Divination", floatText: "", isCast: false},
    {level: 1, name: "Jump", school: "Transmutation", floatText: "", isCast: false},
    {level: 1, name: "Mage Armor", school: "Abjuration", floatText: "", isCast: false},
    {level: 1, name: "Magic Missile", school: "Evocation", floatText: "", isCast: false},
    {level: 1, name: "Protection from Evil and Good", school: "Abjuration", floatText: "", isCast: false},
    {level: 1, name: "Ray of Sickness", school: "Necromancy", floatText: "", isCast: false},
    {level: 1, name: "Shield", school: "Abjuration", floatText: "", isCast: false},
    {level: 1, name: "Silent Image", school: "Illusion", floatText: "", isCast: false},
    {level: 1, name: "Sleep", school: "Enchantment", floatText: "", isCast: false},
    {level: 2, name: "Alter Self", school: "Transmutation", floatText: "", isCast: false},
    {level: 2, name: "Arcane Lock", school: "Abjuration", floatText: "", isCast: false},
    {level: 2, name: "Barkskin", school: "Transmutation", floatText: "", isCast: false},
    {level: 2, name: "Blindness", school: "Necromancy", floatText: "", isCast: false},
    {level: 2, name: "Blur", school: "Illusion", floatText: "", isCast: false},
    {level: 2, name: "Crown of Madness", school: "Enchantment", floatText: "", isCast: false},
    {level: 2, name: "Darkness", school: "Evocation", floatText: "", isCast: false},
    {level: 2, name: "Darkvision", school: "Transmutation", floatText: "", isCast: false},
    {level: 2, name: "Detect Thoughts", school: "Divination", floatText: "", isCast: false},
    {level: 2, name: "Earthbind", school: "Transmutation", floatText: "", isCast: false},
    {level: 2, name: "Enlarge/Reduce", school: "Transmutation", floatText: "", isCast: false},
    {level: 2, name: "Flaming Sphere", school: "Conjuration", floatText: "", isCast: false},
    {level: 2, name: "Hold Person", school: "Enchantment", floatText: "", isCast: false},
    {level: 2, name: "Invisibility", school: "Illusion", floatText: "", isCast: false},
    {level: 2, name: "Knock", school: "Transmutation", floatText: "", isCast: false},
    {level: 2, name: "Levitate", school: "Transmutation", floatText: "", isCast: false},
    {level: 2, name: "Magic Weapon", school: "Transmutation", floatText: "", isCast: false},
    {level: 2, name: "Earthen Grasp", school: "Transmutation", floatText: "", isCast: false},
    {level: 2, name: "Acid Arrow", school: "Evocation", floatText: "", isCast: false},
    {level: 2, name: "Mind Spike", school: "Divination", floatText: "", isCast: false},
    {level: 2, name: "Mirror Image", school: "Illusion", floatText: "", isCast: false},
    {level: 2, name: "Misty Step", school: "Conjuration", floatText: "", isCast: false},
    {level: 2, name: "Phantasmal Force", school: "Illusion", floatText: "", isCast: false},
    {level: 2, name: "Ray of Enfeeblement", school: "Necromancy", floatText: "", isCast: false},
    {level: 2, name: "Rope Trick", school: "Transmutation", floatText: "", isCast: false},
    {level: 2, name: "Scorching Ray", school: "Evocation", floatText: "", isCast: false},
    {level: 2, name: "Shatter", school: "Evocation", floatText: "", isCast: false},
    {level: 2, name: "Spider Climb", school: "Transmutation", floatText: "", isCast: false},
    {level: 2, name: "Suggestion", school: "Enchantment", floatText: "", isCast: false},
    {level: 2, name: "Web", school: "Conjuration", floatText: "", isCast: false},
    {level: 3, name: "Animate Dead", school: "Necromancy", floatText: "", isCast: false},
    {level: 3, name: "Bestow Curse", school: "Necromancy", floatText: "", isCast: false},
    {level: 3, name: "Blink", school: "Transmutation", floatText: "", isCast: false},
    {level: 3, name: "Clairvoyance", school: "Divination", floatText: "", isCast: false},
    {level: 3, name: "Counterspell", school: "Abjuration", floatText: "", isCast: false},
    {level: 3, name: "Dispel Magic", school: "Abjuration", floatText: "", isCast: false},
    {level: 3, name: "Erupting Earth", school: "Transmutation", floatText: "", isCast: false},
    {level: 3, name: "Fear", school: "Illusion", floatText: "", isCast: false},
    {level: 3, name: "Fireball", school: "Evocation", floatText: "", isCast: false},
    {level: 3, name: "Flame Arrows", school: "Transmutation", floatText: "", isCast: false},
    {level: 3, name: "Fly", school: "Transmutation", floatText: "", isCast: false},
    {level: 3, name: "Glyph of Warding", school: "Abjuration", floatText: "", isCast: false},
    {level: 3, name: "Haste", school: "Transmutation", floatText: "", isCast: false},
    {level: 3, name: "Hypnotic Pattern", school: "Illusion", floatText: "", isCast: false},
    {level: 3, name: "Lightning Bolt", school: "Evocation", floatText: "", isCast: false},
    {level: 3, name: "Magic Circle", school: "Abjuration", floatText: "", isCast: false},
    {level: 3, name: "Major Image", school: "Illusion", floatText: "", isCast: false},
    {level: 3, name: "Sleet Storm", school: "Conjuration", floatText: "", isCast: false},
    {level: 3, name: "Slow", school: "Transmutation", floatText: "", isCast: false},
    {level: 3, name: "Stinking Cloud", school: "Conjuration", floatText: "", isCast: false},
    {level: 3, name: "Tidal Wave", school: "Conjuration", floatText: "", isCast: false},
    {level: 3, name: "Vampiric Touch", school: "Necromancy", floatText: "", isCast: false},
    {level: 3, name: "Wall of Sand", school: "Evocation", floatText: "", isCast: false},
    {level: 3, name: "Water Breathing", school: "Transmutation", floatText: "", isCast: false},
    {level: 3, name: "Conjure Elemental", school: "Conjuration", floatText: "", isCast: false},
    {level: 4, name: "Arcane Eye", school: "Divination", floatText: "", isCast: false},
    {level: 4, name: "Banishment", school: "Abjuration", floatText: "", isCast: false},
    {level: 4, name: "Blight", school: "Necromancy", floatText: "", isCast: false},
    {level: 4, name: "Charm Monster", school: "Enchantment", floatText: "", isCast: false},
    {level: 4, name: "Confusion", school: "Enchantment", floatText: "", isCast: false},
    {level: 4, name: "Control Water", school: "Transmutation", floatText: "", isCast: false},
    {level: 4, name: "Dimension Door", school: "Conjuration", floatText: "", isCast: false},
    {level: 4, name: "Fire Shield", school: "Evocation", floatText: "", isCast: false},
    {level: 4, name: "Greater Invisibility", school: "Illusion", floatText: "", isCast: false},
    {level: 4, name: "Ice Storm", school: "Evocation", floatText: "", isCast: false},
    {level: 4, name: "Locate Creature", school: "Divination", floatText: "", isCast: false},
    {level: 4, name: "Phantasmal Killer", school: "Illusion", floatText: "", isCast: false},
    {level: 4, name: "Polymorph", school: "Transmutation", floatText: "", isCast: false},
    {level: 4, name: "Stoneskin", school: "Abjuration", floatText: "", isCast: false},
    {level: 4, name: "Summon Demon", school: "Conjuration", floatText: "", isCast: false},
    {level: 4, name: "Vitriolic Sphere", school: "Evocation", floatText: "", isCast: false},
    {level: 4, name: "Wall of Fire", school: "Evocation", floatText: "", isCast: false},
    {level: 4, name: "Watery Sphere", school: "Conjuration", floatText: "", isCast: false},
    {level: 5, name: "Bigby's Hand", school: "Evocation", floatText: "", isCast: false},
    {level: 5, name: "Cloudkill", school: "Conjuration", floatText: "", isCast: false},
    {level: 5, name: "Cone of Cold", school: "Evocation", floatText: "", isCast: false},
    {level: 5, name: "Conjure Elemental", school: "Conjuration", floatText: "", isCast: false},
    {level: 5, name: "Control Winds", school: "Transmutation", floatText: "", isCast: false},
    {level: 5, name: "Dominate Person", school: "Enchantment", floatText: "", isCast: false},
    {level: 5, name: "Dream", school: "Illusion", floatText: "", isCast: false},
    {level: 5, name: "Enervation", school: "Necromancy", floatText: "", isCast: false},
    {level: 5, name: "Geas", school: "Enchantment", floatText: "", isCast: false},
    {level: 5, name: "Hold Monster", school: "Enchantment", floatText: "", isCast: false},
    {level: 5, name: "Negative Energy Field", school: "Necromancy", floatText: "", isCast: false},
    {level: 5, name: "Scrying", school: "Divination", floatText: "", isCast: false},
    {level: 5, name: "Seeming", school: "Illusion", floatText: "", isCast: false},
    {level: 5, name: "Telekinesis", school: "Transmutation", floatText: "", isCast: false},
    {level: 5, name: "Teleportation Circle", school: "Conjuration", floatText: "", isCast: false},
    {level: 5, name: "Transmute Rock", school: "Transmutation", floatText: "", isCast: false},
    {level: 5, name: "Wall of Force", school: "Evocation", floatText: "", isCast: false},
    {level: 6, name: "Chain Lightning", school: "Evocation", floatText: "", isCast: false},
    {level: 6, name: "Circle of Death", school: "Necromancy", floatText: "", isCast: false},
    {level: 6, name: "Create Undead", school: "Necromancy", floatText: "", isCast: false},
    {level: 6, name: "Disintegrate", school: "Transmutation", floatText: "", isCast: false},
    {level: 6, name: "Eyebite", school: "Necromancy", floatText: "", isCast: false},
    {level: 6, name: "Flesh to Stone", school: "Transmutation", floatText: "", isCast: false},
    {level: 6, name: "Globe of Invulnerability", school: "Abjuration", floatText: "", isCast: false},
    {level: 6, name: "Mass Suggestion", school: "Enchantment", floatText: "", isCast: false},
    {level: 6, name: "Mental Prison", school: "Illusion", floatText: "", isCast: false},
    {level: 6, name: "Move Earth", school: "Transmutation", floatText: "", isCast: false},
    {level: 6, name: "Sunbeam", school: "Evocation", floatText: "", isCast: false},
    {level: 6, name: "True Seeing", school: "Divination", floatText: "", isCast: false},
    {level: 6, name: "Wall of Ice", school: "Evocation", floatText: "", isCast: false},
    {level: 7, name: "Etherealness", school: "Transmutation", floatText: "", isCast: false},
    {level: 7, name: "Finger of Death", school: "Necromancy", floatText: "", isCast: false},
    {level: 7, name: "Forcecage", school: "Evocation", floatText: "", isCast: false},
    {level: 7, name: "Mirage Arcane", school: "Illusion", floatText: "", isCast: false},
    {level: 7, name: "Plane Shift", school: "Conjuration", floatText: "", isCast: false},
    {level: 7, name: "Prismatic Spray", school: "Evocation", floatText: "", isCast: false},
    {level: 7, name: "Reverse Gravity", school: "Transmutation", floatText: "", isCast: false},
    {level: 7, name: "Teleport", school: "Conjuration", floatText: "", isCast: false},
    {level: 7, name: "Whirlwind", school: "Evocation", floatText: "", isCast: false},
    {level: 8, name: "Antimagic Field", school: "Abjuration", floatText: "", isCast: false},
    {level: 8, name: "Control Weather", school: "Transmutation", floatText: "", isCast: false},
    {level: 8, name: "Demiplane", school: "Conjuration", floatText: "", isCast: false},
    {level: 8, name: "Dominate Monster", school: "Enchantment", floatText: "", isCast: false},
    {level: 8, name: "Feeblemind", school: "Enchantment", floatText: "", isCast: false},
    {level: 8, name: "Illusory Dragon", school: "Illusion", floatText: "", isCast: false},
    {level: 8, name: "Incendiary Cloud", school: "Conjuration", floatText: "", isCast: false},
    {level: 8, name: "Maddening Darkness", school: "Evocation", floatText: "", isCast: false},
    {level: 8, name: "Maze", school: "Conjuration", floatText: "", isCast: false},
    {level: 8, name: "Mind Blank", school: "Abjuration", floatText: "", isCast: false},
    {level: 8, name: "Sunburst", school: "Evocation", floatText: "", isCast: false},
    {level: 9, name: "Astral Projection", school: "Necromancy", floatText: "", isCast: false},
    {level: 9, name: "Foresight", school: "Divination", floatText: "", isCast: false},
    {level: 9, name: "Gate", school: "Conjuration", floatText: "", isCast: false},
    {level: 9, name: "Invulnerability", school: "Abjuration", floatText: "", isCast: false},
    {level: 9, name: "Mass Polymorph", school: "Transmutation", floatText: "", isCast: false},
    {level: 9, name: "Meteor Swarm", school: "Evocation", floatText: "", isCast: false},
    {level: 9, name: "Power Word Kill", school: "Enchantment", floatText: "", isCast: false},
    {level: 9, name: "Prismatic Wall", school: "Abjuration", floatText: "", isCast: false},
    {level: 9, name: "Psychic Scream", school: "Enchantment", floatText: "", isCast: false},
    {level: 9, name: "Time Stop", school: "Transmutation", floatText: "", isCast: false},
    {level: 9, name: "True Polymorph", school: "Transmutation", floatText: "", isCast: false},
    {level: 9, name: "Weird", school: "Illusion", floatText: "", isCast: false},
    {level: 9, name: "Wish", school: "Conjuration", floatText: "", isCast: false}]
  }

  var enCommandMatcher = text.match(/\n? ?(?:> You |> You say "|)\/(\w*)(.*)/i) ? text.match(/\n? ?(?:> You |> You say "|)\/(\w*)(.*)/i) : []
  var enCommand = enCommandMatcher[1]
  var commandMatcher = text.match(/\n? ?(?:> You |> You say "|)\/(\w+?)( [\w ]+)?[".]?\n?$/i) ? text.match(/\n? ?(?:> You |> You say "|)\/(\w+?)( [\w ]+)?[".]?\n?$/i) : []
  var command = commandMatcher[1]
  var editorText = text.match(/\n? ?(?:> You |> You say "|)(.*)/s) ? text.match(/\n? ?(?:> You |> You say "|)(.*)/s)[1] : ""
  
  if(editorText == `/${command}`){ 
    editorText = ""
  }
  
  state.set.args = commandMatcher[2] ? commandMatcher[2].trim().split(' ') : []

  state.set.bookStart = 0
  state.set.bookEnd = 0
  state.message = ""

  if(!state.checkClass){
    for(i in state.skills){
      if(lowered.includes("school of " + `${i}`.toLowerCase())){
        state.skills[`${i}`] += 2
        state.character.major = `${i}`
      }
    }

    state.checkClass = true
  }
  
  if (command == "learn"){
    if (Number(state.set.args[1])){
      var spellLevel = Number(state.set.args[1])
      var spellSchool = toTitleCase(state.set.args[0])
      var spellName = toTitleCase(state.set.args.splice(2).join(" "))
      state.character.spellsKnown.push({level: spellLevel, name: spellName, school: spellSchool})
      modifiedText = ""
    }
  }

  state.character.note = "[ you skills:"
  for(i in state.skills){
    if(state.skills[`${i}`]){
      state.character.note += `< ` + `${i}`.toLowerCase() + `≡ ${state.skillTerms[`${state.skills[`${i}`]}`]}>.\n`      
    }
  }
  state.character.note = state.character.note.slice(0, -1)
  state.character.note += "]"  
  
  state.character.spellsKnown = []
  for (var i = 0; i < state.spells.wizard.length; i++){
    x = state.spells.wizard
    if(state.skills[`${x[`${i}`].school}`] > x[`${i}`].level) {
      state.character.spellsKnown.push(x[`${i}`])
    }
  }

  state.character.spellsBook = "⚚ Spellbook\n"
  for(var i in state.skills){
    var x = state.character
    if(state.skills[`${i}`] >= 1){
      x.spellsBook += `${i}:`
      for(var ii = 0; ii < x.spellsKnown.length; ii++){
        if (x.spellsKnown[`${ii}`].school == `${i}`) {
          x.spellsBook += ` ${x.spellsKnown[`${ii}`].name},`
        }
      }
      x.spellsBook = x.spellsBook.slice(0, -1)
      x.spellsBook += "\n"
    }
  }
  state.character.spellsBook += "Spellbook ⚚"

  state.character.spellsNote = "[ you powers:"
  for(var i in state.skills){
    var x = state.character
    if(state.skills[`${i}`] >= 1){
      x.spellsNote += "< " + `${i}`.toLowerCase() + " spells≡"
      for(var ii = 0; ii < x.spellsKnown.length; ii++){
        if (x.spellsKnown[`${ii}`].school == `${i}`) {
          x.spellsNote += ` ${x.spellsKnown[`${ii}`].name}&`
        }
      }
      x.spellsNote = x.spellsNote.slice(0, -1)
      x.spellsNote += ">.\n"
    }
  }
  state.character.spellsNote = state.character.spellsNote.slice(0, -1)
  state.character.spellsNote += "]"

  updateWorldEntry(Number(worldInfo[0].id), "spellbook, spells, spell list, list of spells, castable", state.character.spellsBook, isNotHidden = true)
  
  if(modifiedText.toLowerCase().includes("familiar") && !state.event.familiarComplete){
    state.set.familiarMatch = true
  }
  
  if(state.set.familiarMatch == true){
    var string = modifiedText.toLowerCase()
    if(familiarTerms.exec(string)){
      state.familiar.type = familiarTerms.exec(string)[0]
      state.set.finalMessageAdd = `Congratulations! You bonded a ${state.familiar.type} familiar! You can give them a name in WI.`
      for(var i = 0; i < worldInfo.length; i++){
        if(worldInfo[`${i}`].keys.includes("⚘")){
          worldInfo[`${i}`].entry = `Familiar Type: ${state.familiar.type}\nFamiliar Name: none\nYou can update your familiar type and name here.`
        }
      }
      state.event.familiarComplete = true
      state.set.familiarMatch = false
    }
  }

  for(var i = 0; i < worldInfo.length; i++){
    if(worldInfo[`${i}`].keys.includes("⚘")){
        state.familiar.type = worldInfo[`${i}`].entry.match(/(?<=(Familiar Type:.))(.*?)(?=(\n))/) ? worldInfo[`${i}`].entry.match(/(?<=(Familiar Type:.))(.*?)(?=(\n))/)[0] : "none"
        state.familiar.name = worldInfo[`${i}`].entry.match(/(?<=(Familiar Name:.))(.*?)(?=(\n))/) ? worldInfo[`${i}`].entry.match(/(?<=(Familiar Name:.))(.*?)(?=(\n))/)[0] : "none"
    }
  }

//  for(var i = 0; i < state.spells.wizard.length; i++ ){
//    state.spells.wizard[i].isCast = false
//  }

//  if(/cast|summon|conjure|evoke|enchant|transmute|abjure/.exec(lowered)){
//    for(var i = 0; i < state.spells.wizard.length; i++ ){
//      var spellName = new RegExp(`\\b${state.spells.wizard[i].name.toLowerCase()}\\b`)
//      if(spellName.exec(lowered)){
//        state.spells.wizard[i].isCast = true
//      }
//    }
//  }

  if(state.familiar.type != "none"){
    state.event.familiarComplete = true
  }

  if(state.familiar.type != "none" && state.familiar.name != "none"){
    state.character.note += `\n[ you relations:< ${state.familiar.name}≡ familiar< ${state.familiar.type}>>.]`
  } else if (state.familiar.type != "none"){
      state.character.note += `\n[ you relations:< familiar≡ ${state.familiar.type}>.]`
  }
  
  if(command == "cheat"){
    state.skillPoints += 100
    state.set.args = []
    text = null; stop = true; return{ text, stop }
  }

  if(command == "clear" || command == "hide"){
    state.message = ""
    state.set.args = []
    text = null; stop = true; return{ text, stop }
  }

  if(command == "exp"){
    state.level.currentExp += 50
    state.set.args = []
    text = null; stop = true; return{ text, stop }
  }

  if(command == "level"){
    state.message = `Current level: ${state.level.player}. Experience required for next level: ` + (state.level.expReq - state.level.currentExp)
    state.set.args = []
    text = null; stop = true; return{ text, stop }
  }

  if(command == "tic"){
    state.set.ticDisplay = state.set.ticDisplay ? false : true
    state.set.args = []
    modifiedText = ""
  }
  
  if(state.set.ticDisplay){
    state.displayStats = [{key: "tic", value: state.set.tic, color: "green"}]
   }

  if(command == "hic"){
    state.set.meme = state.set.meme ? "" : "[A/N: everyone has been drinking heavily. Everyone is drunk right now.]"
    state.set.args = []
    text = null; stop = true; return{ text, stop }
  }

  if(command == "tits"){
    state.set.meme = state.set.meme ? "" : "[A/N: every casts spells using breasts and cleavage.]"
    state.set.args = []
    text = null; stop = true; return{ text, stop }
  }

  if(command == "lewd"){
    state.set.meme = state.set.meme ? "" : "[A/N: write this story as an erotic novel.]"
    state.set.args = []
    text = null; stop = true; return{ text, stop }
  }

  if(enCommand == "hang"){
    state.set.hang = enCommandMatcher[2] ? enCommandMatcher[2] : ""
    state.set.args = []
    text = null; stop = true; return{ text, stop }
  }

  if(enCommand == "en"){
    state.set.en = enCommandMatcher[2] ? enCommandMatcher[2] : ""
    modifiedText = ""
    state.set.enTic = state.set.tic
    text = null; stop = true; return{ text, stop }
  }

  if(enCommand == "display"){
    state.set.emDisplay = state.set.emDisplay ? false : true
    state.set.emToggle = true
    modifiedText = ""
  }

  state.set.editorText = editorText ? `[Editor's note: ${editorText}.]` : ""

  if (!state.set.emDisplay && !state.set.ticDisplay) {
    state.displayStats = []
  }

  if(state.set.emToggle){
    state.set.emToggle = false
    text = null; stop = true; return{ text, stop }
  }

  if(state.set.emDisplay){
    state.displayStats = state.set.em ? [{key: "E/N", value: state.set.editorText}] : []
  }

  if(enCommand == "editor"){
    state.set.em = state.set.em ? false : true
    text = null; stop = true; return{ text, stop }
  }

  if(state.set.em){
    modifiedText = " "
  }

  state.set.args = []

  return ({text : modifiedText})
}

modifier(text)
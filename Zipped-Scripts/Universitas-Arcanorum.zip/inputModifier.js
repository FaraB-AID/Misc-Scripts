const modifier = (text) => {    
  modifiedText = text
  stop = false  
  const lowered = text.toLowerCase()

  var enCommandMatcher = text.match(/\n? ?(?:> You |> You say "|)\/(\w*)(.*)/i) ? text.match(/\n? ?(?:> You |> You say "|)\/(\w*)(.*)/i) : []
  var enCommand = enCommandMatcher[1]
  var commandMatcher = text.match(/\n? ?(?:> You |> You say "|)\/(\w+?)( [\w ]+)?[".]?\n?$/i) ? text.match(/\n? ?(?:> You |> You say "|)\/(\w+?)( [\w ]+)?[".]?\n?$/i) : []
  var command = commandMatcher[1]
  var editorText = text.match(/\n? ?(?:> You |> You say "|)(.*)/s) ? text.match(/\n? ?(?:> You |> You say "|)(.*)/s)[1] : ""

  if(editorText == `/${command}`){ 
    editorText = ""
  }
  
  state.set.args = commandMatcher[2] ? commandMatcher[2].trim().split(' ') : []

  state.set.bookStart = 0
  state.set.bookEnd = 0
  state.message = ""

  if(!state.checkClass){
    for(i in state.skills){
      if(lowered.includes("school of " + `${i}`.toLowerCase())){
        state.skills[`${i}`] += 2
        state.character.major = `${i}`
      }
    }

    state.checkClass = true
  }
  
  familiarCheck()
  familiarVerbs()
  familiarNouns()
  familiarCheck()


  
  if(command == "rationale"){
    state.set.rationale = state.set.rationale ? false : true
    state.set.args = []
    text = null; stop = true; return{ text, stop }
  }

  if(command == "comment"){
    state.set.commentary = state.set.commentary ? false : true
    state.set.args = []
    text = null; stop = true; return{ text, stop }
  }

  if(command == "commands"){
    state.message = "/clear — remove the message (this text)\n/comment — familiar chat messages (toggle; default on)\n/rationale — exp gain messages (toggle; default off)\n/level — show current level & exp to next\n/tic — tic display (toggle; used for event timing)\n/en, /hang, /editor, /display — E/N script. See scenario comments for details." 
    state.set.args = []
    text = null; stop = true; return{ text, stop }
  }

  if(command == "secrets"){
    state.message = "/cheat — gain +100 skill points\n/exp — gain +100 exp\n/hic — make everyone drunk (toggle)\n/tits — make breasts the primary casting appendage (toggle)\n/lewd — force-start sex scenes (toggle)"
    state.set.args = []
    text = null; stop = true; return{ text, stop }
  }

  if(command == "cheat"){
    state.skillPoints += 100
    state.set.args = []
    text = null; stop = true; return{ text, stop }
  }

  if(command == "clear" || command == "hide"){
    state.message = ""
    state.set.args = []
    text = null; stop = true; return{ text, stop }
  }

  if(command == "exp"){
    state.level.currentExp += 100
    state.set.args = []
    text = null; stop = true; return{ text, stop }
  }

  if(command == "level"){
    state.message = `Current level: ${state.level.player}. Experience required for next level: ` + (state.level.expReq - state.level.currentExp)
    state.set.args = []
    text = null; stop = true; return{ text, stop }
  }

  if(command == "tic"){
    state.set.ticDisplay = state.set.ticDisplay ? false : true
    state.set.args = []
    modifiedText = ""
    state.set.comToggle = true
  }
  
  if(state.set.ticDisplay){
    state.displayStats = [{key: "tic", value: state.set.tic, color: "green"}]
   }

  if(command == "hic"){
    state.set.meme = state.set.meme ? "" : "[Author's note: everyone has been drinking heavily. Everyone is drunk right now.]"
    state.set.args = []
    text = null; stop = true; return{ text, stop }
  }

  if(command == "tits"){
    state.set.meme = state.set.meme ? "" : "[Author's note: every casts spells using breasts and cleavage.]"
    state.set.args = []
    text = null; stop = true; return{ text, stop }
  }

  if(command == "lewd"){
    state.set.meme = state.set.meme ? "" : "[Editor's note: write the next paragraph as a sex scene.]"
    state.set.args = []
    text = null; stop = true; return{ text, stop }
  }

  if(enCommand == "hang"){
    state.set.hang = enCommandMatcher[2] ? enCommandMatcher[2] : ""
    state.set.args = []
    text = null; stop = true; return{ text, stop }
  }

  if(enCommand == "en"){
    state.set.en = enCommandMatcher[2] ? enCommandMatcher[2] : ""
    modifiedText = ""
    state.set.enTic = state.set.tic
    text = null; stop = true; return{ text, stop }
  }

  if(enCommand == "display"){
    state.set.emDisplay = state.set.emDisplay ? false : true
    state.set.comToggle = true
    modifiedText = ""
  }

  state.set.editorText = editorText ? `[Editor's note: ${editorText}.]` : ""

  if (!state.set.emDisplay && !state.set.ticDisplay) {
    state.displayStats = []
  }

  if(state.set.comToggle){
    state.set.comToggle = false
    text = null; stop = true; return{ text, stop }
  }

  if(state.set.emDisplay){
    state.displayStats = state.set.em ? [{key: "E/N", value: state.set.editorText}] : []
  }

  if(enCommand == "editor"){
    state.set.em = state.set.em ? false : true
    text = null; stop = true; return{ text, stop }
  }

  if(state.set.em){
    modifiedText = " "
  }

  state.set.args = []

  return ({text : modifiedText})
}

modifier(text)

//  if (command == "learn"){
//    if (Number(state.set.args[1])){
//      var spellLevel = Number(state.set.args[1])
//      var spellSchool = toTitleCase(state.set.args[0])
//      var spellName = toTitleCase(state.set.args.splice(2).join(" "))
//      state.character.spellsKnown.push({level: spellLevel, name: spellName, school: spellSchool})
//      modifiedText = ""
//    }
//  }

//  for(var i = 0; i < state.spells.wizard.length; i++ ){
//    state.spells.wizard[i].isCast = false
//  }

//  if(/cast|summon|conjure|evoke|enchant|transmute|abjure/.exec(lowered)){
//    for(var i = 0; i < state.spells.wizard.length; i++ ){
//      var spellName = new RegExp(`\\b${state.spells.wizard[i].name.toLowerCase()}\\b`)
//      if(spellName.exec(lowered)){
//        state.spells.wizard[i].isCast = true
//      }
//    }
//  }
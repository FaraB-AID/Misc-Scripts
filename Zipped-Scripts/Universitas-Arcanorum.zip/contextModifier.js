const modifier = (text) => {
  var newtext = text

  var currHistory = history.length ? history[(history.length -1)].text : ""
  if(currHistory != state.set.prevHistory){
    state.set.ticOn = true
  }
  state.set.prevHistory = history.length ? history[(history.length -1)].text : ""

  state.evaluationBot = 'FamiliarBot'

  if(text.includes("⚚ Spellbook")){
    state.set.bookStart = text.match(/⚚ Spellbook/) ? text.match(/⚚ Spellbook/).index : 0
    state.set.bookEnd = text.match(/Spellbook ⚚/) ? text.match(/Spellbook ⚚/).index + 11 : 0
    state.set.tog = 1
  }
  newtext = newtext.substr(0,state.set.bookStart) + newtext.substr(state.set.bookEnd)


  const contextMemory = info.memoryLength ? newtext.slice(0, info.memoryLength) : ''
  const context = info.memoryLength ? newtext.slice(info.memoryLength) : newtext
  const lines = context.split("\n")


  if(state.set.tic === state.event.times[0]){
    var scheduleSchool = state.character.major ? state.character.major : "Unusual Magic"
    var scheduleAdvisor = state.set.advisors[state.character.major] ? state.set.advisors[state.character.major] : "Master Vongs"
    state.message += "\nYou have a class schedule! It's been recorded in a WI entry."
    scheduleWI = {"id": "0.046241285244748375", "keys": "schedule, classes", entry:`𝑪𝒍𝒂𝒔𝒔 𝑺𝒄𝒉𝒆𝒅𝒖𝒍𝒆:\nM,W — 9am — Introduction to ${scheduleSchool}\nT,U — 11am — Foundations for Magical Study\nT — 1pm — ${state.set.electives1[state.set.el1]}\nW — 4pm: — ${state.set.electives1[state.set.el2]}\nAdvisor: ${scheduleAdvisor}`, "isNotHidden": true}
    worldInfo.splice(2, 0, scheduleWI)
  }
  
  if(state.set.tic === (state.event.times[0] + 2)){
    state.event.note = ""
  }

  if(state.set.tic === state.event.times[1]){
    state.event.note = `[Editor's note: write a paragraph where you are gifted a scroll of Find Familiar.]`
    state.message += "\nYou can use a scroll of Find Familiar to summon a magical companion. Track their name and type in your WI to help the AI remember them!"
    state.set.eventMessage = true
  }

  if(state.set.tic === (state.event.times[1] + 2)){
    state.event.note = ""
  }

//  for(var i = 0; i < state.spells.wizard.length; i++){
//    if(state.spells.wizard[i].isCast){

//    }
//  }

  if(lines.length > 3) {
     lines.splice(-4, 0, `${state.character.note}`)
  }

  if(state.set.tog == 1){
    if(lines.length > 3) {
      lines.splice(-4, 0, `${state.character.spellsNote}`)
    }
  state.set.tog == 0
    } 

    if (lines.length > 0) {
      if(state.set.meme){
        lines.push(state.set.meme)
      }
    }

    if (lines.length > 0) {
      if(state.set.hang){
        lines.push(state.set.hang)
      }
    }
    
    if (lines.length > 0) {
      if(state.set.em){
        lines.push(state.set.editorText)
      }
    }
  
    if (lines.length > 0) {
      if(state.set.tic === state.set.enTic){
        editorNote = "[Editor's note:" + state.set.en + ".]"
        lines.push(editorNote)
      }
    }
  
    if (lines.length > 0) {
      if(state.event.note){
        lines.push(state.event.note)
      }
    }

  const combinedLines = lines.join("\n").slice(-(info.maxChars - info.memoryLength))
  var finalText = [contextMemory, combinedLines].join("")
  return { text: finalText }
}

modifier(text)
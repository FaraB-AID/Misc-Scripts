const modifier = (text) => {
  let modifiedText = text
  console.log(info)


  state.evaluationBot = 'FamiliarBot'

  function lowercaseFirstLetter(string) {
    return string.charAt(0).toLowerCase() + string.slice(1);
  }

  if (!state.set.eventMessage){
    state.message = ""
  }

  if(info.evaluation.EXP){
    state.level.currentExp += info.evaluation.EXP
    state.message = `You gained ${info.evaluation.EXP} exp because ` + lowercaseFirstLetter(info.evaluation.reason.substring(1))
    if(state.familiar.type != "none" && info.evaluation.Comment){
      if(state.familiar.name != "none"){
        state.message += `\n${state.familiar.name} says ${info.evaluation.Comment}`
      } else {
      state.message += `\nYour familiar says ${info.evaluation.Comment}`
    }
    }
  }


  if (state.level.currentExp >= state.level.expReq){
    state.level.player++
    state.level.currentExp -= state.level.expReq
    state.level.expReq = Math.round(state.level.expReq*1.25)
    state.skillPoints += 1
    state.message += `\nYou've leveled up! You're now level ${state.level.player}! Congrats!`
  }

  if(modifiedText.toLowerCase().includes("familiar") && !state.event.familiarComplete){
    state.set.familiarMatch = true
  }

  if(state.set.familiarMatch == true){
    var string = modifiedText.toLowerCase()
    if(familiarTerms.exec(string)){
      state.familiar.type = familiarTerms.exec(string)[0]
      state.set.finalMessageAdd = `Congratulations! You bonded a ${state.familiar.type} familiar! You can give them a name in WI.`
      for(var i = 0; i < worldInfo.length; i++){
        if(worldInfo[`${i}`].keys.includes("⚘")){
          worldInfo[`${i}`].entry = `Familiar Type: ${state.familiar.type}\nFamiliar Name: none\nYou can update your familiar type and name here.`
        }
      }
      state.event.familiarComplete = true
      state.set.familiarMatch = false
    }
  }

  if(state.set.ticDisplay){
    state.displayStats = [{key: "tic", value: state.set.tic, color: "green"}]
   }
  
  if (!state.set.emDisplay && !state.set.ticDisplay) {
    state.displayStats = []
  }

  if(state.set.ticOn){
    state.set.tic++
    state.set.ticOn = false
  }

  state.message += state.set.finalMessageAdd
  state.set.finalMessageAdd = ""
  state.set.eventMessage = false

  return { text: modifiedText }
  }

modifier(text)
const modifier = (text) => {
  modifiedText = text
  console.log(info)

  state.evaluationBot = 'FamiliarBot'

  function lowercaseFirstLetter(string) {
    return string.charAt(0).toLowerCase() + string.slice(1);
  }

  if (!state.set.eventMessage){
    state.message = ""
  }

  familiarCheck()
  familiarVerbs()
  familiarNouns()
  state.set.familiarMatch = false
  familiarCheck()

  if(info.evaluation.EXP){
    state.level.currentExp += info.evaluation.EXP
    if(state.set.rationale){
      state.message += newLine() + `You gained ${info.evaluation.EXP} exp because ` + lowercaseFirstLetter(info.evaluation.reason.substring(1))
    }    
  }    

  if(state.familiar.species != "none" && info.evaluation.Comment && state.set.commentary){
    if(state.familiar.name != "none"){
        state.message += newLine() + `${state.familiar.name} says ${info.evaluation.Comment}`
      } else {
      state.message += newLine() + `Your familiar says ${info.evaluation.Comment}`
    }
  }


  if (state.level.currentExp >= state.level.expReq){
    state.level.player++
    state.level.currentExp -= state.level.expReq
    state.level.expReq = Math.round(state.level.expReq*1.25)
    state.skillPoints += 1
    state.message += newLine() + `You've leveled up! You're now level ${state.level.player}! Congrats!`
  }

  if(state.set.ticDisplay){
    state.displayStats = [{key: "tic", value: state.set.tic, color: "green"}]
   }
  
  if (!state.set.enDisplay && !state.set.ticDisplay) {
    state.displayStats = []
  }

  if(state.set.ticOn){
    state.set.tic++
    state.set.ticOn = false
  }

  state.message += newLine() + state.set.finalMessageAdd
  state.set.finalMessageAdd = ""
  state.set.eventMessage = false

  return { text: modifiedText }
  }

modifier(text)
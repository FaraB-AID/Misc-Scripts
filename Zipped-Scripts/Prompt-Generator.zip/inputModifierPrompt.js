const modifier = (text) => {    
  let modifiedText = text
  stop = false  
  const lowered = text.toLowerCase()
  
  if(!state.setup){
    state.set = {show: false}
    modifiedText = "[The story begins...]\n"
    state.setup = true
    anSetting = /(?:☀)(.*)(?:☁)/.exec(text) ? /(?:☀)(.*)(?:☁)/.exec(text)[1] : ""
    anStyle = /(?:☁)(.*)(?:☂)/.exec(text) ? /(?:☁)(.*)(?:☂)/.exec(text)[1] : ""
    anFocus = /(?:☂)(.*)(?:☃)/.exec(text) ? /(?:☂)(.*)(?:☃)/.exec(text)[1] : ""
    anYou = /(?:☃)(.*)(?:☄)/.exec(text) ? /(?:☃)(.*)(?:☄)/.exec(text)[1] : ""
    anCharName1 = /(?:☄)(.*)(?:★)/.exec(text) ? /(?:☄)(.*)(?:★)/.exec(text)[1] : ""
    anChar1 = /(?:★)(.*)(?:☆)/.exec(text) ? /(?:★)(.*)(?:☆)/.exec(text)[1] : ""
    anCharName2 = /(?:☆)(.*)(?:☇)/.exec(text) ? /(?:☆)(.*)(?:☇)/.exec(text)[1] : ""
    anChar2 = /(?:☇)(.*)(?:☈)/.exec(text) ? /(?:☇)(.*)(?:☈)/.exec(text)[1] : ""
    anCharFinal1 = `& ${anCharName1}< ${anChar1}>`
    anCharFinal1 = (anCharFinal1 == "&  < >") ? "" : anCharFinal1 
    anCharFinal2 = `& ${anCharName2}< ${anChar2}>`
    anCharFinal2 = (anCharFinal2 == "&  < >") ? "" : anCharFinal2
    enLocation = /(?:☈)(.*)(?:☉)/.exec(text) ? /(?:☈)(.*)(?:☉)/.exec(text)[1] : ""
    enScene = /(?:☉)(.*)(?:☊)/.exec(text) ? /(?:☉)(.*)(?:☊)/.exec(text)[1] : ""
    state.set.anFinal = `[Author's note: [ setting:< ${anSetting}>. style:< ${anStyle}>. focus:< ${anFocus}>. characters:< you< ${anYou}>${anCharFinal1}${anCharFinal2}>.]]`
    state.set.enFinal = `[Editor's note: [ write:< opening scene>. location:< ${enLocation}>. scene:< ${enScene}>.]]`
  }

  if(lowered.includes("/show")){
    state.set.show = true
    modifiedText = `${state.set.anFinal}\n${state.set.enFinal}`
  }

  return ({text : modifiedText})
}

modifier(text)
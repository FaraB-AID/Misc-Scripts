const modifier = (text) => {
  let modifiedText = text
  const lowered = text.toLowerCase()

  if(state.set.show){
    modifiedText = `${state.set.anFinal}\n${state.set.enFinal}`
    state.set.show = false
  }

  return { text: modifiedText }
}

modifier(text)
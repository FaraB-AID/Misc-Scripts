//Enter your desired password between "". It can be any sequence of regular characters,
//which will need to appear somewhere in your prompt or initial memory 
//after placeholders to trigger the scenario conversion.
var passWord = ""

//If the player enters the correct password, 
//the text between `` will replace their prompt.
var passPrompt = ``

//If the player enters the correct password, 
//the text between `` will replace their memory.
var passMemory = ``

//If the player enters the correct password, 
//the text between `` will replace their A/N.
var passAuthorsNote = ``

//If the player enters the correct password, 
//the text between `` will be inserted as invisible floating text.
//Replace 3 with how many lines back the text should float. 3 is the default for A/N.
var passFloatText = ``
var passFloatDistance = 3

//if the player enters the correct password,
//the following WIs (up to 10) will be inserted,
//after any current WIs get deleted. Put text for keys between ""
//and entries between ``

var passWIkeys1 = ""
var passWIentry1 = ``

var passWIkeys2 = ""
var passWIentry2 = ``

var passWIkeys3 = ""
var passWIentry3 = ``

var passWIkeys4 = ""
var passWIentry4 = ``

var passWIkeys5 = ""
var passWIentry5 = ``

var passWIkeys6 = ""
var passWIentry6 = ``

var passWIkeys7 = ""
var passWIentry7 = ``

var passWIkeys8 = ""
var passWIentry8 = ``

var passWIkeys9 = ""
var passWIentry9 = ``

var passWIkeys10 = ""
var passWIentry10 = ``


const modifier = (text) => {    
  let modifiedText = text
  stop = false  
  const lowered = text.toLowerCase()

  if(!state.setup){
    state.setup = true
    state.set = {tic: 0, passWord: false, enHelp: false, enAuto: true, enFormat: true, enFormatStart: "[Editor's note: this scene< ", enFormatEnd: ">.]", enDist: 0, floatDist: 1, actionCount: 0, en: "", float: "", em: false, enDisplay: false, emToggle: false}
    if(passWord){  
      if (text.includes(passWord) || memory.includes(passWord)){
        for(var i = 0; i < worldInfo.length; i++){
          removeWorldEntry(worldInfo[i].index)
          i--
        }
        var passWIkeys = [passWIkeys1, passWIkeys2, passWIkeys3, passWIkeys4, passWIkeys5, passWIkeys6, passWIkeys7, passWIkeys8, passWIkeys9, passWIkeys10]
        var passWIentry = [passWIentry1, passWIentry2, passWIentry3, passWIentry4, passWIentry5, passWIentry6, passWIentry7, passWIentry8, passWIentry9, passWIentry10]
        for(var i = 0; i < passWIentry.length; i++){
          if(passWIkeys[i] && passWIentry[i]){
            addWorldEntry(passWIkeys[i], passWIentry[i], isNotHidden = false)
          }
        }
        modifiedText = passPrompt
        state.memory.context = passMemory
        state.memory.authorsNote = passAuthorsNote
        state.set.passWord = true
      }
    }
  }

  var enCommandMatcher = text.match(/\n? ?(> You |> You say "|)(\/\w*)? ?(.*)/i) ? text.match(/\n? ?(> You |> You say "|)(\/\w*)? ?(.*)/i) : []
  var enCommand = enCommandMatcher[2]
  var enArgs = enCommandMatcher[3]
  if(enCommandMatcher[1] == '> You ' || enCommandMatcher[1] == '> You say "'){
    enArgs = enCommandMatcher[3].substring(0, enCommandMatcher[3].length - 1)
  }
  
  state.message = ""

  if(enCommand == "/enhelp"){
    var helpText = "E/N Commands:\n/en 𝘵𝘦𝘹𝘵 — creates an E/N using 𝘵𝘦𝘹𝘵 that lasts for one action\n/float 𝘵𝘦𝘹𝘵 — creates unformatted floating text using 𝘵𝘦𝘹𝘵\n/editor — toggles Editor Mode (all inputs are converted into E/Ns)\n/display — toggles whether E/Ns are shown in the top text.\n/auto — toggles whether you automatically submit a minimal (\" \") input after setting an E/N\n/format — toggles whether E/N formatting includes \" this scene:<\"\n/endist # — sets how many lines back E/Ns float (default: 0; in front of text)\n/floatdist — sets how many lines back /float text floats (default: 1) #"
    state.set.enHelp = state.set.enHelp ? false : true
    state.message = state.set.enHelp ? helpText : ""
    text = null; stop = true; return{ text, stop }
  }

  if(enCommand == "/auto"){
    state.set.enAuto = state.set.enAuto ? false : true
    state.message = state.set.enAuto ? "Auto mode on." : "Auto mode off."
    text = null; stop = true; return{ text, stop }
  }

  if(enCommand == "/format"){
    state.set.enFormat = state.set.enFormat ? false : true
    state.message = state.set.enFormat ? `E/N format is now "[Editor's note: this scene< 𝘵𝘦𝘹𝘵>.]` : `E/N format is now "[Editor's note: 𝘵𝘦𝘹𝘵.]`
    state.set.enFormatStart = state.set.enFormat ? "[Editor's note: this scene< " : "[Editor's note: "
    state.set.enFormatEnd = state.set.enFormat ? ">.]" : ".]"
    text = null; stop = true; return{ text, stop }
  }

  if(enCommand == "/endist"){
    if(Number(enArgs)){
      state.set.enDist = Number(enArgs)
      state.message = `E/N distance set to above the ${enArgs} most recent lines of text.`
    } else {
      state.set.enDist = 0
      state.message = `E/N distance set to 0 (hanging beneath all text).`
    }
    text = null; stop = true; return{ text, stop }
  }

  if(enCommand == "/floatdist"){
    if(Number(enArgs)){
      state.set.floatDist = Number(enArgs)
      state.message = `Float distance set to above the ${enArgs} most recent lines of text.`
    } else {
      state.set.floatDist = 0
      state.message = `Float distance set to 0 (hanging beneath all text).`
    }
    text = null; stop = true; return{ text, stop }
  }

  if(enCommand == "/display"){
    state.set.enDisplay = state.set.enDisplay ? false : true
    state.message = state.set.enDisplay ? "E/N display on." : "E/N display off."
    if (state.set.enDisplay){
      state.displayStats = state.set.en ? [{key: "E/N", value: state.set.en}] : []
    } else {
      state.displayStats = []
    }
    text = null; stop = true; return{ text, stop }
  }

  if(enCommand == "/float"){
    state.set.float = enArgs ? enArgs : ""
    text = null; stop = true; return{ text, stop }
  }

  if(enCommand == "/en"){
    state.set.en = enArgs ? `${state.set.enFormatStart}${enArgs}${state.set.enFormatEnd}` : ""
    state.set.actionCount = enArgs ? info.actionCount : 0
    if(state.set.enDisplay){
      state.displayStats = state.set.en ? [{key: "E/N", value: state.set.en}] : []
    }
    if(state.set.enAuto){
      modifiedText = " "
      if(state.set.actionCount){
        state.set.actionCount++
      }
    } else {
      text = null; stop = true; return{ text, stop }
    }
  }

  if(enCommand == "/editor"){
    state.set.em = state.set.em ? false : true
    state.set.en = state.set.em ? state.set.en : ""
    state.set.message = state.set.em ? "Editor mode enabled." : "Editor mode disabled."
    text = null; stop = true; return{ text, stop }
  }

  if(state.set.em && !enCommand){
    state.set.actionCount = enArgs ? 0 : state.set.actionCount
    state.set.en = enArgs ? `${state.set.enFormatStart}${enArgs}${state.set.enFormatEnd}` : ""
    if(state.set.enDisplay){
      state.displayStats = state.set.en ? [{key: "E/N", value: state.set.en}] : []
    }
    if(state.set.enAuto && enArgs){
      modifiedText = " "
    } else {
      text = null; stop = true; return{ text, stop }
    }
  }

    return ({text : modifiedText})
}

modifier(text)
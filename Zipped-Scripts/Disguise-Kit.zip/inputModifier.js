

const modifier = (text) => {    
  let modifiedText = text
  stop = false  
  const lowered = text.toLowerCase()

  if(!state.setup){
    state.setup = true
    state.set = {tic: 0, em: false, emDisplay: false, emtoggle: false, passWord: false}
    if (text.includes(passWord) || memory.includes(passWord)){
      for(var i = 0; i < worldInfo.length; i++){
        removeWorldEntry(worldInfo[i].index)
        i--
      }
      var passWIkeys = [passWIkeys1, passWIkeys2, passWIkeys3, passWIkeys4, passWIkeys5, passWIkeys6, passWIkeys7, passWIkeys8, passWIkeys9, passWIkeys10]
      var passWIentry = [passWIentry1, passWIentry2, passWIentry3, passWIentry4, passWIentry5, passWIentry6, passWIentry7, passWIentry8, passWIentry9, passWIentry10]
      for(var i = 0; i < passWIentry.length; i++){
        if(passWIkeys[i] && passWIentry[i]){
          addWorldEntry(passWIkeys[i], passWIentry[i], isNotHidden = false)
        }
      }
      modifiedText = passPrompt
      state.memory.context = passMemory
      state.memory.authorsNote = passAuthorsNote
      state.set.passWord = true
    }
  }

  var enCommandMatcher = text.match(/\n? ?(?:> You |> You say "|)\/(\w*)(.*)/i) ? text.match(/\n? ?(?:> You |> You say "|)\/(\w*)(.*)/i) : []
  var enCommand = enCommandMatcher[1]
  var editorText = text.match(/\n? ?(?:> You |> You say "|)(.*)/s) ? text.match(/\n? ?(?:> You |> You say "|)(.*)/s)[1] : ""

  if(editorText == `/${enCommand}`){ 
    editorText = ""
  }

  if(enCommand == "hang"){
    state.set.hang = enCommandMatcher[2] ? enCommandMatcher[2] : ""
    modifiedText = ""
    text = null; stop = true; return{ text, stop }
  }

  if(enCommand == "en"){
    state.set.en = enCommandMatcher[2] ? enCommandMatcher[2] : ""
    modifiedText = ""
    state.set.enTic = state.set.tic
    text = null; stop = true; return{ text, stop }
  }

  if(enCommand == "display"){
    state.set.emDisplay = state.set.emDisplay ? false : true
    state.set.emToggle = true
    modifiedText = ""
  }

  state.set.editorText = editorText ? `[Editor's note: ${editorText}.]` : ""

  if(state.set.emDisplay){
    state.displayStats = state.set.em ? [{key: "E/N", value: state.set.editorText}] : []
  } else {
    state.displayStats = []
  }

  if(state.set.emToggle){
    state.set.emToggle = false
    text = null; stop = true; return{ text, stop }
  }

  if(enCommand == "editor"){
    state.set.em = state.set.em ? false : true
    text = null; stop = true; return{ text, stop }
  }

  if(state.set.em){
    modifiedText = " "
  }

    return ({text : modifiedText})
}

modifier(text)